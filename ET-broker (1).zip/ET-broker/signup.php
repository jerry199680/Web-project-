<?php
session_start(); // Start the session
header('Content-Type: application/json');

// Connect to the database
require_once 'db_connect.php';

// --- Response Function ---
function send_response($status, $message, $data = []) {
    echo json_encode(['status' => $status, 'message' => $message, 'data' => $data]);
    exit();
}

// Check for DB connection errors
if ($conn->connect_error) {
    send_response('error', 'Database connection failed: ' . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_response('error', 'Invalid request method.');
}

// Get and sanitize input
$role = filter_input(INPUT_POST, 'role', FILTER_SANITIZE_STRING) ?? 'user';
$fullname = filter_input(INPUT_POST, 'fullname', FILTER_SANITIZE_STRING) ?? '';
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL) ?? '';
$phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING) ?? '';
$password = $_POST['password'] ?? ''; // Don't sanitize password
$confirm_password = $_POST['confirm_password'] ?? '';
$admin_secret = filter_input(INPUT_POST, 'admin_secret', FILTER_SANITIZE_STRING) ?? '';
$address = filter_input(INPUT_POST, 'address', FILTER_SANITIZE_STRING) ?? '';

// Validate required fields
if (empty($fullname) || empty($email) || empty($phone) || empty($password)) {
    send_response('error', 'Please fill in all required fields.');
}

// Validate password match
if ($password !== $confirm_password) {
    send_response('error', 'Passwords do not match.', ['field' => 'confirm-password']);
}

// Validate email format
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    send_response('error', 'Invalid email format.', ['field' => 'email']);
}

// Validate password strength
if (strlen($password) < 8) {
    send_response('error', 'Password must be at least 8 characters long.', ['field' => 'password']);
}

// --- Avatar Upload ---
$avatar_path = 'images/default-avatar.png';
if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
    $upload_dir = 'images/avatars/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    // Validate file type
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
    $file_type = $_FILES['avatar']['type'];
    if (!in_array($file_type, $allowed_types)) {
        send_response('error', 'Invalid file type. Only JPG, PNG, and GIF are allowed.', ['field' => 'avatar']);
    }
    
    // Validate file size (max 5MB)
    if ($_FILES['avatar']['size'] > 5 * 1024 * 1024) {
        send_response('error', 'File is too large. Maximum size is 5MB.', ['field' => 'avatar']);
    }
    
    $avatar_name = uniqid('avatar_', true) . '.' . pathinfo(basename($_FILES['avatar']['name']), PATHINFO_EXTENSION);
    $target_file = $upload_dir . $avatar_name;
    if (move_uploaded_file($_FILES['avatar']['tmp_name'], $target_file)) {
        $avatar_path = $target_file;
    } else {
        send_response('error', 'Failed to upload avatar.', ['field' => 'avatar']);
    }
}

// Hash the password
$password_hash = password_hash($password, PASSWORD_BCRYPT);

// --- Database Insertion ---
if ($role === 'admin') {
    // Validate admin secret
    $correct_admin_secret = "ETHIO_ADMIN_2024"; 
    if ($admin_secret !== $correct_admin_secret) {
        send_response('error', 'Invalid Admin Secret Code.', ['field' => 'admin-secret']);
    }
    
    // Check if admin email already exists
    $stmt = $conn->prepare("SELECT id FROM admins WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        send_response('error', 'An admin with this email already exists.', ['field' => 'email']);
    }
    $stmt->close();
    
    // Insert new admin
    $stmt = $conn->prepare("INSERT INTO admins (fullname, email, password_hash, passcode) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $fullname, $email, $password_hash, $admin_secret);
    if ($stmt->execute()) {
        $admin_id = $stmt->insert_id;
        
        // Automatically log the admin in
        $_SESSION['user_id'] = $admin_id;
        $_SESSION['fullname'] = $fullname;
        $_SESSION['email'] = $email;
        $_SESSION['role'] = 'admin';
        $_SESSION['last_activity'] = time();
        
        send_response('success', 'Admin account created successfully.', ['role' => 'admin']);
    } else {
        send_response('error', 'Failed to create admin account: ' . $conn->error);
    }
    $stmt->close();

} else { // 'user' role
    // Check if user email or phone already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? OR phone = ?");
    $stmt->bind_param("ss", $email, $phone);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        send_response('error', 'A user with this email or phone number already exists.', ['field' => 'email']);
    }
    $stmt->close();

    $is_seller = isset($_POST['is_seller']) ? 1 : 0;

    // Insert new user
    $stmt = $conn->prepare("INSERT INTO users (fullname, email, phone, password_hash, avatar, is_seller, address) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssis", $fullname, $email, $phone, $password_hash, $avatar_path, $is_seller, $address);

    if ($stmt->execute()) {
        $user_id = $stmt->insert_id;

        // Automatically log the user in
        $_SESSION['user_id'] = $user_id;
        $_SESSION['fullname'] = $fullname;
        $_SESSION['email'] = $email;
        $_SESSION['avatar'] = $avatar_path;
        $_SESSION['is_seller'] = (bool)$is_seller;
        $_SESSION['role'] = 'user';
        $_SESSION['last_activity'] = time();

        $user_data = [
            'id' => $user_id,
            'fullname' => $fullname,
            'email' => $email,
            'avatar' => $avatar_path,
            'is_seller' => (bool)$is_seller,
            'role' => 'user'
        ];

        send_response('success', 'Account created successfully! Redirecting...', $user_data);
    } else {
        send_response('error', 'Failed to create account: ' . $conn->error);
    }
    $stmt->close();
}

$conn->close();
?>
