document.addEventListener('DOMContentLoaded', () => {
    // --- MOCK DATA ---
    let tempProductData = null; // To hold product data before payment
    const seller = {
        name: "Elena Petrova",
        avatar: "images/a9a28572d7d010e5403ceb9b76d575f5.jpg"
    };

    let products = [
        { id: 1, name: "Modern Velvet Chair", category: "Furniture", price: 299.99, stock: 15, status: "In Stock", views: 2800, sales: 120, description: "A stylish and comfortable chair for any modern living room.", image: "images/air1.jpg" },
        { id: 2, name: "Wireless ANC Headphones", category: "Electronics", price: 149.50, stock: 3, status: "Low Stock", views: 5600, sales: 350, description: "Immerse yourself in music with these noise-cancelling headphones.", image: "images/888d5ef36fa9f83b4cffaacd968b2af6.jpg" },
        { id: 3, name: "Vintage Leather Bag", category: "Apparel", price: 89.00, stock: 0, status: "Out of Stock", views: 1200, sales: 50, description: "A classic leather bag that combines style and function.", image: "images/Bag.jpg" }
    ];

    const reviews = [
        { user: "John M.", avatar: "images/a8d80c1f4d009efadc5065e4631e7eee.jpg", rating: 5, text: "Absolutely love the Modern Velvet Chair! It's even more beautiful in person and so comfortable. Delivery was quick too." },
        { user: "Sarah K.", avatar: "images/b347226b26108eb06dfb2f8effc9a341.jpg", rating: 4, text: "The headphones are great for the price. Noise cancellation is decent, but the battery could be a bit better." }
    ];

    const notifications = [
        { type: "new_order", text: "You have a new order (#10582) for Wireless ANC Headphones.", unread: true },
        { type: "low_stock", text: "Warning: 'Vintage Leather Bag' is now out of stock.", unread: true },
        { type: "review", text: "You received a new 5-star review for 'Modern Velvet Chair'.", unread: false }
    ];
    
    const messages = [
        { from: "Alex Ray", text: "Hi, can you tell me the dimensions of the velvet chair?", unread: true },
        { from: "Mia Wong", text: "I'm interested in the leather bag. When will it be back in stock?", unread: true }
    ];

    const transactions = [
        { id: "TRX001", date: "2023-10-26", amount: 1500.00, status: "Completed" },
        { id: "TRX002", date: "2023-10-20", amount: 850.50, status: "Completed" },
        { id: "TRX003", date: "2023-10-15", amount: 2500.00, status: "Pending" }
    ];


    // --- DOM ELEMENTS ---
    const views = document.querySelectorAll('.view');
    const sidebarLinks = document.querySelectorAll('.sidebar-nav li');
    const greetingEl = document.getElementById('greeting');
    const sellerNameEl = document.getElementById('seller-name');
    const sellerAvatarEl = document.getElementById('seller-avatar');
    const notificationsBadge = document.getElementById('notifications-badge');
    const messagesBadge = document.getElementById('messages-badge');
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const sidebar = document.querySelector('.sidebar');

    // --- RENDER FUNCTIONS ---
    const renderAddProductForm = (product = {}) => {
        const isEdit = Object.keys(product).length > 0;
        const view = document.getElementById('add-product-view');
        view.innerHTML = `
            <div class="widget">
                <div class="widget-header"><h2>${isEdit ? 'Edit' : 'Add New'} Product</h2></div>
                <form id="product-form" data-id="${product.id || ''}">
                    <div class="form-layout">
                        <div class="image-upload-group">
                            <img src="${product.image || 'images/placeholder.png'}" alt="Product preview" id="image-preview">
                            <div>
                                <label for="product-image">Product Image</label>
                                <input type="file" id="product-image" accept="image/*">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="product-name">Product Name</label>
                            <input type="text" id="product-name" value="${product.name || ''}" required>
                        </div>
                        <div class="form-group">
                            <label for="product-category">Category</label>
                            <select id="product-category" required>
                                <option ${product.category === 'Furniture' ? 'selected' : ''}>Furniture</option>
                                <option ${product.category === 'Electronics' ? 'selected' : ''}>Electronics</option>
                                <option ${product.category === 'Apparel' ? 'selected' : ''}>Apparel</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="product-price">Price</label>
                            <input type="number" id="product-price" value="${product.price || ''}" required>
                        </div>
                        <div class="form-group">
                            <label for="product-stock">Stock</label>
                            <input type="number" id="product-stock" value="${product.stock || ''}" required>
                        </div>
                        <div class="form-group full-width">
                            <label for="product-description">Description</label>
                            <textarea id="product-description" rows="4">${product.description || ''}</textarea>
                        </div>
                        <div class="form-group full-width">
                            <button type="submit" class="btn">${isEdit ? 'Save Changes' : 'Proceed to Payment'}</button>
                        </div>
                    </div>
                </form>
            </div>`;
        
        document.getElementById('product-image').addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (event) => {
                    document.getElementById('image-preview').src = event.target.result;
                }
                reader.readAsDataURL(file);
            }
        });
    };

    const renderPaymentView = () => {
        const view = document.getElementById('payment-view');
        const listingFee = 5.00; // Example fee
        view.innerHTML = `
            <div class="widget">
                <div class="widget-header"><h2>Confirm Payment</h2></div>
                <div class="payment-summary">
                    <h3>Listing Fee</h3>
                    <div class="fee">$${listingFee.toFixed(2)}</div>
                    <p>A small fee is required to list your product on our platform.</p>
                    <br>
                    <button id="confirm-payment-btn" class="btn">Confirm Payment & Upload</button>
                </div>
            </div>`;
    };

    // --- EVENT HANDLERS & LOGIC ---
    const switchView = (viewName) => {
        sidebarLinks.forEach(l => l.classList.remove('active'));
        const activeLink = document.querySelector(`[data-view="${viewName}"]`);
        if (activeLink) activeLink.classList.add('active');
        
        views.forEach(v => v.classList.remove('active'));
        const targetView = document.getElementById(`${viewName}-view`);
        targetView.classList.add('active');

        // Lazy load content
        switch (viewName) {
            case 'dashboard': renderDashboard(); break;
            case 'products': renderProducts(); break;
            case 'add-product': renderAddProductForm(); break;
            case 'reviews': renderReviews(); break;
            case 'payouts': renderTransactions(); break;
            case 'notifications': renderNotifications(); break;
            case 'payment': renderPaymentView(); break;
        }
    };

    const handleProductFormSubmit = (e) => {
        e.preventDefault();
        const form = e.target;
        const id = form.dataset.id;
        
        tempProductData = {
            name: form.querySelector('#product-name').value,
            category: form.querySelector('#product-category').value,
            price: parseFloat(form.querySelector('#product-price').value),
            stock: parseInt(form.querySelector('#product-stock').value),
            description: form.querySelector('#product-description').value,
            image: form.querySelector('#image-preview').src,
            status: parseInt(form.querySelector('#product-stock').value) > 0 ? "In Stock" : "Out of Stock",
            views: 0,
            sales: 0
        };

        if (id) { // If editing, just save it without payment
            products = products.map(p => p.id === parseInt(id) ? { ...p, ...tempProductData } : p);
            tempProductData = null; // clear temp data
            switchView('products');
        } else { // If new, proceed to payment
            switchView('payment');
        }
    };

    const handlePaymentConfirmation = () => {
        if (tempProductData) {
            tempProductData.id = Date.now();
            products.push(tempProductData);
            tempProductData = null; // clear temp data
            alert('Payment successful! Your product has been listed.');
            switchView('products');
        }
    };

    const handleProductsTableClick = (e) => {
        const target = e.target.closest('button');
        if (!target) return;

        const id = parseInt(target.dataset.id);
        if (target.classList.contains('delete')) {
            if (confirm('Are you sure you want to delete this product?')) {
                products = products.filter(p => p.id !== id);
                renderProducts();
            }
        } else if (target.classList.contains('edit')) {
            const product = products.find(p => p.id === id);
            switchView('add-product');
            renderAddProductForm(product);
        }
    };

    // --- INITIALIZATION ---
    const init = () => {
        // Load initial data
        greetingEl.textContent = `Welcome back, ${seller.name}!`;
        sellerNameEl.textContent = seller.name;
        sellerAvatarEl.src = seller.avatar;
        notificationsBadge.textContent = notifications.filter(n => n.unread).length;
        messagesBadge.textContent = messages.filter(m => m.unread).length;

        // Set up event listeners
        sidebarLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                switchView(link.dataset.view);
            });
        });

        mobileMenuToggle.addEventListener('click', () => sidebar.classList.toggle('open'));
        
        document.addEventListener('submit', e => {
            if (e.target.id === 'product-form') handleProductFormSubmit(e);
        });

        document.addEventListener('click', e => {
            if (e.target.closest('.product-table')) handleProductsTableClick(e);
            if (e.target.id === 'confirm-payment-btn') handlePaymentConfirmation();
            if (e.target.id === 'add-new-product-btn') switchView('add-product');
        });

        // Load initial view
        switchView('dashboard');
    };

    const initChart = () => {
        const ctx = document.getElementById('salesChart')?.getContext('2d');
        if (!ctx) return;
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Sales',
                    data: [120, 190, 150, 250, 220, 300],
                    borderColor: 'var(--accent-teal)',
                    backgroundColor: 'rgba(0, 121, 107, 0.1)',
                    tension: 0.4,
                    fill: true,
                }]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });
    };
    
    // --- Helper functions from previous steps that are still needed ---
    const createKpiCard = (kpi) => `
        <div class="kpi-card">
            <div class="icon"><i class="fas ${kpi.icon}"></i></div>
            <div class="info">
                <div class="value">${kpi.value}</div>
                <div class="label">${kpi.label}</div>
            </div>
        </div>`;

    const createProductRow = (p) => `
        <tr>
            <td>
                <div class="product-info">
                    <img src="${p.image}" alt="${p.name}">
                    <span>${p.name}</span>
                </div>
            </td>
            <td>${p.category}</td>
            <td>$${p.price.toFixed(2)}</td>
            <td>${p.stock}</td>
            <td><span class="status ${p.status.toLowerCase().replace(' ', '')}">${p.status}</span></td>
            <td class="actions">
                <button class="btn-icon view" data-id="${p.id}"><i class="fas fa-eye"></i></button>
                <button class="btn-icon edit" data-id="${p.id}"><i class="fas fa-edit"></i></button>
                <button class="btn-icon delete" data-id="${p.id}"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`;

    const renderDashboard = () => {
        const totalSales = products.reduce((sum, p) => sum + p.price * p.sales, 0);
        const kpis = [
            { icon: 'fa-dollar-sign', label: 'Total Revenue', value: `$${(totalSales / 1000).toFixed(1)}k` },
            { icon: 'fa-box-open', label: 'Active Listings', value: products.filter(p => p.stock > 0).length },
            { icon: 'fa-star', label: 'Average Rating', value: '4.8' },
            { icon: 'fa-arrow-trend-up', label: 'Total Sales', value: products.reduce((sum, p) => sum + p.sales, 0) }
        ];
        const recentProducts = products.slice(0, 3);

        const view = document.getElementById('dashboard-view');
        view.innerHTML = `
            <div class="kpi-grid">${kpis.map(createKpiCard).join('')}</div>
            <div class="dashboard-layout">
                <div class="widget">
                    <div class="widget-header"><h2>Sales Analytics</h2></div>
                    <canvas id="salesChart"></canvas>
                </div>
                <div class="widget">
                    <div class="widget-header"><h2>Recent Products</h2></div>
                    <table class="product-table mini">
                        <tbody>${recentProducts.map(p => `
                            <tr>
                                <td>
                                    <div class="product-info">
                                        <img src="${p.image}" alt="${p.name}">
                                        <span>${p.name}</span>
                                    </div>
                                </td>
                                <td>$${p.price.toFixed(2)}</td>
                            </tr>`).join('')}
                        </tbody>
                    </table>
                </div>
            </div>`;
        initChart();
    };

    const renderProducts = () => {
        const view = document.getElementById('products-view');
        view.innerHTML = `
            <div class="widget">
                <div class="widget-header">
                    <h2>All Products</h2>
                    <button class="btn" id="add-new-product-btn">Add New Product</button>
                </div>
                <table class="product-table">
                    <thead><tr><th>Product</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th>Actions</th></tr></thead>
                    <tbody>${products.map(createProductRow).join('')}</tbody>
                </table>
            </div>`;
    };

    const renderReviews = () => {
        const view = document.getElementById('reviews-view');
        view.innerHTML = `
            <div class="widget">
                <div class="widget-header"><h2>Customer Reviews</h2></div>
                <div class="reviews-grid">
                    ${reviews.map(r => `
                        <div class="review-card">
                            <div class="review-header">
                                <img src="${r.avatar}" alt="${r.user}">
                                <div>
                                    <strong>${r.user}</strong>
                                    <div class="review-rating">${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}</div>
                                </div>
                            </div>
                            <p class="review-body">${r.text}</p>
                        </div>
                    `).join('')}
                </div>
            </div>`;
    };

    const renderTransactions = () => {
        const view = document.getElementById('payouts-view');
        view.innerHTML = `
            <div class="widget">
                <div class="widget-header"><h2>Transaction History</h2></div>
                <div class="item-list">
                    ${transactions.map(t => `
                        <div class="list-item">
                            <div class="icon"><i class="fas fa-receipt"></i></div>
                            <div class="info">
                                <strong>Transaction #${t.id}</strong>
                                <small>${t.date}</small>
                            </div>
                            <div class="amount">$${t.amount.toFixed(2)}</div>
                            <div class="status ${t.status.toLowerCase()}">${t.status}</div>
                        </div>
                    `).join('')}
                </div>
            </div>`;
    };
    
    const renderNotifications = () => {
        const view = document.getElementById('notifications-view');
        view.innerHTML = `
            <div class="widget">
                <div class="widget-header"><h2>Notifications</h2></div>
                <div class="item-list">
                    ${notifications.map(n => `
                        <div class="list-item ${n.unread ? 'unread' : ''}">
                            <div class="icon"><i class="fas ${n.type === 'new_order' ? 'fa-shopping-cart' : 'fa-info-circle'}"></i></div>
                            <div class="info">${n.text}</div>
                        </div>
                    `).join('')}
                </div>
            </div>`;
    };

    init();
});
document.addEventListener('DOMContentLoaded', () => {
    // ... (existing chart and mobile menu code) ...

    const addProductForm = document.getElementById('add-product-form'); // Assuming form ID
    const productsTable = document.querySelector('.products-list-widget tbody');

    // Mock seller data (in a real app, this would come from the logged-in user's session)
    const currentSeller = {
        name: 'Abel T.',
        profilePic: 'images/a9a28572d7d010e5403ceb9b76d575f5.jpg',
        location: 'Addis Ababa'
    };

    function loadProducts() {
        const products = JSON.parse(localStorage.getItem('products')) || [];
        const sellerProducts = products.filter(p => p.sellerName === currentSeller.name);
        
        if (productsTable) {
            productsTable.innerHTML = sellerProducts.map(p => `
                <tr>
                    <td><input type="checkbox"></td>
                    <td>
                        <div class="product-info">
                            <img src="${p.image}" alt="${p.name}">
                            <span>${p.name}</span>
                        </div>
                    </td>
                    <td>$${p.price.toFixed(2)}</td>
                    <td>${p.stock || 'N/A'}</td>
                    <td><span class="status active">Active</span></td>
                    <td>${p.views || 0}</td>
                    <td class="actions">
                        <button class="btn-icon"><i class="fas fa-edit"></i></button>
                        <button class="btn-icon"><i class="fas fa-trash"></i></button>
                    </td>
                </tr>
            `).join('');
        }
    }

    if (addProductForm) {
        addProductForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            const products = JSON.parse(localStorage.getItem('products')) || [];
            
            const newProduct = {
                id: Date.now(),
                name: document.getElementById('product-name').value,
                price: parseFloat(document.getElementById('product-price').value),
                category: document.getElementById('product-category').value,
                image: document.getElementById('image-preview-container').querySelector('img').src, // from image preview
                sellerName: currentSeller.name,
                sellerProfilePic: currentSeller.profilePic,
                sellerLocation: currentSeller.location,
                stock: 100, // Example stock
                views: 0
            };

            products.push(newProduct);
            localStorage.setItem('products', JSON.stringify(products));
            
            alert('Product added successfully!');
            addProductForm.reset();
            document.getElementById('image-preview-container').style.display = 'none';
            
            loadProducts(); // Refresh the table
        });
    }

    loadProducts();
    console.log('Seller dashboard initialized.');
});
