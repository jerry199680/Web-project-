function renderProductCard(product) {
    return `
        <div class="product-card" data-id="${product.id}">
            <div class="product-image-container">
                <a href="product-detail.html?id=${product.id}">
                    <img src="${product.image}" alt="${product.name}" loading="lazy">
                </a>
                ${product.badge ? `<div class="product-badge">${product.badge}</div>` : ''}
                <button class="quick-view-btn" aria-label="Quick View"><i class="fas fa-eye"></i></button>
            </div>
            <div class="product-info">
                <h3><a href="product-detail.html?id=${product.id}">${product.name}</a></h3>
                <div class="price">$${parseFloat(product.price).toFixed(2)}</div>
                <div class="product-meta">
                    <span><i class="fas fa-map-marker-alt"></i> ${product.location}</span> | 
                    <span>by <strong>${product.seller_name}</strong></span>
                </div>
                <button class="add-to-cart-btn" data-product-id="${product.id}">Add to Cart</button>
            </div>
        </div>
    `;
}

document.addEventListener('click', async (e) => {
    if (e.target.classList.contains('add-to-cart-btn')) {
        const productId = e.target.dataset.productId;
        try {
            const response = await fetch('/api/cart.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ product_id: productId, quantity: 1 }),
            });
            const result = await response.json();
            if (result.success) {
                updateCartCount();
                // Optionally, show a success message
                alert('Product added to cart!');
            } else {
                alert(result.message || 'Could not add to cart. Please log in.');
            }
        } catch (error) {
            console.error('Error adding to cart:', error);
            alert('An error occurred. Please try again.');
        }
    }
});

async function updateCartCount() {
    try {
        const response = await fetch('/api/cart.php');
        const cart = await response.json();
        const cartCount = document.getElementById('cartCount');
        if (cartCount && Array.isArray(cart)) {
            const totalQuantity = cart.reduce((sum, item) => sum + item.quantity, 0);
            cartCount.textContent = totalQuantity;
        }
    } catch (error) {
        console.error('Error updating cart count:', error);
    }
}

document.addEventListener('DOMContentLoaded', updateCartCount);
