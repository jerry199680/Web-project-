document.addEventListener('DOMContentLoaded', () => {
    // Get product ID from URL
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('id');

    if (!productId) {
        console.error('No product ID specified in URL');
        return;
    }

    // Fetch product data
    fetch(`/backend/products.php?id=${productId}`)
        .then(response => {
            if (!response.ok) throw new Error('Product not found');
            return response.json();
        })
        .then(product => {
            // Update product details in the page
            document.getElementById('productTitle').textContent = product.name;
            document.getElementById('productPrice').textContent = `$${product.price}`;
            document.getElementById('productDescription').textContent = product.description;
            document.getElementById('mainProductImage').src = product.image;

            // Image Gallery
            const mainImage = document.getElementById('mainProductImage');
            const thumbnails = document.querySelectorAll('.thumbnail');

            thumbnails.forEach(thumbnail => {
                thumbnail.addEventListener('click', () => {
                    // Remove active class from all thumbnails
                    thumbnails.forEach(t => t.classList.remove('active'));
                    // Add active class to the clicked one
                    thumbnail.classList.add('active');
                    
                    if (!thumbnail.classList.contains('video-thumbnail')) {
                        mainImage.src = thumbnail.src;
                    } else {
                        // Handle video display logic, e.g., open a modal
                        console.log('Video thumbnail clicked');
                    }
                });
            });

            // Tabs
            const tabLinks = document.querySelectorAll('.tab-link');
            const tabContents = document.querySelectorAll('.tab-content');
    
            tabLinks.forEach(link => {
                link.addEventListener('click', () => {
                    const tabId = link.dataset.tab;
    
                    // Update active tab link
                    tabLinks.forEach(l => l.classList.remove('active'));
                    link.classList.add('active');
    
                    // Update active tab content
                    tabContents.forEach(content => {
                        if (content.id === tabId) {
                            content.classList.add('active');
                        } else {
                            content.classList.remove('active');
                        }
                    });
                });
            });
    
            // Quantity Selector
            const minusBtn = document.querySelector('.qty-btn.minus');
            const plusBtn = document.querySelector('.qty-btn.plus');
            const qtyInput = document.getElementById('quantity');
    
            minusBtn.addEventListener('click', () => {
                let currentValue = parseInt(qtyInput.value);
                if (currentValue > 1) {
                    qtyInput.value = currentValue - 1;
                }
            });
    
            plusBtn.addEventListener('click', () => {
                let currentValue = parseInt(qtyInput.value);
                qtyInput.value = currentValue + 1;
            });
        });
        .catch(error => {
            console.error('Error loading product:', error);
            document.getElementById('productContainer').innerHTML = 
                '<div class="error">Product not found</div>';
        });
});