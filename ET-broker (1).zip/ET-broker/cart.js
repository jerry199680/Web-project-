// Cart Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const cartItems = document.getElementById('cartItems');
    const emptyCart = document.getElementById('emptyCart');
    const cartItemCount = document.getElementById('cartItemCount');
    const subtotal = document.getElementById('subtotal');
    const shipping = document.getElementById('shipping');
    const tax = document.getElementById('tax');
    const total = document.getElementById('total');
    const clearCartBtn = document.getElementById('clearCartBtn');
    const checkoutBtn = document.getElementById('checkoutBtn');
    const couponCode = document.getElementById('couponCode');
    const applyCouponBtn = document.getElementById('applyCouponBtn');
    const couponMessage = document.getElementById('couponMessage');
    const recommendedProducts = document.getElementById('recommendedProducts');
    
    // Modal elements
    const quantityModal = document.getElementById('quantityModal');
    const removeModal = document.getElementById('removeModal');
    const closeQuantityModal = document.getElementById('closeQuantityModal');
    const closeRemoveModal = document.getElementById('closeRemoveModal');
    
    // State
    let cart = [];
    let currentItemId = null;
    let appliedCoupon = null;
    
    // Initialize
    loadCart();
    setupEventListeners();
    loadRecommendedProducts();
    
    function setupEventListeners() {
        // Clear cart
        clearCartBtn.addEventListener('click', clearCart);
        
        // Checkout
        checkoutBtn.addEventListener('click', proceedToCheckout);
        
        // Coupon
        applyCouponBtn.addEventListener('click', applyCoupon);
        couponCode.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') applyCoupon();
        });
        
        // Modal controls
        closeQuantityModal.addEventListener('click', () => quantityModal.classList.remove('show'));
        closeRemoveModal.addEventListener('click', () => removeModal.classList.remove('show'));
        
        // Close modals on outside click
        quantityModal.addEventListener('click', (e) => {
            if (e.target === quantityModal) quantityModal.classList.remove('show');
        });
        removeModal.addEventListener('click', (e) => {
            if (e.target === removeModal) removeModal.classList.remove('show');
        });
    }
    
    function loadCart() {
        // Load cart from localStorage
        const savedCart = localStorage.getItem('cart');
        if (savedCart) {
            cart = JSON.parse(savedCart);
        }
        
        renderCart();
        updateSummary();
    }
    
    function saveCart() {
        localStorage.setItem('cart', JSON.stringify(cart));
        updateCartCount();
    }
    
    function updateCartCount() {
        const count = cart.reduce((total, item) => total + item.quantity, 0);
        cartItemCount.textContent = `${count} item${count !== 1 ? 's' : ''} in your cart`;
        
        // Update header cart count
        const headerCartCount = document.getElementById('cartCount');
        if (headerCartCount) {
            headerCartCount.textContent = count;
        }
    }
    
    function renderCart() {
        if (cart.length === 0) {
            cartItems.style.display = 'none';
            emptyCart.style.display = 'block';
            return;
        }

        cartItems.style.display = 'block';
        emptyCart.style.display = 'none';
        
        cartItems.innerHTML = cart.map(item => `
            <div class="cart-item" data-id="${item.id}">
                <div class="cart-item-image">
                    <img src="${item.image}" alt="${item.title}">
                </div>
                <div class="cart-item-details">
                    <h3 class="cart-item-title">${item.title}</h3>
                    <p class="cart-item-seller">Sold by ${item.seller}</p>
                    <p class="cart-item-location">
                        <i class="fas fa-map-marker-alt"></i>
                        ${item.location}
                    </p>
                </div>
                <div class="cart-item-actions">
                    <div class="cart-item-price">ETB ${(item.price * item.quantity).toFixed(2)}</div>
                    <div class="cart-item-controls">
                        <div class="quantity-control">
                            <button class="quantity-btn" onclick="updateQuantity(${item.id}, ${item.quantity - 1})">
                                <i class="fas fa-minus"></i>
                            </button>
                            <span class="quantity-input">${item.quantity}</span>
                            <button class="quantity-btn" onclick="updateQuantity(${item.id}, ${item.quantity + 1})">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                        <button class="cart-item-remove" onclick="showRemoveModal(${item.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                    </div>
                </div>
        `).join('');
    }
    
    function updateSummary() {
        const subtotalAmount = cart.reduce((total, item) => total + (item.price * item.quantity), 0);
        const shippingAmount = calculateShipping(subtotalAmount);
        const taxAmount = (subtotalAmount + shippingAmount) * 0.15; // 15% tax
        const totalAmount = subtotalAmount + shippingAmount + taxAmount;
        
        // Apply coupon discount if any
        let discountAmount = 0;
        if (appliedCoupon) {
            discountAmount = appliedCoupon.type === 'percentage' 
                ? (subtotalAmount * appliedCoupon.value) / 100
                : appliedCoupon.value;
            totalAmount -= discountAmount;
        }
        
        subtotal.textContent = `ETB ${subtotalAmount.toFixed(2)}`;
        shipping.textContent = `ETB ${shippingAmount.toFixed(2)}`;
        tax.textContent = `ETB ${taxAmount.toFixed(2)}`;
        total.textContent = `ETB ${Math.max(0, totalAmount).toFixed(2)}`;
    }
    
    function calculateShipping(subtotal) {
        // Free shipping over ETB 1000
        if (subtotal >= 1000) return 0;
        
        // Calculate shipping based on number of unique sellers
        const uniqueSellers = new Set(cart.map(item => item.sellerId));
        return uniqueSellers.size * 50; // ETB 50 per seller
    }
    
    function updateQuantity(itemId, newQuantity) {
        if (newQuantity < 1) {
            showRemoveModal(itemId);
            return;
        }
        
        const item = cart.find(item => item.id === itemId);
        if (item) {
            item.quantity = newQuantity;
            saveCart();
            renderCart();
            updateSummary();
        }
    }
    
    function showRemoveModal(itemId) {
        currentItemId = itemId;
        const item = cart.find(item => item.id === itemId);
        
        if (item) {
            document.getElementById('removeItemPreview').innerHTML = `
                <img src="${item.image}" alt="${item.title}">
                <div class="item-preview-info">
                    <h4>${item.title}</h4>
                    <div class="price">ETB ${item.price.toFixed(2)}</div>
            </div>
            `;
        }
        
        removeModal.classList.add('show');
    }
    
    function removeItem(itemId) {
        cart = cart.filter(item => item.id !== itemId);
        saveCart();
        renderCart();
            updateSummary();
        removeModal.classList.remove('show');
    }
    
    function clearCart() {
        if (confirm('Are you sure you want to clear your cart?')) {
            cart = [];
            saveCart();
            renderCart();
            updateSummary();
        }
    }
    
    function applyCoupon() {
        const code = couponCode.value.trim();
        if (!code) return;
        
        // Simulate coupon validation
        const coupons = {
            'WELCOME10': { type: 'percentage', value: 10, description: '10% off' },
            'SAVE50': { type: 'fixed', value: 50, description: 'ETB 50 off' },
            'FREESHIP': { type: 'shipping', value: 0, description: 'Free shipping' }
        };
        
        if (coupons[code]) {
            appliedCoupon = coupons[code];
            couponMessage.textContent = `Coupon applied: ${appliedCoupon.description}`;
            couponMessage.className = 'coupon-message success';
            updateSummary();
            } else {
            couponMessage.textContent = 'Invalid coupon code';
            couponMessage.className = 'coupon-message error';
        }
    }
    
    function proceedToCheckout() {
        if (cart.length === 0) {
            alert('Your cart is empty');
            return;
        }
        
        // Save cart data for checkout
        localStorage.setItem('checkoutCart', JSON.stringify(cart));
        localStorage.setItem('appliedCoupon', JSON.stringify(appliedCoupon));
        
        // Redirect to checkout page
        window.location.href = 'checkout.html';
    }
    
    async function loadRecommendedProducts() {
        try {
            // Simulate loading recommended products
            const mockProducts = [
                { id: 1, title: 'Wireless Headphones', price: 299.99, image: 'images/headphones.jpg' },
                { id: 2, title: 'Smart Watch', price: 599.99, image: 'images/smartwatch.jpg' },
                { id: 3, title: 'Bluetooth Speaker', price: 199.99, image: 'images/speaker.jpg' },
                { id: 4, title: 'Phone Case', price: 49.99, image: 'images/phonecase.jpg' }
            ];
            
            recommendedProducts.innerHTML = mockProducts.map(product => `
                <div class="recommended-product" onclick="addToCart(${product.id})">
                    <img src="${product.image}" alt="${product.title}">
                    <h4>${product.title}</h4>
                    <div class="price">ETB ${product.price.toFixed(2)}</div>
                </div>
            `).join('');
        } catch (error) {
            console.error('Error loading recommended products:', error);
        }
    }
    
    function addToCart(productId) {
        // This would normally fetch product details from API
        const product = {
            id: productId,
            title: 'Sample Product',
            price: 99.99,
            image: 'images/default-product.png',
            seller: 'Sample Seller',
            sellerId: 1,
            location: 'Addis Ababa',
            quantity: 1
        };
        
        const existingItem = cart.find(item => item.id === productId);
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push(product);
        }
        
        saveCart();
        renderCart();
        updateSummary();
        
        // Show success message
        alert('Product added to cart!');
    }
    
    // Make functions globally available
    window.updateQuantity = updateQuantity;
    window.showRemoveModal = showRemoveModal;
    window.addToCart = addToCart;
    
    // Event listeners for modals
    document.getElementById('confirmRemoveBtn').addEventListener('click', () => {
        if (currentItemId) {
            removeItem(currentItemId);
        }
    });
    
    document.getElementById('cancelRemoveBtn').addEventListener('click', () => {
        removeModal.classList.remove('show');
    });
});