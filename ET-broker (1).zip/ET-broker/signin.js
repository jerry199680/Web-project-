// Signin Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const signinForm = document.getElementById('signinForm');
    const passwordInput = document.getElementById('password');
    const passwordToggle = document.getElementById('passwordToggle');
    const forgotPasswordLink = document.getElementById('forgotPasswordLink');
    const forgotPasswordModal = document.getElementById('forgotPasswordModal');
    const closeForgotModal = document.getElementById('closeForgotModal');
    const forgotPasswordForm = document.getElementById('forgotPasswordForm');
    const successModal = document.getElementById('successModal');
    const continueBtn = document.getElementById('continueBtn');
    const submitBtn = document.getElementById('submitBtn');
    const adminPasscodeGroup = document.getElementById('adminPasscodeGroup');

    // Password toggle functionality
    function togglePasswordVisibility(input, toggle) {
        const isPassword = input.type === 'password';
        input.type = isPassword ? 'text' : 'password';
        toggle.querySelector('i').className = isPassword ? 'fas fa-eye-slash' : 'fas fa-eye';
    }

    // Form validation
    function validateForm() {
        let isValid = true;
        const formData = new FormData(signinForm);

        // Clear previous errors
        clearAllErrors();

        // Validate identifier (email or phone)
        const identifier = formData.get('identifier');
        if (!identifier || identifier.trim().length === 0) {
            showError('identifier-error', 'Please enter your email or phone number');
            isValid = false;
        }

        // Validate password
        const password = formData.get('password');
        if (!password || password.length === 0) {
            showError('password-error', 'Please enter your password');
            isValid = false;
        }

        // Validate admin passcode if admin role is detected
        const role = formData.get('role');
        if (role === 'admin') {
            const adminPasscode = formData.get('adminPasscode');
            if (!adminPasscode) {
                showError('adminPasscode-error', 'Admin passcode is required');
            isValid = false;
            }
        }

        return isValid;
    }

    // Show error message
    function showError(errorId, message) {
        const errorElement = document.getElementById(errorId);
        if (errorElement) {
            errorElement.textContent = message;
            errorElement.classList.add('show');
        }
        
        // Add error class to parent form group
        const formGroup = errorElement?.closest('.form-group');
        if (formGroup) {
            formGroup.classList.add('error');
        }
    }

    // Hide error message
    function hideError(errorId) {
        const errorElement = document.getElementById(errorId);
        if (errorElement) {
            errorElement.classList.remove('show');
        }
        
        // Remove error class from parent form group
        const formGroup = errorElement?.closest('.form-group');
        if (formGroup) {
            formGroup.classList.remove('error');
        }
    }

    // Clear all errors
    function clearAllErrors() {
        const errorElements = document.querySelectorAll('.error-message');
        errorElements.forEach(error => {
            error.classList.remove('show');
        });
        
        const formGroups = document.querySelectorAll('.form-group');
        formGroups.forEach(group => {
            group.classList.remove('error');
        });
    }

    // Check if identifier is email or phone
    function isEmail(identifier) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(identifier);
    }

    // Check if identifier is phone
    function isPhone(identifier) {
        const phoneRegex = /^\+251[0-9]{9}$/;
        return phoneRegex.test(identifier.replace(/\s/g, ''));
    }

    // Submit signin form
    async function submitForm() {
        if (!validateForm()) {
            return;
        }

        const formData = new FormData(signinForm);
        const identifier = formData.get('identifier');
        
        // Determine if identifier is email or phone
        const loginType = isEmail(identifier) ? 'email' : 'phone';

        // Show loading state
        submitBtn.disabled = true;
        submitBtn.querySelector('.btn-text').style.display = 'none';
        submitBtn.querySelector('.btn-loading').style.display = 'flex';

        try {
            const response = await fetch('backend/api.php/users/signin', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    identifier: identifier,
                    password: formData.get('password'),
                    rememberMe: formData.get('rememberMe') === 'on',
                    loginType: loginType,
                    adminPasscode: formData.get('adminPasscode') || null
                })
            });

            const result = await response.json();

            if (result.success) {
                // Store user data and token
                localStorage.setItem('user', JSON.stringify(result.user));
                localStorage.setItem('token', result.token);
                
                // Show success modal
                successModal.classList.add('show');
                
                // Redirect based on user role
                setTimeout(() => {
                    if (result.user.role === 'admin') {
                        window.location.href = 'admin-dashboard.html';
                    } else if (result.user.role === 'seller') {
                        window.location.href = 'seller-dashboard.html';
                    } else {
                        window.location.href = 'home1.html';
                    }
                }, 2000);
            } else {
                // Show error messages
                if (result.errors) {
                    Object.keys(result.errors).forEach(field => {
                        showError(`${field}-error`, result.errors[field]);
                    });
                } else {
                    showError('identifier-error', result.message || 'Invalid credentials');
                }
            }
        } catch (error) {
            console.error('Signin error:', error);
            showError('identifier-error', 'An error occurred. Please try again.');
        } finally {
            // Hide loading state
            submitBtn.disabled = false;
            submitBtn.querySelector('.btn-text').style.display = 'block';
            submitBtn.querySelector('.btn-loading').style.display = 'none';
        }
    }

    // Submit forgot password form
    async function submitForgotPassword() {
        const email = document.getElementById('resetEmail').value;
        
        if (!email) {
            showError('resetEmail-error', 'Please enter your email address');
            return;
        }

        try {
            const response = await fetch('backend/api.php/users/forgot-password', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email })
            });

            const result = await response.json();

            if (result.success) {
                alert('Password reset link sent to your email');
                forgotPasswordModal.classList.remove('show');
                forgotPasswordForm.reset();
            } else {
                showError('resetEmail-error', result.message || 'Failed to send reset link');
            }
        } catch (error) {
            console.error('Forgot password error:', error);
            showError('resetEmail-error', 'An error occurred. Please try again.');
        }
    }

    // Check if user is admin (for showing admin passcode field)
    async function checkUserRole(identifier) {
        try {
            const response = await fetch('backend/api.php/users/check-role', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ identifier })
            });

            const result = await response.json();
            
            if (result.success && result.role === 'admin') {
                adminPasscodeGroup.style.display = 'block';
                // Add hidden input for role
                if (!document.querySelector('input[name="role"]')) {
                    const roleInput = document.createElement('input');
                    roleInput.type = 'hidden';
                    roleInput.name = 'role';
                    roleInput.value = 'admin';
                    signinForm.appendChild(roleInput);
                }
            } else {
                adminPasscodeGroup.style.display = 'none';
                const roleInput = document.querySelector('input[name="role"]');
                if (roleInput) {
                    roleInput.remove();
                }
            }
        } catch (error) {
            console.error('Role check error:', error);
        }
    }

    // Event Listeners
    passwordToggle.addEventListener('click', () => {
        togglePasswordVisibility(passwordInput, passwordToggle);
    });

    // Real-time role checking
    const identifierInput = document.getElementById('identifier');
    let roleCheckTimeout;

    identifierInput.addEventListener('input', function() {
        clearTimeout(roleCheckTimeout);
        const identifier = this.value.trim();
        
        if (identifier.length > 3) {
            roleCheckTimeout = setTimeout(() => {
                checkUserRole(identifier);
            }, 500);
        } else {
            adminPasscodeGroup.style.display = 'none';
        }
    });

    // Form submission
    signinForm.addEventListener('submit', function(e) {
        e.preventDefault();
        submitForm();
    });

    // Forgot password
    forgotPasswordLink.addEventListener('click', function(e) {
        e.preventDefault();
        forgotPasswordModal.classList.add('show');
    });

    closeForgotModal.addEventListener('click', function() {
        forgotPasswordModal.classList.remove('show');
        forgotPasswordForm.reset();
        clearAllErrors();
    });

    forgotPasswordForm.addEventListener('submit', function(e) {
        e.preventDefault();
        submitForgotPassword();
    });

    // Close modals when clicking outside
    forgotPasswordModal.addEventListener('click', function(e) {
        if (e.target === forgotPasswordModal) {
            forgotPasswordModal.classList.remove('show');
            forgotPasswordForm.reset();
            clearAllErrors();
        }
    });

    successModal.addEventListener('click', function(e) {
        if (e.target === successModal) {
            successModal.classList.remove('show');
        }
    });

    // Continue button
    continueBtn.addEventListener('click', function() {
        successModal.classList.remove('show');
        const user = JSON.parse(localStorage.getItem('user'));
        if (user) {
            if (user.role === 'admin') {
                window.location.href = 'admin-dashboard.html';
            } else if (user.role === 'seller') {
                window.location.href = 'seller-dashboard.html';
            } else {
                window.location.href = 'home1.html';
            }
        }
    });

    // Google sign in
    document.querySelector('.google-btn').addEventListener('click', function() {
        // Implement Google OAuth
        alert('Google sign in will be implemented soon');
    });

    // Check if user is already logged in
    const user = localStorage.getItem('user');
    const token = localStorage.getItem('token');
    
    if (user && token) {
        // User is already logged in, redirect to appropriate dashboard
        const userData = JSON.parse(user);
        if (userData.role === 'admin') {
            window.location.href = 'admin-dashboard.html';
        } else if (userData.role === 'seller') {
            window.location.href = 'seller-dashboard.html';
        } else {
            window.location.href = 'home1.html';
        }
    }
});