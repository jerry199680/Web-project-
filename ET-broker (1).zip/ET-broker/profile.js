document.addEventListener('DOMContentLoaded', function() {
    // Tab switching logic
    const navLinks = document.querySelectorAll('.profile-nav-link');
    const tabContents = document.querySelectorAll('.tab-content');
    const ctaButton = document.querySelector('.btn-primary[data-tab-target="create-seller"]');
    
    function switchTab(tabId) {
        // Hide all tabs
        tabContents.forEach(content => {
            content.classList.remove('active');
            if (content.id === tabId) {
                content.classList.add('active');
                // Add animation to the active tab
                content.classList.add('fade-in');
                setTimeout(() => content.classList.remove('fade-in'), 500);
            }
        });
        
        // Update nav links
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.dataset.tab === tabId) {
                link.classList.add('active');
            }
        });
    }
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const tabId = this.dataset.tab;
            switchTab(tabId);
            window.location.hash = tabId;
        });
    });
    
    if (ctaButton) {
        ctaButton.addEventListener('click', function(e) {
            e.preventDefault();
            const tabId = this.dataset.tabTarget;
            switchTab(tabId);
            window.location.hash = tabId;
        });
    }
    
    // Check for hash on page load
    const initialTab = window.location.hash.substring(1);
    if (initialTab) {
        switchTab(initialTab);
    } else {
        // Default to first tab if no hash is present
        const firstTabId = navLinks[0]?.dataset.tab;
        if (firstTabId) switchTab(firstTabId);
    }
    
    // Load user profile data
    loadUserProfile();
    
    // Avatar upload functionality
    const avatarUpload = document.getElementById('avatarUpload');
    if (avatarUpload) {
        avatarUpload.addEventListener('change', handleAvatarUpload);
    }
    
    // Edit profile button
    const editProfileBtn = document.getElementById('editProfileBtn');
    if (editProfileBtn) {
        editProfileBtn.addEventListener('click', function() {
            // Show edit profile modal or switch to edit profile tab
            const editProfileModal = document.createElement('div');
            editProfileModal.className = 'modal fade-in';
            editProfileModal.innerHTML = `
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>Edit Profile</h3>
                        <button class="close-btn"><i class="fas fa-times"></i></button>
                    </div>
                    <div class="modal-body">
                        <form id="editProfileForm">
                            <div class="form-group">
                                <label for="editName">Name</label>
                                <input type="text" id="editName" value="${document.getElementById('userName').textContent}">
                            </div>
                            <div class="form-group">
                                <label for="editEmail">Email</label>
                                <input type="email" id="editEmail" value="${document.getElementById('userEmail').textContent}">
                            </div>
                            <div class="form-group">
                                <label for="editPhone">Phone</label>
                                <input type="tel" id="editPhone" placeholder="Your phone number">
                            </div>
                            <div class="form-group">
                                <label for="editBio">Bio</label>
                                <textarea id="editBio" rows="4" placeholder="Tell us about yourself"></textarea>
                            </div>
                            <button type="submit" class="btn-primary">Save Changes</button>
                        </form>
                    </div>
                </div>
            `;
            document.body.appendChild(editProfileModal);
            
            // Close modal functionality
            const closeBtn = editProfileModal.querySelector('.close-btn');
            closeBtn.addEventListener('click', function() {
                editProfileModal.classList.add('fade-out');
                setTimeout(() => editProfileModal.remove(), 300);
            });
            
            // Form submission
            const editProfileForm = document.getElementById('editProfileForm');
            editProfileForm.addEventListener('submit', function(e) {
                e.preventDefault();
                updateUserProfile();
                editProfileModal.classList.add('fade-out');
                setTimeout(() => editProfileModal.remove(), 300);
            });
        });
    }
});

// Load user profile data from API
async function loadUserProfile() {
    try {
        const response = await fetch('/api/profile.php');
        if (response.ok) {
            const userData = await response.json();
            
            // Update profile UI with user data
            document.getElementById('userName').textContent = userData.name;
            document.getElementById('userEmail').textContent = userData.email;
            
            if (userData.avatar_url) {
                document.getElementById('userAvatar').src = userData.avatar_url;
            }
            
            // Update stats if available
            if (userData.stats) {
                document.getElementById('listingsCount').textContent = userData.stats.listings || 0;
                document.getElementById('ordersCount').textContent = userData.stats.orders || 0;
                document.getElementById('reviewsCount').textContent = userData.stats.reviews || 0;
            }
            
            // Store user data in localStorage for other pages
            localStorage.setItem('user_data', JSON.stringify(userData));
            
            // Show notification if there are unread messages or notifications
            if (userData.unread_notifications > 0) {
                window.notificationSystem.addNotification(
                    `You have ${userData.unread_notifications} unread notifications`, 
                    'info'
                );
            }
            
            if (userData.unread_messages > 0) {
                window.notificationSystem.addNotification(
                    `You have ${userData.unread_messages} unread messages`, 
                    'info'
                );
            }
        } else {
            // Handle error
            window.notificationSystem.addNotification(
                'Failed to load profile data. Please try again later.', 
                'error'
            );
        }
    } catch (error) {
        console.error('Error loading profile:', error);
        window.notificationSystem.addNotification(
            'An error occurred while loading your profile.', 
            'error'
        );
    }
}

// Handle avatar upload
async function handleAvatarUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    // Validate file type
    const validTypes = ['image/jpeg', 'image/png', 'image/gif'];
    if (!validTypes.includes(file.type)) {
        window.notificationSystem.addNotification(
            'Please select a valid image file (JPEG, PNG, or GIF).', 
            'error'
        );
        return;
    }
    
    // Validate file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
        window.notificationSystem.addNotification(
            'Image size should be less than 2MB.', 
            'error'
        );
        return;
    }
    
    // Show loading state
    const avatar = document.getElementById('userAvatar');
    const originalSrc = avatar.src;
    avatar.classList.add('loading');
    
    try {
        // Create form data for upload
        const formData = new FormData();
        formData.append('avatar', file);
        
        // Upload to server
        const response = await fetch('/api/upload_avatar.php', {
            method: 'POST',
            body: formData
        });
        
        if (response.ok) {
            const result = await response.json();
            
            // Update avatar with new image
            avatar.src = result.avatar_url;
            
            // Show success notification
            window.notificationSystem.addNotification(
                'Profile picture updated successfully!', 
                'success'
            );
            
            // Update user data in localStorage
            const userData = JSON.parse(localStorage.getItem('user_data') || '{}');
            userData.avatar_url = result.avatar_url;
            localStorage.setItem('user_data', JSON.stringify(userData));
        } else {
            // Revert to original image on error
            avatar.src = originalSrc;
            
            // Show error notification
            window.notificationSystem.addNotification(
                'Failed to update profile picture. Please try again.', 
                'error'
            );
        }
    } catch (error) {
        console.error('Error uploading avatar:', error);
        
        // Revert to original image on error
        avatar.src = originalSrc;
        
        // Show error notification
        window.notificationSystem.addNotification(
            'An error occurred while uploading your profile picture.', 
            'error'
        );
    } finally {
        // Remove loading state
        avatar.classList.remove('loading');
    }
}

// Update user profile
async function updateUserProfile() {
    const name = document.getElementById('editName').value;
    const email = document.getElementById('editEmail').value;
    const phone = document.getElementById('editPhone').value;
    const bio = document.getElementById('editBio').value;
    
    try {
        const response = await fetch('/api/update_profile.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                name,
                email,
                phone,
                bio
            })
        });
        
        if (response.ok) {
            // Update UI
            document.getElementById('userName').textContent = name;
            document.getElementById('userEmail').textContent = email;
            
            // Update localStorage
            const userData = JSON.parse(localStorage.getItem('user_data') || '{}');
            userData.name = name;
            userData.email = email;
            userData.phone = phone;
            userData.bio = bio;
            localStorage.setItem('user_data', JSON.stringify(userData));
            
            // Show success notification
            window.notificationSystem.addNotification(
                'Profile updated successfully!', 
                'success'
            );
        } else {
            // Show error notification
            window.notificationSystem.addNotification(
                'Failed to update profile. Please try again.', 
                'error'
            );
        }
    } catch (error) {
        console.error('Error updating profile:', error);
        
        // Show error notification
        window.notificationSystem.addNotification(
            'An error occurred while updating your profile.', 
            'error'
        );
    }
}
