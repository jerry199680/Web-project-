<?php
session_start(); // Start the session at the very beginning
header('Content-Type: application/json');

// Connect to the database
require_once 'db_connect.php';

// --- Response Function ---
function send_response($status, $message, $data = []) {
    echo json_encode(['status' => $status, 'message' => $message, 'data' => $data]);
    exit();
}

// Check for DB connection errors
if ($conn->connect_error) {
    send_response('error', 'Database connection failed: ' . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_response('error', 'Invalid request method.');
}

// Get and sanitize input
$role = filter_input(INPUT_POST, 'role', FILTER_SANITIZE_STRING) ?? 'user';
$identifier = filter_input(INPUT_POST, 'identifier', FILTER_SANITIZE_STRING) ?? '';
$password = $_POST['password'] ?? ''; // Don't sanitize password as it may contain special characters
$passcode = filter_input(INPUT_POST, 'passcode', FILTER_SANITIZE_STRING) ?? '';
$remember = isset($_POST['remember_me']) ? true : false;

// Validate required fields
if (empty($identifier) || empty($password)) {
    send_response('error', 'Identifier and password are required.');
}

// --- Authentication Logic ---
if ($role === 'admin') {
    if (empty($passcode)) {
        send_response('error', 'Admin passcode is required.', ['field' => 'admin-passcode']);
    }

    $stmt = $conn->prepare("SELECT * FROM admins WHERE email = ? AND passcode = ?");
    $stmt->bind_param("ss", $identifier, $passcode);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $admin = $result->fetch_assoc();
        if (password_verify($password, $admin['password_hash'])) {
            // Store admin info in session
            $_SESSION['user_id'] = $admin['id'];
            $_SESSION['fullname'] = $admin['fullname'];
            $_SESSION['email'] = $admin['email'];
            $_SESSION['role'] = 'admin';
            $_SESSION['last_activity'] = time();

            // Set remember me cookie if requested (30 days)
            if ($remember) {
                $token = bin2hex(random_bytes(32));
                setcookie('remember_token', $token, time() + 30 * 24 * 60 * 60, '/', '', true, true);
                
                // In a real app, you would store this token in the database
                // associated with the admin's ID and check it on subsequent visits
            }

            send_response('success', 'Admin login successful.', ['role' => 'admin']);
        } else {
            send_response('error', 'Invalid credentials.', ['field' => 'password']);
        }
    } else {
        send_response('error', 'Invalid credentials or passcode.', ['field' => 'identifier']);
    }
    $stmt->close();

} else { // 'user' role
    // Check if input is email or phone
    $is_email = filter_var($identifier, FILTER_VALIDATE_EMAIL);
    
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? OR phone = ?");
    $stmt->bind_param("ss", $identifier, $identifier);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password_hash'])) {
            // Store user info in session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['fullname'] = $user['fullname'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['avatar'] = $user['avatar'];
            $_SESSION['is_seller'] = (bool)$user['is_seller'];
            $_SESSION['role'] = 'user';
            $_SESSION['last_activity'] = time();

            // Set remember me cookie if requested (30 days)
            if ($remember) {
                $token = bin2hex(random_bytes(32));
                setcookie('remember_token', $token, time() + 30 * 24 * 60 * 60, '/', '', true, true);
                
                // In a real app, you would store this token in the database
                // associated with the user's ID and check it on subsequent visits
            }

            // Send back only essential, non-sensitive data
            $user_data = [
                'fullname' => $user['fullname'],
                'email' => $user['email'],
                'avatar' => $user['avatar'],
                'is_seller' => (bool)$user['is_seller'],
                'role' => 'user'
            ];
            send_response('success', 'Login successful! Redirecting...', $user_data);
        } else {
            send_response('error', 'Invalid email/phone or password.', ['field' => 'password']);
        }
    } else {
        send_response('error', 'Invalid email/phone or password.', ['field' => 'identifier']);
    }
    $stmt->close();
}

$conn->close();
?>
