// Seller Dashboard JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const navLinks = document.querySelectorAll('.nav-link');
    const sellerSections = document.querySelectorAll('.seller-section');
    
    // Charts
    let salesChart = null;
    let productsChart = null;
    let salesTrendsChart = null;
    let demographicsChart = null;
    let revenueBreakdownChart = null;
    let earningsChart = null;
    
    // State
    let currentSection = 'dashboard';
    let currentPage = 1;
    let currentFilters = {};
    
    // Initialize
    setupEventListeners();
    loadDashboardData();
    
    function setupEventListeners() {
        // Navigation
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.dataset.section;
                switchSection(section);
            });
        });
        
        // Filter changes
        setupFilterListeners();
        
        // Settings tabs
        setupSettingsTabs();
        
        // Message filters
        setupMessageFilters();
    }
    
    function setupFilterListeners() {
        // Product filters
        const productSearch = document.getElementById('productSearch');
        const productStatusFilter = document.getElementById('productStatusFilter');
        const productCategoryFilter = document.getElementById('productCategoryFilter');
        
        if (productSearch) productSearch.addEventListener('input', debounce(() => loadProducts(), 500));
        if (productStatusFilter) productStatusFilter.addEventListener('change', () => loadProducts());
        if (productCategoryFilter) productCategoryFilter.addEventListener('change', () => loadProducts());
        
        // Order filters
        const orderSearch = document.getElementById('orderSearch');
        const orderStatusFilter = document.getElementById('orderStatusFilter');
        const orderDateFrom = document.getElementById('orderDateFrom');
        const orderDateTo = document.getElementById('orderDateTo');
        
        if (orderSearch) orderSearch.addEventListener('input', debounce(() => loadOrders(), 500));
        if (orderStatusFilter) orderStatusFilter.addEventListener('change', () => loadOrders());
        if (orderDateFrom) orderDateFrom.addEventListener('change', () => loadOrders());
        if (orderDateTo) orderDateTo.addEventListener('change', () => loadOrders());
        
        // Sales period change
        const salesPeriod = document.getElementById('salesPeriod');
        if (salesPeriod) {
            salesPeriod.addEventListener('change', () => updateSalesChart());
        }
    }
    
    function setupSettingsTabs() {
        const tabBtns = document.querySelectorAll('.tab-btn');
        const tabContents = document.querySelectorAll('.tab-content');
        
        tabBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const tabId = btn.dataset.tab;
                
                // Update active tab
                tabBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                
                // Update active content
                tabContents.forEach(content => {
                    content.classList.remove('active');
                    if (content.id === tabId) {
                        content.classList.add('active');
                    }
                });
            });
        });
    }
    
    function setupMessageFilters() {
        const filterBtns = document.querySelectorAll('.filter-btn');
        
        filterBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                filterBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                
                const filter = btn.dataset.filter;
                filterMessages(filter);
            });
        });
    }
    
    function switchSection(section) {
        // Update navigation
        navLinks.forEach(link => {
            link.parentElement.classList.remove('active');
            if (link.dataset.section === section) {
                link.parentElement.classList.add('active');
            }
        });
        
        // Update sections
        sellerSections.forEach(sec => {
            sec.classList.remove('active');
            if (sec.id === section) {
                sec.classList.add('active');
            }
        });
        
        currentSection = section;
        
        // Load section data
        switch (section) {
            case 'dashboard':
                loadDashboardData();
                break;
            case 'products':
                loadProducts();
                break;
            case 'orders':
                loadOrders();
                break;
            case 'analytics':
                loadAnalytics();
                break;
            case 'messages':
                loadMessages();
                break;
            case 'reviews':
                loadReviews();
                break;
            case 'store':
                loadStoreSettings();
                break;
            case 'earnings':
                loadEarnings();
                break;
        }
    }
    
    async function loadDashboardData() {
        try {
            // Load stats
            const statsResponse = await fetch('backend/api.php/seller/stats');
            const stats = await statsResponse.json();
            
            if (stats.success) {
                updateStatsCards(stats.data);
            }
            
            // Load recent activity
            const activityResponse = await fetch('backend/api.php/seller/activity');
            const activity = await activityResponse.json();
            
            if (activity.success) {
                updateRecentActivity(activity.data);
            }
            
            // Initialize charts
            initializeCharts();
            
        } catch (error) {
            console.error('Error loading dashboard data:', error);
        }
    }
    
    function updateStatsCards(data) {
        document.getElementById('totalProducts').textContent = data.totalProducts || 0;
        document.getElementById('totalOrders').textContent = data.totalOrders || 0;
        document.getElementById('totalRevenue').textContent = `ETB ${(data.totalRevenue || 0).toFixed(2)}`;
        document.getElementById('totalViews').textContent = data.totalViews || 0;
        document.getElementById('avgRating').textContent = (data.avgRating || 0).toFixed(1);
        document.getElementById('pendingOrders').textContent = data.pendingOrders || 0;
    }
    
    function updateRecentActivity(activities) {
        const container = document.getElementById('recentActivity');
        if (!container) return;
        
        container.innerHTML = activities.map(activity => `
            <div class="activity-item">
                <div class="activity-icon">
                    <i class="fas ${getActivityIcon(activity.type)}"></i>
                </div>
                <div class="activity-content">
                    <div class="activity-title">${activity.title}</div>
                    <div class="activity-description">${activity.description}</div>
                </div>
                <div class="activity-time">${timeAgo(activity.created_at)}</div>
            </div>
        `).join('');
    }
    
    function getActivityIcon(type) {
        const icons = {
            'product_created': 'fa-box',
            'order_received': 'fa-shopping-cart',
            'review_received': 'fa-star',
            'payment_received': 'fa-credit-card',
            'message_received': 'fa-comment',
            'default': 'fa-circle'
        };
        return icons[type] || icons.default;
    }
    
    function timeAgo(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const diffInSeconds = Math.floor((now - date) / 1000);
        
        if (diffInSeconds < 60) return 'Just now';
        if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
        if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
        return `${Math.floor(diffInSeconds / 86400)}d ago`;
    }
    
    function initializeCharts() {
        // Sales Chart
        const salesCtx = document.getElementById('salesChart');
        if (salesCtx) {
            updateSalesChart();
        }
        
        // Products Chart
        const productsCtx = document.getElementById('productsChart');
        if (productsCtx) {
            updateProductsChart();
        }
    }
    
    async function updateSalesChart() {
        const period = document.getElementById('salesPeriod')?.value || 30;
        const ctx = document.getElementById('salesChart');
        if (!ctx) return;
        
        try {
            const response = await fetch(`backend/api.php/seller/sales?period=${period}`);
            const data = await response.json();
            
            if (salesChart) {
                salesChart.destroy();
            }
            
            salesChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.labels || [],
                    datasets: [{
                        label: 'Sales',
                        data: data.values || [],
                        borderColor: '#00796b',
                        backgroundColor: 'rgba(0, 121, 107, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return 'ETB ' + value.toLocaleString();
                                }
                            }
                        }
                    }
                }
            });
        } catch (error) {
            console.error('Error loading sales chart:', error);
        }
    }
    
    async function updateProductsChart() {
        const ctx = document.getElementById('productsChart');
        if (!ctx) return;
        
        try {
            const response = await fetch('backend/api.php/seller/top-products');
            const data = await response.json();
            
            if (productsChart) {
                productsChart.destroy();
            }
            
            productsChart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: data.labels || [],
                    datasets: [{
                        data: data.values || [],
                        backgroundColor: [
                            '#00796b',
                            '#4db6ac',
                            '#80cbc4',
                            '#b2dfdb',
                            '#e0f2f1'
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        } catch (error) {
            console.error('Error loading products chart:', error);
        }
    }
    
    async function loadProducts() {
        const search = document.getElementById('productSearch')?.value || '';
        const status = document.getElementById('productStatusFilter')?.value || '';
        const category = document.getElementById('productCategoryFilter')?.value || '';
        
        try {
            const params = new URLSearchParams({
                search,
                status,
                category,
                page: currentPage
            });
            
            const response = await fetch(`backend/api.php/seller/products?${params}`);
            const data = await response.json();
            
            if (data.success) {
                updateProductsTable(data.products);
                updatePagination('productsPagination', data.pagination);
            }
        } catch (error) {
            console.error('Error loading products:', error);
        }
    }
    
    function updateProductsTable(products) {
        const tbody = document.querySelector('#productsTable tbody');
        if (!tbody) return;
        
        tbody.innerHTML = products.map(product => `
            <tr>
                <td><img src="${product.main_image || 'images/default-product.png'}" alt="${product.title}"></td>
                <td>${product.title}</td>
                <td>${product.category_name || '-'}</td>
                <td>ETB ${product.price.toFixed(2)}</td>
                <td>${product.qty}</td>
                <td>${product.views || 0}</td>
                <td><span class="status-badge ${product.status}">${product.status}</span></td>
                <td>${formatDate(product.created_at)}</td>
                <td>
                    <div class="action-buttons">
                        <button class="action-btn view" onclick="viewProduct(${product.id})">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="action-btn edit" onclick="editProduct(${product.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="action-btn delete" onclick="deleteProduct(${product.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }
    
    async function loadOrders() {
        const search = document.getElementById('orderSearch')?.value || '';
        const status = document.getElementById('orderStatusFilter')?.value || '';
        const dateFrom = document.getElementById('orderDateFrom')?.value || '';
        const dateTo = document.getElementById('orderDateTo')?.value || '';
        
        try {
            const params = new URLSearchParams({
                search,
                status,
                date_from: dateFrom,
                date_to: dateTo,
                page: currentPage
            });
            
            const response = await fetch(`backend/api.php/seller/orders?${params}`);
            const data = await response.json();
            
            if (data.success) {
                updateOrdersTable(data.orders);
                updatePagination('ordersPagination', data.pagination);
            }
        } catch (error) {
            console.error('Error loading orders:', error);
        }
    }
    
    function updateOrdersTable(orders) {
        const tbody = document.querySelector('#ordersTable tbody');
        if (!tbody) return;
        
        tbody.innerHTML = orders.map(order => `
            <tr>
                <td>${order.order_number}</td>
                <td>${order.customer_name}</td>
                <td>${order.items_count} items</td>
                <td>ETB ${order.total_amount.toFixed(2)}</td>
                <td><span class="status-badge ${order.status}">${order.status}</span></td>
                <td>${formatDate(order.created_at)}</td>
                <td>
                    <div class="action-buttons">
                        <button class="action-btn view" onclick="viewOrder(${order.id})">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="action-btn edit" onclick="updateOrderStatus(${order.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }
    
    async function loadAnalytics() {
        try {
            // Load analytics data and charts
            updateSalesTrendsChart();
            updateTopProductsList();
            updateDemographicsChart();
            updateRevenueBreakdownChart();
        } catch (error) {
            console.error('Error loading analytics:', error);
        }
    }
    
    function updateSalesTrendsChart() {
        const ctx = document.getElementById('salesTrendsChart');
        if (!ctx) return;
        
        // Mock data for now
        if (salesTrendsChart) {
            salesTrendsChart.destroy();
        }
        
        salesTrendsChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Sales',
                    data: [12000, 19000, 15000, 25000, 22000, 30000],
                    borderColor: '#00796b',
                    backgroundColor: 'rgba(0, 121, 107, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }
    
    function updateTopProductsList() {
        const container = document.getElementById('topProductsList');
        if (!container) return;
        
        // Mock data
        const topProducts = [
            { id: 1, title: 'Wireless Headphones', sales: 45, revenue: 13500 },
            { id: 2, title: 'Smart Watch', sales: 32, revenue: 19200 },
            { id: 3, title: 'Bluetooth Speaker', sales: 28, revenue: 8400 },
            { id: 4, title: 'Phone Case', sales: 67, revenue: 3350 }
        ];
        
        container.innerHTML = topProducts.map(product => `
            <div class="top-product-item">
                <img src="images/default-product.png" alt="${product.title}" class="top-product-image">
                <div class="top-product-info">
                    <div class="top-product-title">${product.title}</div>
                    <div class="top-product-stats">${product.sales} sales • ETB ${product.revenue.toLocaleString()}</div>
                </div>
            </div>
        `).join('');
    }
    
    function updateDemographicsChart() {
        const ctx = document.getElementById('demographicsChart');
        if (!ctx) return;
        
        if (demographicsChart) {
            demographicsChart.destroy();
        }
        
        demographicsChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['18-25', '26-35', '36-45', '46-55', '55+'],
                datasets: [{
                    data: [25, 35, 20, 15, 5],
                    backgroundColor: [
                        '#00796b',
                        '#4db6ac',
                        '#80cbc4',
                        '#b2dfdb',
                        '#e0f2f1'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }
    
    function updateRevenueBreakdownChart() {
        const ctx = document.getElementById('revenueBreakdownChart');
        if (!ctx) return;
        
        if (revenueBreakdownChart) {
            revenueBreakdownChart.destroy();
        }
        
        revenueBreakdownChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Electronics', 'Clothing', 'Home', 'Sports', 'Books'],
                datasets: [{
                    label: 'Revenue',
                    data: [45000, 32000, 28000, 15000, 8000],
                    backgroundColor: '#00796b'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'ETB ' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    }
    
    async function loadMessages() {
        try {
            const response = await fetch('backend/api.php/seller/messages');
            const data = await response.json();
            
            if (data.success) {
                updateMessagesList(data.messages);
            }
        } catch (error) {
            console.error('Error loading messages:', error);
        }
    }
    
    function updateMessagesList(messages) {
        const container = document.getElementById('messagesList');
        if (!container) return;
        
        container.innerHTML = messages.map(message => `
            <div class="message-item ${message.unread ? 'unread' : ''}" onclick="selectMessage(${message.id})">
                <div class="message-header">
                    <span class="message-sender">${message.sender_name}</span>
                    <span class="message-time">${timeAgo(message.created_at)}</span>
                </div>
                <div class="message-preview">${message.preview}</div>
            </div>
        `).join('');
    }
    
    function filterMessages(filter) {
        const messageItems = document.querySelectorAll('.message-item');
        
        messageItems.forEach(item => {
            if (filter === 'all' || 
                (filter === 'unread' && item.classList.contains('unread')) ||
                (filter === 'important' && item.classList.contains('important'))) {
                item.style.display = 'block';
            } else {
                item.style.display = 'none';
            }
        });
    }
    
    async function loadReviews() {
        try {
            const response = await fetch('backend/api.php/seller/reviews');
            const data = await response.json();
            
            if (data.success) {
                updateReviewsSummary(data.summary);
                updateReviewsList(data.reviews);
            }
        } catch (error) {
            console.error('Error loading reviews:', error);
        }
    }
    
    function updateReviewsSummary(summary) {
        document.getElementById('overallRating').textContent = summary.avgRating.toFixed(1);
        document.getElementById('totalReviews').textContent = summary.totalReviews;
        
        // Update rating breakdown
        const ratingBars = document.querySelectorAll('.rating-bar');
        ratingBars.forEach((bar, index) => {
            const rating = 5 - index;
            const count = summary.ratingBreakdown[rating] || 0;
            const percentage = summary.totalReviews > 0 ? (count / summary.totalReviews) * 100 : 0;
            
            const fill = bar.querySelector('.fill');
            const countSpan = bar.querySelector('span:last-child');
            
            fill.style.width = `${percentage}%`;
            countSpan.textContent = count;
        });
    }
    
    function updateReviewsList(reviews) {
        const container = document.getElementById('reviewsList');
        if (!container) return;
        
        container.innerHTML = reviews.map(review => `
            <div class="review-item">
                <div class="review-avatar">
                    <i class="fas fa-user"></i>
                </div>
                <div class="review-content">
                    <div class="review-header">
                        <span class="review-author">${review.customer_name}</span>
                        <div class="review-rating">
                            ${'★'.repeat(review.rating)}${'☆'.repeat(5 - review.rating)}
                        </div>
                    </div>
                    <div class="review-text">${review.comment}</div>
                    <div class="review-meta">${formatDate(review.created_at)} • ${review.product_title}</div>
                </div>
            </div>
        `).join('');
    }
    
    async function loadStoreSettings() {
        try {
            const response = await fetch('backend/api.php/seller/store-settings');
            const data = await response.json();
            
            if (data.success) {
                populateStoreForm(data.settings);
            }
        } catch (error) {
            console.error('Error loading store settings:', error);
        }
    }
    
    function populateStoreForm(settings) {
        document.getElementById('storeName').value = settings.store_name || '';
        document.getElementById('storeDescription').value = settings.store_description || '';
        document.getElementById('storeLocation').value = settings.location || '';
        document.getElementById('storePhone').value = settings.phone || '';
        document.getElementById('storeEmail').value = settings.email || '';
    }
    
    async function loadEarnings() {
        try {
            const response = await fetch('backend/api.php/seller/earnings');
            const data = await response.json();
            
            if (data.success) {
                updateEarningsSummary(data.summary);
                updateEarningsChart(data.chartData);
                updatePayoutsTable(data.payouts);
            }
        } catch (error) {
            console.error('Error loading earnings:', error);
        }
    }
    
    function updateEarningsSummary(summary) {
        document.getElementById('availableBalance').textContent = summary.availableBalance.toFixed(2);
        document.getElementById('monthlyEarnings').textContent = summary.monthlyEarnings.toFixed(2);
        document.getElementById('totalEarnings').textContent = summary.totalEarnings.toFixed(2);
    }
    
    function updateEarningsChart(chartData) {
        const ctx = document.getElementById('earningsChart');
        if (!ctx) return;
        
        if (earningsChart) {
            earningsChart.destroy();
        }
        
        earningsChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: chartData.labels || [],
                datasets: [{
                    label: 'Earnings',
                    data: chartData.values || [],
                    borderColor: '#00796b',
                    backgroundColor: 'rgba(0, 121, 107, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'ETB ' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    }
    
    function updatePayoutsTable(payouts) {
        const tbody = document.getElementById('payoutsTableBody');
        if (!tbody) return;
        
        tbody.innerHTML = payouts.map(payout => `
            <tr>
                <td>${formatDate(payout.created_at)}</td>
                <td>ETB ${payout.amount.toFixed(2)}</td>
                <td>${payout.method}</td>
                <td><span class="status-badge ${payout.status}">${payout.status}</span></td>
                <td>${payout.reference}</td>
            </tr>
        `).join('');
    }
    
    function updatePagination(containerId, pagination) {
        const container = document.getElementById(containerId);
        if (!container || !pagination) return;
        
        const { current_page, total_pages, has_prev, has_next } = pagination;
        
        container.innerHTML = `
            <button ${!has_prev ? 'disabled' : ''} onclick="changePage(${current_page - 1})">
                <i class="fas fa-chevron-left"></i>
            </button>
            ${Array.from({ length: total_pages }, (_, i) => i + 1).map(page => `
                <span class="page-number ${page === current_page ? 'active' : ''}" 
                      onclick="changePage(${page})">${page}</span>
            `).join('')}
            <button ${!has_next ? 'disabled' : ''} onclick="changePage(${current_page + 1})">
                <i class="fas fa-chevron-right"></i>
            </button>
        `;
    }
    
    function changePage(page) {
        currentPage = page;
        
        switch (currentSection) {
            case 'products':
                loadProducts();
                break;
            case 'orders':
                loadOrders();
                break;
        }
    }
    
    function formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }
    
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    // Action functions
    function viewProduct(productId) {
        console.log('View product:', productId);
    }
    
    function editProduct(productId) {
        window.location.href = `upload_product.html?edit=${productId}`;
    }
    
    function deleteProduct(productId) {
        if (confirm('Are you sure you want to delete this product?')) {
            console.log('Delete product:', productId);
        }
    }
    
    function viewOrder(orderId) {
        console.log('View order:', orderId);
    }
    
    function updateOrderStatus(orderId) {
        console.log('Update order status:', orderId);
    }
    
    function selectMessage(messageId) {
        console.log('Select message:', messageId);
    }
    
    function composeMessage() {
        console.log('Compose message');
    }
    
    function exportAnalytics() {
        console.log('Export analytics');
    }
    
    // Store settings form
    document.getElementById('storeSettingsForm')?.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        
        try {
            const response = await fetch('backend/api.php/seller/store-settings', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                alert('Store settings saved successfully');
            } else {
                alert('Error saving settings: ' + result.message);
            }
        } catch (error) {
            console.error('Error saving settings:', error);
            alert('Error saving settings');
        }
    });
    
    // Make functions globally available
    window.changePage = changePage;
    window.viewProduct = viewProduct;
    window.editProduct = editProduct;
    window.deleteProduct = deleteProduct;
    window.viewOrder = viewOrder;
    window.updateOrderStatus = updateOrderStatus;
    window.selectMessage = selectMessage;
    window.composeMessage = composeMessage;
    window.exportAnalytics = exportAnalytics;
});
