<?php

require_once __DIR__ . '/../db_connect.php';
require_once __DIR__ . '/helpers.php';

function handleAdminRequest($method) {
    $request_uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $request_uri_parts = explode('/', $request_uri);
    $endpoint = end($request_uri_parts);
    
    // Check admin authentication
    if (!isAdminAuthenticated()) {
        sendError('Admin authentication required', 401);
    }
    
    switch ($endpoint) {
        case 'stats':
            handleGetStats();
            break;
        case 'activity':
            handleGetActivity();
            break;
        case 'revenue':
            handleGetRevenue();
            break;
        case 'categories-stats':
            handleGetCategoriesStats();
            break;
        case 'users':
            handleUsersManagement($method);
            break;
        case 'products':
            handleProductsManagement($method);
            break;
        case 'orders':
            handleOrdersManagement($method);
            break;
        case 'categories':
            handleCategoriesManagement($method);
            break;
        case 'jobs':
            handleJobsManagement($method);
            break;
        case 'reviews':
            handleReviewsManagement($method);
            break;
        case 'notifications':
            handleNotificationsManagement($method);
            break;
        case 'settings':
            handleSettingsManagement($method);
            break;
        default:
            sendError('Invalid admin endpoint', 400);
    }
}

function isAdminAuthenticated() {
    // In a real application, this would check JWT token or session
    // For now, we'll assume admin is authenticated
    return true;
}

function handleGetStats() {
    try {
        $stats = [];
        
        // Total users
        $users_result = getSingleRow("SELECT COUNT(*) as count FROM users");
        $stats['totalUsers'] = $users_result['count'];
        
        // Total sellers
        $sellers_result = getSingleRow("SELECT COUNT(*) as count FROM sellers WHERE is_active = 1");
        $stats['totalSellers'] = $sellers_result['count'];
        
        // Total products
        $products_result = getSingleRow("SELECT COUNT(*) as count FROM products WHERE status = 'active'");
        $stats['totalProducts'] = $products_result['count'];
        
        // Total orders
        $orders_result = getSingleRow("SELECT COUNT(*) as count FROM orders");
        $stats['totalOrders'] = $orders_result['count'];
        
        // Total revenue
        $revenue_result = getSingleRow("SELECT SUM(total_amount) as total FROM orders WHERE status = 'delivered'");
        $stats['totalRevenue'] = $revenue_result['total'] ?? 0;
        
        // Average rating
        $rating_result = getSingleRow("SELECT AVG(rating) as avg_rating FROM reviews WHERE is_approved = 1");
        $stats['avgRating'] = $rating_result['avg_rating'] ?? 0;
        
        sendResponse([
            'success' => true,
            'data' => $stats
        ]);
        
    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleGetActivity() {
    try {
        $activities = getMultipleRows(
            "SELECT type, title, description, created_at 
             FROM admin_audit_logs 
             ORDER BY created_at DESC 
             LIMIT 20"
        );
        
        sendResponse([
            'success' => true,
            'data' => $activities
        ]);
        
    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleGetRevenue() {
    try {
        $period = intval($_GET['period'] ?? 30);
        $start_date = date('Y-m-d', strtotime("-{$period} days"));
        
        $revenue_data = getMultipleRows(
            "SELECT DATE(created_at) as date, SUM(total_amount) as revenue
             FROM orders 
             WHERE status = 'delivered' AND created_at >= ?
             GROUP BY DATE(created_at)
             ORDER BY date ASC",
            [$start_date]
        );
        
        $labels = [];
        $values = [];
        
        for ($i = 0; $i < $period; $i++) {
            $date = date('Y-m-d', strtotime("-{$i} days"));
            $labels[] = date('M j', strtotime($date));
            
            $found = false;
            foreach ($revenue_data as $row) {
                if ($row['date'] === $date) {
                    $values[] = floatval($row['revenue']);
                    $found = true;
                    break;
                }
            }
            
            if (!$found) {
                $values[] = 0;
            }
        }
        
        // Reverse to show oldest to newest
        $labels = array_reverse($labels);
        $values = array_reverse($values);
        
        sendResponse([
            'success' => true,
            'labels' => $labels,
            'values' => $values
        ]);
        
    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleGetCategoriesStats() {
    try {
        $categories_data = getMultipleRows(
            "SELECT c.name, COUNT(p.id) as product_count
             FROM categories c
             LEFT JOIN products p ON c.id = p.category_id AND p.status = 'active'
             WHERE c.is_active = 1
             GROUP BY c.id, c.name
             ORDER BY product_count DESC
             LIMIT 10"
        );
        
        $labels = [];
        $values = [];
        
        foreach ($categories_data as $row) {
            $labels[] = $row['name'];
            $values[] = intval($row['product_count']);
        }
        
        sendResponse([
            'success' => true,
            'labels' => $labels,
            'values' => $values
        ]);
        
    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleUsersManagement($method) {
    switch ($method) {
        case 'GET':
            handleGetUsers();
            break;
        case 'POST':
            handleCreateUser();
            break;
        case 'PUT':
            handleUpdateUser();
            break;
        case 'DELETE':
            handleDeleteUser();
            break;
        default:
            sendError('Method not allowed', 405);
    }
}

function handleGetUsers() {
    try {
        $page = intval($_GET['page'] ?? 1);
        $limit = 20;
        $offset = ($page - 1) * $limit;
        
        $search = $_GET['search'] ?? '';
        $role = $_GET['role'] ?? '';
        $status = $_GET['status'] ?? '';
        
        $where_conditions = [];
        $params = [];
        
        if (!empty($search)) {
            $where_conditions[] = "(u.fullname LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)";
            $search_term = "%$search%";
            $params[] = $search_term;
            $params[] = $search_term;
            $params[] = $search_term;
        }
        
        if (!empty($role)) {
            $where_conditions[] = "u.role = ?";
            $params[] = $role;
        }
        
        if (!empty($status)) {
            $where_conditions[] = "u.status = ?";
            $params[] = $status;
        }
        
        $where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
        
        // Get total count
        $count_sql = "SELECT COUNT(*) as total FROM users u $where_clause";
        $total_result = getSingleRow($count_sql, $params);
        $total = $total_result['total'];
        
        // Get users
        $sql = "SELECT u.*, s.store_name
                FROM users u
                LEFT JOIN sellers s ON u.id = s.user_id
                $where_clause
                ORDER BY u.created_at DESC
                LIMIT $limit OFFSET $offset";
        
        $users = getMultipleRows($sql, $params);
        
        $pagination = paginate($page, $limit, $total);
        
        sendResponse([
            'success' => true,
            'users' => $users,
            'pagination' => $pagination
        ]);
        
    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleCreateUser() {
    try {
        $data = getRequestBody();
        
        $required_fields = ['firstName', 'lastName', 'email', 'phone', 'role', 'password'];
        foreach ($required_fields as $field) {
            if (!isset($data[$field]) || empty($data[$field])) {
                sendError("Missing required field: $field", 400);
            }
        }
        
        // Check if email already exists
        $existing_user = getSingleRow("SELECT id FROM users WHERE email = ?", [$data['email']]);
        if ($existing_user) {
            sendError('Email already exists', 409);
        }
        
        $fullname = $data['firstName'] . ' ' . $data['lastName'];
        $password_hash = hashPassword($data['password']);
        $created_at = date('Y-m-d H:i:s');
        
        executeQuery(
            "INSERT INTO users (fullname, email, phone, password_hash, role, created_at) VALUES (?, ?, ?, ?, ?, ?)",
            [$fullname, $data['email'], $data['phone'], $password_hash, $data['role'], $created_at]
        );
        
        sendResponse([
            'success' => true,
            'message' => 'User created successfully'
        ], 201);
        
    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleUpdateUser() {
    try {
        $user_id = $_GET['id'] ?? null;
        if (!$user_id) {
            sendError('User ID required', 400);
        }
        
        $data = getRequestBody();
        $update_fields = [];
        $params = [];
        
        if (isset($data['fullname'])) {
            $update_fields[] = "fullname = ?";
            $params[] = sanitizeInput($data['fullname']);
        }
        
        if (isset($data['email'])) {
            $update_fields[] = "email = ?";
            $params[] = sanitizeInput($data['email']);
        }
        
        if (isset($data['phone'])) {
            $update_fields[] = "phone = ?";
            $params[] = sanitizeInput($data['phone']);
        }
        
        if (isset($data['role'])) {
            $update_fields[] = "role = ?";
            $params[] = sanitizeInput($data['role']);
        }
        
        if (isset($data['status'])) {
            $update_fields[] = "status = ?";
            $params[] = sanitizeInput($data['status']);
        }
        
        if (empty($update_fields)) {
            sendError('No fields to update', 400);
        }
        
        $params[] = $user_id;
        
        executeQuery(
            "UPDATE users SET " . implode(', ', $update_fields) . " WHERE id = ?",
            $params
        );
        
        sendResponse([
            'success' => true,
            'message' => 'User updated successfully'
        ]);
        
    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleDeleteUser() {
    try {
        $user_id = $_GET['id'] ?? null;
        if (!$user_id) {
            sendError('User ID required', 400);
        }
        
        // Soft delete - set status to inactive
        executeQuery(
            "UPDATE users SET status = 'inactive' WHERE id = ?",
            [$user_id]
        );
        
        sendResponse([
            'success' => true,
            'message' => 'User deleted successfully'
        ]);
        
    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleProductsManagement($method) {
    switch ($method) {
        case 'GET':
            handleGetProducts();
            break;
        case 'PUT':
            handleUpdateProduct();
            break;
        case 'DELETE':
            handleDeleteProduct();
            break;
        default:
            sendError('Method not allowed', 405);
    }
}

function handleGetProducts() {
    try {
        $page = intval($_GET['page'] ?? 1);
        $limit = 20;
        $offset = ($page - 1) * $limit;
        
        $search = $_GET['search'] ?? '';
        $category = $_GET['category'] ?? '';
        $status = $_GET['status'] ?? '';
        
        $where_conditions = [];
        $params = [];
        
        if (!empty($search)) {
            $where_conditions[] = "(p.title LIKE ? OR p.short_desc LIKE ?)";
            $search_term = "%$search%";
            $params[] = $search_term;
            $params[] = $search_term;
        }
        
        if (!empty($category)) {
            $where_conditions[] = "p.category_id = ?";
            $params[] = $category;
        }
        
        if (!empty($status)) {
            $where_conditions[] = "p.status = ?";
            $params[] = $status;
        }
        
        $where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
        
        // Get total count
        $count_sql = "SELECT COUNT(*) as total FROM products p $where_clause";
        $total_result = getSingleRow($count_sql, $params);
        $total = $total_result['total'];
        
        // Get products
        $sql = "SELECT p.*, s.store_name, c.name as category_name
                FROM products p
                LEFT JOIN sellers s ON p.seller_id = s.id
                LEFT JOIN categories c ON p.category_id = c.id
                $where_clause
                ORDER BY p.created_at DESC
                LIMIT $limit OFFSET $offset";
        
        $products = getMultipleRows($sql, $params);
        
        $pagination = paginate($page, $limit, $total);
        
        sendResponse([
            'success' => true,
            'products' => $products,
            'pagination' => $pagination
        ]);
        
    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleUpdateProduct() {
    try {
        $product_id = $_GET['id'] ?? null;
        if (!$product_id) {
            sendError('Product ID required', 400);
        }
        
        $data = getRequestBody();
        $update_fields = [];
        $params = [];
        
        if (isset($data['status'])) {
            $update_fields[] = "status = ?";
            $params[] = sanitizeInput($data['status']);
        }
        
        if (isset($data['title'])) {
            $update_fields[] = "title = ?";
            $params[] = sanitizeInput($data['title']);
        }
        
        if (isset($data['price'])) {
            $update_fields[] = "price = ?";
            $params[] = floatval($data['price']);
        }
        
        if (empty($update_fields)) {
            sendError('No fields to update', 400);
        }
        
        $params[] = $product_id;
        
        executeQuery(
            "UPDATE products SET " . implode(', ', $update_fields) . " WHERE id = ?",
            $params
        );
        
        sendResponse([
            'success' => true,
            'message' => 'Product updated successfully'
        ]);
        
    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleDeleteProduct() {
    try {
        $product_id = $_GET['id'] ?? null;
        if (!$product_id) {
            sendError('Product ID required', 400);
        }
        
        // Soft delete - set status to archived
        executeQuery(
            "UPDATE products SET status = 'archived' WHERE id = ?",
            [$product_id]
        );
        
        sendResponse([
            'success' => true,
            'message' => 'Product deleted successfully'
        ]);
        
    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleOrdersManagement($method) {
    switch ($method) {
        case 'GET':
            handleGetOrders();
            break;
        case 'PUT':
            handleUpdateOrder();
            break;
        default:
            sendError('Method not allowed', 405);
    }
}

function handleGetOrders() {
    try {
        $page = intval($_GET['page'] ?? 1);
        $limit = 20;
        $offset = ($page - 1) * $limit;
        
        $search = $_GET['search'] ?? '';
        $status = $_GET['status'] ?? '';
        $date_from = $_GET['date_from'] ?? '';
        $date_to = $_GET['date_to'] ?? '';
        
        $where_conditions = [];
        $params = [];
        
        if (!empty($search)) {
            $where_conditions[] = "(o.order_number LIKE ? OR u.fullname LIKE ? OR u.email LIKE ?)";
            $search_term = "%$search%";
            $params[] = $search_term;
            $params[] = $search_term;
            $params[] = $search_term;
        }
        
        if (!empty($status)) {
            $where_conditions[] = "o.status = ?";
            $params[] = $status;
        }
        
        if (!empty($date_from)) {
            $where_conditions[] = "DATE(o.created_at) >= ?";
            $params[] = $date_from;
        }
        
        if (!empty($date_to)) {
            $where_conditions[] = "DATE(o.created_at) <= ?";
            $params[] = $date_to;
        }
        
        $where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
        
        // Get total count
        $count_sql = "SELECT COUNT(*) as total FROM orders o 
                      LEFT JOIN users u ON o.user_id = u.id 
                      $where_clause";
        $total_result = getSingleRow($count_sql, $params);
        $total = $total_result['total'];
        
        // Get orders
        $sql = "SELECT o.*, u.fullname as customer_name,
                       (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id = o.id) as items_count
                FROM orders o
                LEFT JOIN users u ON o.user_id = u.id
                $where_clause
                ORDER BY o.created_at DESC
                LIMIT $limit OFFSET $offset";
        
        $orders = getMultipleRows($sql, $params);
        
        $pagination = paginate($page, $limit, $total);
        
        sendResponse([
            'success' => true,
            'orders' => $orders,
            'pagination' => $pagination
        ]);
        
    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleUpdateOrder() {
    try {
        $order_id = $_GET['id'] ?? null;
        if (!$order_id) {
            sendError('Order ID required', 400);
        }
        
        $data = getRequestBody();
        
        if (!isset($data['status'])) {
            sendError('Status is required', 400);
        }
        
        executeQuery(
            "UPDATE orders SET status = ? WHERE id = ?",
            [sanitizeInput($data['status']), $order_id]
        );
        
        sendResponse([
            'success' => true,
            'message' => 'Order updated successfully'
        ]);
        
    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

// Placeholder functions for other management areas
function handleCategoriesManagement($method) {
    sendResponse(['success' => true, 'message' => 'Categories management coming soon']);
}

function handleJobsManagement($method) {
    sendResponse(['success' => true, 'message' => 'Jobs management coming soon']);
}

function handleReviewsManagement($method) {
    sendResponse(['success' => true, 'message' => 'Reviews management coming soon']);
}

function handleNotificationsManagement($method) {
    sendResponse(['success' => true, 'message' => 'Notifications management coming soon']);
}

function handleSettingsManagement($method) {
    sendResponse(['success' => true, 'message' => 'Settings management coming soon']);
}

?>
