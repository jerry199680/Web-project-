<?php

function readJSON($filename) {
    $path = __DIR__ . '/data/' . $filename;
    if (!file_exists($path)) {
        return [];
    }
    $json = file_get_contents($path);
    return json_decode($json, true);
}

function writeJSON($filename, $data) {
    $path = __DIR__ . '/data/' . $filename;
    file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT));
}

function getRequestBody() {
    $content_type = $_SERVER['CONTENT_TYPE'] ?? '';
    
    if (strpos($content_type, 'application/json') !== false) {
    return json_decode(file_get_contents('php://input'), true);
    } elseif (strpos($content_type, 'multipart/form-data') !== false) {
        return $_POST;
    } else {
        return $_POST;
    }
}

function sendResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit();
}

function sendError($message, $statusCode = 500, $errors = null) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    
    $response = ['message' => $message];
    if ($errors) {
        $response['errors'] = $errors;
    }
    
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    exit();
}

function generateUniqueId($prefix = 'id_') {
    return $prefix . uniqid() . '_' . mt_rand(1000, 9999);
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function validatePhone($phone) {
    $phone = preg_replace('/\s+/', '', $phone);
    return preg_match('/^\+251[0-9]{9}$/', $phone);
}

function sanitizeInput($input) {
    return htmlspecialchars(strip_tags(trim($input)), ENT_QUOTES, 'UTF-8');
}

function generateRandomString($length = 32) {
    return bin2hex(random_bytes($length / 2));
}

function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

function validateFileUpload($file, $allowed_types = ['jpg', 'jpeg', 'png', 'gif'], $max_size = 5242880) {
    $errors = [];
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errors[] = 'File upload error';
        return $errors;
    }
    
    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($file_extension, $allowed_types)) {
        $errors[] = 'Invalid file type. Allowed: ' . implode(', ', $allowed_types);
    }
    
    if ($file['size'] > $max_size) {
        $errors[] = 'File too large. Maximum size: ' . ($max_size / 1024 / 1024) . 'MB';
    }
    
    return $errors;
}

function createNotification($user_id, $type, $title, $message, $data = null) {
    try {
        require_once __DIR__ . '/../db_connect.php';
        
        $data_json = $data ? json_encode($data) : null;
        
        executeQuery(
            "INSERT INTO notifications (user_id, type, title, message, data) VALUES (?, ?, ?, ?, ?)",
            [$user_id, $type, $title, $message, $data_json]
        );
        
        return true;
    } catch (Exception $e) {
        error_log("Notification creation failed: " . $e->getMessage());
        return false;
    }
}

function logActivity($user_id, $action, $target_type = null, $target_id = null, $details = null) {
    try {
        require_once __DIR__ . '/../db_connect.php';
        
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
        $details_json = $details ? json_encode($details) : null;
        
        executeQuery(
            "INSERT INTO admin_audit_logs (admin_id, action, target_type, target_id, details, ip_address, user_agent) VALUES (?, ?, ?, ?, ?, ?, ?)",
            [$user_id, $action, $target_type, $target_id, $details_json, $ip_address, $user_agent]
        );
        
        return true;
    } catch (Exception $e) {
        error_log("Activity logging failed: " . $e->getMessage());
        return false;
    }
}

function formatCurrency($amount, $currency = 'ETB') {
    return $currency . ' ' . number_format($amount, 2);
}

function timeAgo($datetime) {
    $time = time() - strtotime($datetime);
    
    if ($time < 60) return 'just now';
    if ($time < 3600) return floor($time/60) . ' minutes ago';
    if ($time < 86400) return floor($time/3600) . ' hours ago';
    if ($time < 2592000) return floor($time/86400) . ' days ago';
    if ($time < 31536000) return floor($time/2592000) . ' months ago';
    return floor($time/31536000) . ' years ago';
}

function paginate($page, $limit, $total) {
    $total_pages = ceil($total / $limit);
    $offset = ($page - 1) * $limit;
    
    return [
        'page' => $page,
        'limit' => $limit,
        'total' => $total,
        'total_pages' => $total_pages,
        'offset' => $offset,
        'has_next' => $page < $total_pages,
        'has_prev' => $page > 1
    ];
}

function generateOrderNumber() {
    return 'EB' . date('Ymd') . str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
}

function calculateListingFee($price, $rate = 5.0) {
    return ($price * $rate) / 100;
}

function sendEmail($to, $subject, $message, $is_html = true) {
    // In production, implement actual email sending
    // For now, just log the email
    error_log("Email to $to: $subject - $message");
    return true;
}

function getClientIP() {
    $ip_keys = ['HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'];
    foreach ($ip_keys as $key) {
        if (array_key_exists($key, $_SERVER) === true) {
            foreach (explode(',', $_SERVER[$key]) as $ip) {
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                    return $ip;
                }
            }
        }
    }
    return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
}

function rateLimit($key, $limit = 10, $window = 3600) {
    $file = __DIR__ . '/../cache/rate_limit_' . md5($key) . '.json';
    $now = time();
    
    if (file_exists($file)) {
        $data = json_decode(file_get_contents($file), true);
        if ($data['window'] + $window > $now) {
            if ($data['count'] >= $limit) {
                return false;
            }
            $data['count']++;
        } else {
            $data = ['count' => 1, 'window' => $now];
        }
    } else {
        $data = ['count' => 1, 'window' => $now];
    }
    
    if (!file_exists(dirname($file))) {
        mkdir(dirname($file), 0777, true);
    }
    
    file_put_contents($file, json_encode($data));
    return true;
}

?>
