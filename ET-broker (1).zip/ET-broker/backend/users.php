<?php

require_once __DIR__ . '/../db_connect.php';
require_once __DIR__ . '/helpers.php';

function handleUserRequest($method) {
    $request_uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $request_uri_parts = explode('/', $request_uri);
    $endpoint = end($request_uri_parts);

    switch ($method) {
        case 'POST':
            switch ($endpoint) {
                case 'signup':
                    handleSignup();
                    break;
                case 'signin':
                    handleSignin();
                    break;
                case 'check-email':
                    handleCheckEmail();
                    break;
                case 'check-phone':
                    handleCheckPhone();
                    break;
                case 'forgot-password':
                    handleForgotPassword();
                    break;
                case 'reset-password':
                    handleResetPassword();
                    break;
                case 'check-role':
                    handleCheckRole();
                    break;
                default:
                    sendError('Invalid endpoint', 404);
            }
            break;
        case 'GET':
            switch ($endpoint) {
                case 'profile':
                    handleGetProfile();
                    break;
                case 'verify-email':
                    handleVerifyEmail();
                    break;
                default:
                    sendError('Invalid endpoint', 404);
            }
            break;
        case 'PUT':
            switch ($endpoint) {
                case 'profile':
                    handleUpdateProfile();
                    break;
                case 'change-password':
                    handleChangePassword();
                    break;
                default:
                    sendError('Invalid endpoint', 404);
            }
            break;
        default:
            sendError('Method not allowed', 405);
    }
}

function handleSignup() {
    try {
        $data = getRequestBody();
        
        // Validate required fields
        $required_fields = ['fullname', 'email', 'phone', 'password', 'confirmPassword', 'role', 'terms'];
        foreach ($required_fields as $field) {
            if (!isset($data[$field]) || empty($data[$field])) {
                sendError("Missing required field: $field", 400);
            }
        }

        // Validate email format
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            sendError('Invalid email format', 400);
        }

        // Validate phone format (Ethiopian phone number)
        $phone = preg_replace('/\s+/', '', $data['phone']);
        if (!preg_match('/^\+251[0-9]{9}$/', $phone)) {
            sendError('Invalid phone number format. Use +251XXXXXXXXX', 400);
        }

        // Validate password strength
        if (strlen($data['password']) < 8) {
            sendError('Password must be at least 8 characters', 400);
        }

        // Validate password confirmation
        if ($data['password'] !== $data['confirmPassword']) {
            sendError('Passwords do not match', 400);
        }

        // Validate terms acceptance
        if (!$data['terms']) {
            sendError('You must accept the terms and conditions', 400);
        }

        // Check if email already exists
        $existing_user = getSingleRow(
            "SELECT id FROM users WHERE email = ?",
            [$data['email']]
        );
        if ($existing_user) {
            sendError('Email already registered', 409);
        }

        // Check if phone already exists
        $existing_phone = getSingleRow(
            "SELECT id FROM users WHERE phone = ?",
            [$phone]
        );
        if ($existing_phone) {
            sendError('Phone number already registered', 409);
        }

        // Validate admin passcode if admin role
        if ($data['role'] === 'admin') {
            if (empty($data['adminPasscode'])) {
                sendError('Admin passcode is required', 400);
            }
            
            // Check admin passcode (in production, this should be stored securely)
            $valid_admin_codes = ['admin123', 'ethio2024', 'broker2024'];
            if (!in_array($data['adminPasscode'], $valid_admin_codes)) {
                sendError('Invalid admin passcode', 400);
            }
        }

        // Hash password
        $password_hash = password_hash($data['password'], PASSWORD_DEFAULT);

        // Start transaction
        $conn = getDBConnection();
        $conn->begin_transaction();

        try {
            // Insert user
            $user_id = executeQuery(
                "INSERT INTO users (fullname, email, phone, password_hash, role, is_verified) VALUES (?, ?, ?, ?, ?, ?)",
                [$data['fullname'], $data['email'], $phone, $password_hash, $data['role'], false]
            )->insert_id;

            // Handle avatar upload
            $avatar_url = null;
            if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
                $avatar_url = handleFileUpload($_FILES['avatar'], 'avatars', $user_id);
                
                // Update user with avatar
                executeQuery(
                    "UPDATE users SET avatar_url = ? WHERE id = ?",
                    [$avatar_url, $user_id]
                );
            }

            // Create seller record if role is seller
            if ($data['role'] === 'seller') {
                executeQuery(
                    "INSERT INTO sellers (user_id, store_name, store_desc, phone, location) VALUES (?, ?, ?, ?, ?)",
                    [$user_id, $data['fullname'] . "'s Store", 'Welcome to my store!', $phone, 'Addis Ababa, Ethiopia']
                );
            }

            $conn->commit();

            // Get created user data
            $user = getSingleRow(
                "SELECT id, fullname, email, phone, avatar_url, role, created_at FROM users WHERE id = ?",
                [$user_id]
            );

            // Generate JWT token
            $token = generateJWT($user);

            sendResponse([
                'success' => true,
                'message' => 'Account created successfully',
                'user' => $user,
                'token' => $token
            ], 201);

        } catch (Exception $e) {
            $conn->rollback();
            throw $e;
        }

    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleSignin() {
    try {
        $data = getRequestBody();
        
        if (empty($data['identifier']) || empty($data['password'])) {
            sendError('Email/phone and password are required', 400);
        }

        $identifier = $data['identifier'];
        $password = $data['password'];
        $loginType = $data['loginType'] ?? 'email';

        // Determine if identifier is email or phone
        if ($loginType === 'email') {
            $user = getSingleRow(
                "SELECT id, fullname, email, phone, password_hash, avatar_url, role, is_verified FROM users WHERE email = ?",
                [$identifier]
            );
        } else {
            $user = getSingleRow(
                "SELECT id, fullname, email, phone, password_hash, avatar_url, role, is_verified FROM users WHERE phone = ?",
                [$identifier]
            );
        }

        if (!$user) {
            sendError('Invalid credentials', 401);
        }

        if (!password_verify($password, $user['password_hash'])) {
            sendError('Invalid credentials', 401);
        }

        // Check admin passcode if admin role
        if ($user['role'] === 'admin' && !empty($data['adminPasscode'])) {
            $valid_admin_codes = ['admin123', 'ethio2024', 'broker2024'];
            if (!in_array($data['adminPasscode'], $valid_admin_codes)) {
                sendError('Invalid admin passcode', 401);
            }
        }

        // Update last login
        executeQuery(
            "UPDATE users SET last_login = NOW() WHERE id = ?",
            [$user['id']]
        );

        // Generate JWT token
        $token = generateJWT($user);

        // Remove password hash from response
        unset($user['password_hash']);

        sendResponse([
            'success' => true,
            'message' => 'Login successful',
            'user' => $user,
            'token' => $token
        ]);

    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleCheckEmail() {
    try {
        $data = getRequestBody();
        $email = $data['email'] ?? '';

        if (empty($email)) {
            sendError('Email is required', 400);
        }

        $existing_user = getSingleRow(
            "SELECT id FROM users WHERE email = ?",
            [$email]
        );

        sendResponse([
            'available' => !$existing_user,
            'message' => $existing_user ? 'Email already registered' : 'Email available'
        ]);

    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleCheckPhone() {
    try {
        $data = getRequestBody();
        $phone = $data['phone'] ?? '';

        if (empty($phone)) {
            sendError('Phone is required', 400);
        }

        $existing_user = getSingleRow(
            "SELECT id FROM users WHERE phone = ?",
            [$phone]
        );

        sendResponse([
            'available' => !$existing_user,
            'message' => $existing_user ? 'Phone already registered' : 'Phone available'
        ]);

    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleCheckRole() {
    try {
        $data = getRequestBody();
        $identifier = $data['identifier'] ?? '';

        if (empty($identifier)) {
            sendError('Identifier is required', 400);
        }

        // Check if identifier is email or phone
        $user = null;
        if (filter_var($identifier, FILTER_VALIDATE_EMAIL)) {
            $user = getSingleRow(
                "SELECT role FROM users WHERE email = ?",
                [$identifier]
            );
        } else {
            $user = getSingleRow(
                "SELECT role FROM users WHERE phone = ?",
                [$identifier]
            );
        }

        sendResponse([
            'success' => true,
            'role' => $user ? $user['role'] : null
        ]);

    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleForgotPassword() {
    try {
    $data = getRequestBody();
    $email = $data['email'] ?? '';

        if (empty($email)) {
            sendError('Email is required', 400);
        }

        $user = getSingleRow(
            "SELECT id, fullname FROM users WHERE email = ?",
            [$email]
        );

        if (!$user) {
            sendError('Email not found', 404);
        }

        // Generate reset token
        $reset_token = bin2hex(random_bytes(32));
        $expires_at = date('Y-m-d H:i:s', strtotime('+1 hour'));

        // Store reset token (in production, use a separate table)
        executeQuery(
            "UPDATE users SET password_reset_token = ?, password_reset_expires = ? WHERE id = ?",
            [$reset_token, $expires_at, $user['id']]
        );

        // Send email (in production, implement actual email sending)
        // For now, just return success
        sendResponse([
            'success' => true,
            'message' => 'Password reset link sent to your email'
        ]);

    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleResetPassword() {
    try {
        $data = getRequestBody();
        $token = $data['token'] ?? '';
    $password = $data['password'] ?? '';

        if (empty($token) || empty($password)) {
            sendError('Token and password are required', 400);
        }

        if (strlen($password) < 8) {
            sendError('Password must be at least 8 characters', 400);
        }

        $user = getSingleRow(
            "SELECT id FROM users WHERE password_reset_token = ? AND password_reset_expires > NOW()",
            [$token]
        );

        if (!$user) {
            sendError('Invalid or expired reset token', 400);
        }

        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        executeQuery(
            "UPDATE users SET password_hash = ?, password_reset_token = NULL, password_reset_expires = NULL WHERE id = ?",
            [$password_hash, $user['id']]
        );

        sendResponse([
            'success' => true,
            'message' => 'Password reset successfully'
        ]);

    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleGetProfile() {
    try {
        $user_id = getCurrentUserId();
        
        $user = getSingleRow(
            "SELECT id, fullname, email, phone, avatar_url, role, is_verified, created_at FROM users WHERE id = ?",
            [$user_id]
        );

        if (!$user) {
            sendError('User not found', 404);
        }

        sendResponse([
            'success' => true,
            'user' => $user
        ]);

    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleUpdateProfile() {
    try {
        $user_id = getCurrentUserId();
        $data = getRequestBody();

        $update_fields = [];
        $params = [];

        if (isset($data['fullname'])) {
            $update_fields[] = "fullname = ?";
            $params[] = $data['fullname'];
        }

        if (isset($data['phone'])) {
            $phone = preg_replace('/\s+/', '', $data['phone']);
            if (!preg_match('/^\+251[0-9]{9}$/', $phone)) {
                sendError('Invalid phone number format', 400);
            }
            $update_fields[] = "phone = ?";
            $params[] = $phone;
        }

        if (isset($data['email'])) {
            if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
                sendError('Invalid email format', 400);
            }
            $update_fields[] = "email = ?";
            $params[] = $data['email'];
        }

        if (empty($update_fields)) {
            sendError('No fields to update', 400);
        }

        $params[] = $user_id;

        executeQuery(
            "UPDATE users SET " . implode(', ', $update_fields) . " WHERE id = ?",
            $params
        );

        sendResponse([
            'success' => true,
            'message' => 'Profile updated successfully'
        ]);

    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleChangePassword() {
    try {
        $user_id = getCurrentUserId();
    $data = getRequestBody();

        $current_password = $data['currentPassword'] ?? '';
        $new_password = $data['newPassword'] ?? '';

        if (empty($current_password) || empty($new_password)) {
            sendError('Current password and new password are required', 400);
        }

        if (strlen($new_password) < 8) {
            sendError('New password must be at least 8 characters', 400);
        }

        $user = getSingleRow(
            "SELECT password_hash FROM users WHERE id = ?",
            [$user_id]
        );

        if (!password_verify($current_password, $user['password_hash'])) {
            sendError('Current password is incorrect', 400);
        }

        $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);

        executeQuery(
            "UPDATE users SET password_hash = ? WHERE id = ?",
            [$new_password_hash, $user_id]
        );

        sendResponse([
            'success' => true,
            'message' => 'Password changed successfully'
        ]);

    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleVerifyEmail() {
    try {
        $token = $_GET['token'] ?? '';

        if (empty($token)) {
            sendError('Verification token is required', 400);
        }

        $user = getSingleRow(
            "SELECT id FROM users WHERE email_verification_token = ? AND email_verification_expires > NOW()",
            [$token]
        );

        if (!$user) {
            sendError('Invalid or expired verification token', 400);
        }

        executeQuery(
            "UPDATE users SET is_verified = TRUE, email_verification_token = NULL, email_verification_expires = NULL WHERE id = ?",
            [$user['id']]
        );

        sendResponse([
            'success' => true,
            'message' => 'Email verified successfully'
        ]);

    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

// Helper function to handle file uploads
function handleFileUpload($file, $folder, $user_id) {
    $upload_dir = __DIR__ . '/../uploads/' . $folder . '/';
    
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
    
    if (!in_array($file_extension, $allowed_extensions)) {
        throw new Exception('Invalid file type. Only JPG, PNG, and GIF files are allowed.');
    }

    if ($file['size'] > 5 * 1024 * 1024) { // 5MB max
        throw new Exception('File size too large. Maximum 5MB allowed.');
    }

    $filename = $user_id . '_' . time() . '.' . $file_extension;
    $file_path = $upload_dir . $filename;

    if (!move_uploaded_file($file['tmp_name'], $file_path)) {
        throw new Exception('Failed to upload file.');
    }

    return 'uploads/' . $folder . '/' . $filename;
}

// Helper function to generate JWT token
function generateJWT($user) {
    $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
    $payload = json_encode([
        'user_id' => $user['id'],
        'email' => $user['email'],
        'role' => $user['role'],
        'exp' => time() + (24 * 60 * 60) // 24 hours
    ]);

    $base64_header = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
    $base64_payload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));

    $signature = hash_hmac('sha256', $base64_header . "." . $base64_payload, 'your-secret-key', true);
    $base64_signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));

    return $base64_header . "." . $base64_payload . "." . $base64_signature;
}

// Helper function to get current user ID from JWT
function getCurrentUserId() {
    $headers = getallheaders();
    $auth_header = $headers['Authorization'] ?? '';
    
    if (!preg_match('/Bearer\s(\S+)/', $auth_header, $matches)) {
        throw new Exception('Authorization token required');
    }

    $token = $matches[1];
    $parts = explode('.', $token);
    
    if (count($parts) !== 3) {
        throw new Exception('Invalid token format');
    }

    $payload = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $parts[1])), true);
    
    if (!$payload || $payload['exp'] < time()) {
        throw new Exception('Token expired');
    }

    return $payload['user_id'];
}

?>