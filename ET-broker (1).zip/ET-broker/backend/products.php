<?php

require_once __DIR__ . '/../db_connect.php';
require_once __DIR__ . '/helpers.php';

function handleProductRequest($method) {
    switch ($method) {
        case 'POST':
            handleCreateProduct();
            break;
        case 'GET':
            handleGetProducts();
            break;
        default:
            sendError('Method not allowed', 405);
    }
}

function handleCreateProduct() {
    try {
        $user_id = getCurrentUserId();
        
        // Validate required fields
        $required_fields = ['title', 'short_desc', 'description', 'category_id', 'price', 'quantity', 'condition', 'location'];
        foreach ($required_fields as $field) {
            if (!isset($_POST[$field]) || empty($_POST[$field])) {
                sendError("Missing required field: $field", 400);
            }
        }
        
        // Get seller ID
        $seller = getSingleRow("SELECT id FROM sellers WHERE user_id = ?", [$user_id]);
        if (!$seller) {
            sendError('Seller profile not found', 404);
        }
        
        $price = floatval($_POST['price']);
        $quantity = intval($_POST['quantity']);
        
        // Calculate listing fee
        $listing_fee_amount = ($price * 5) / 100; // 5%
        
        // Insert product
        $sql = "INSERT INTO products (seller_id, category_id, title, short_desc, description, price, qty, location, condition, status, listing_fee_amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $params = [
            $seller['id'],
            $_POST['category_id'],
            sanitizeInput($_POST['title']),
            sanitizeInput($_POST['short_desc']),
            sanitizeInput($_POST['description']),
            $price,
            $quantity,
            sanitizeInput($_POST['location']),
            $_POST['condition'],
            'draft',
            $listing_fee_amount
        ];
        
        $stmt = executeQuery($sql, $params);
        $product_id = $stmt->insert_id;
        
        sendResponse([
            'success' => true,
            'message' => 'Product created successfully',
            'product_id' => $product_id
        ], 201);
        
    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleGetProducts() {
    try {
        $page = intval($_GET['page'] ?? 1);
        $limit = intval($_GET['limit'] ?? 20);
        $category_id = $_GET['category'] ?? null;
        $search = $_GET['q'] ?? null;
        
        $where_conditions = ["p.status = 'active'"];
        $params = [];
        
        if ($category_id) {
            $where_conditions[] = "p.category_id = ?";
            $params[] = $category_id;
        }
        
        if ($search) {
            $where_conditions[] = "(p.title LIKE ? OR p.short_desc LIKE ?)";
            $search_term = "%$search%";
            $params[] = $search_term;
            $params[] = $search_term;
        }
        
        $where_clause = implode(' AND ', $where_conditions);
        
        $offset = ($page - 1) * $limit;
        $sql = "SELECT p.*, s.store_name, c.name as category_name
                FROM products p
                JOIN sellers s ON p.seller_id = s.id
                JOIN categories c ON p.category_id = c.id
                WHERE $where_clause
                ORDER BY p.created_at DESC
                LIMIT $limit OFFSET $offset";
        
        $products = getMultipleRows($sql, $params);
        
        sendResponse([
            'success' => true,
            'products' => $products
        ]);
        
    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

?>