<?php

require_once __DIR__ . '/helpers.php';

function handleHeroImageRequest($method) {
    switch ($method) {
        case 'GET':
            handleGetHeroImages();
            break;
        case 'POST':
            handlePostHeroImage();
            break;
        case 'DELETE':
            handleDeleteHeroImage();
            break;
        default:
            sendError('Method not allowed', 405);
            break;
    }
}

function handleGetHeroImages() {
    $heroImages = readJSON('hero_images.json');
    sendResponse($heroImages);
}

function handlePostHeroImage() {
    if (empty($_FILES['hero_images'])) {
        sendError('No image files uploaded', 400);
    }

    $heroImages = readJSON('hero_images.json');
    $newImages = [];
    $uploadDir = __DIR__ . '/../images/';

    foreach ($_FILES['hero_images']['tmp_name'] as $key => $tmp_name) {
        if ($_FILES['hero_images']['error'][$key] == UPLOAD_ERR_OK) {
            $imageFileName = uniqid() . '_' . basename($_FILES['hero_images']['name'][$key]);
            $imageFilePath = $uploadDir . $imageFileName;
            if (move_uploaded_file($tmp_name, $imageFilePath)) {
                $newImages[] = 'EB/images/' . $imageFileName;
            } else {
                error_log("Failed to upload hero image: " . $_FILES['hero_images']['name'][$key]);
            }
        }
    }

    if (!empty($newImages)) {
        $heroImages = array_merge($heroImages, $newImages);
        writeJSON('hero_images.json', $heroImages);
        sendResponse(['message' => 'Images uploaded successfully', 'newImages' => $newImages], 201);
    } else {
        sendError('No images were successfully uploaded', 500);
    }
}

function handleDeleteHeroImage() {
    $data = getRequestBody();
    $imageUrl = $data['imageUrl'] ?? null;

    if (!$imageUrl) {
        sendError('Image URL is required', 400);
    }

    $heroImages = readJSON('hero_images.json');
    $initialCount = count($heroImages);
    
    // Remove image file from server
    $imagePath = __DIR__ . '/../' . $imageUrl; // Adjust path to actual file location
    if (file_exists($imagePath)) {
        unlink($imagePath);
    }

    // Remove from JSON
    $heroImages = array_filter($heroImages, fn($image) => $image !== $imageUrl);

    if (count($heroImages) < $initialCount) {
        writeJSON('hero_images.json', array_values($heroImages));
        sendResponse(['message' => 'Image deleted successfully']);
    } else {
        sendError('Image not found', 404);
    }
}

?>
