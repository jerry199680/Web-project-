<?php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

// Handle OPTIONS preflight request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

// Basic routing logic
$request_uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$request_uri_parts = explode('/', $request_uri);

// Filter out empty parts and re-index
$request_uri_parts = array_values(array_filter($request_uri_parts));

// Assuming the API base path is /EB/backend/api.php
// We need to find the 'api.php' part and then get the segment after it
$api_index = array_search('api.php', $request_uri_parts);
$endpoint = null;
if ($api_index !== false && isset($request_uri_parts[$api_index + 1])) {
    $endpoint = $request_uri_parts[$api_index + 1];
}

$method = $_SERVER['REQUEST_METHOD'];

// Include helper functions
require_once __DIR__ . '/helpers.php';

// Route requests
switch ($endpoint) {
    case 'products':
        require_once __DIR__ . '/products.php';
        handleProductRequest($method);
        break;
    case 'categories':
        require_once __DIR__ . '/categories.php';
        handleCategoryRequest($method);
        break;
    case 'users':
        require_once __DIR__ . '/users.php';
        handleUserRequest($method);
        break;
    case 'orders':
        require_once __DIR__ . '/orders.php';
        handleOrderRequest($method);
        break;
    case 'deals':
        require_once __DIR__ . '/deals.php';
        handleDealRequest($method);
        break;
    case 'hero_images':
        require_once __DIR__ . '/hero_images.php';
        handleHeroImageRequest($method);
        break;
    case 'staff':
        require_once __DIR__ . '/staff.php';
        handleStaffRequest($method);
        break;
    case 'admin':
        require_once __DIR__ . '/admin.php';
        handleAdminRequest($method);
        break;
    default:
        http_response_code(404);
        echo json_encode(['message' => 'Endpoint not found']);
        break;
}

?>
