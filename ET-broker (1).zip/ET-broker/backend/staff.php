<?php

require_once __DIR__ . '/helpers.php';

function handleStaffRequest($method) {
    switch ($method) {
        case 'GET':
            handleGetStaff();
            break;
        case 'POST':
            handlePostStaff();
            break;
        case 'PUT':
            handlePutStaff();
            break;
        case 'DELETE':
            handleDeleteStaff();
            break;
        default:
            sendError('Method not allowed', 405);
            break;
    }
}

function handleGetStaff() {
    $staff = readJSON('staff.json');
    // Do not send passwords
    $safeStaff = array_map(function($member) {
        unset($member['password']);
        return $member;
    }, $staff);
    sendResponse($safeStaff);
}

function handlePostStaff() {
    $data = getRequestBody();
    $name = $data['name'] ?? '';
    $email = $data['email'] ?? '';
    $password = $data['password'] ?? '';
    $role = $data['role'] ?? '';

    if (empty($name) || empty($email) || empty($password) || empty($role)) {
        sendError('Missing required staff fields', 400);
    }

    $staff = readJSON('staff.json');

    // Check if email already exists
    foreach ($staff as $member) {
        if ($member['email'] === $email) {
            sendError('Staff member with this email already exists', 409);
        }
    }

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $newStaff = [
        'id' => generateUniqueId('staff_'),
        'name' => $name,
        'email' => $email,
        'password' => $hashedPassword,
        'role' => $role,
        'dateAdded' => date('Y-m-d H:i:s'),
    ];

    $staff[] = $newStaff;
    writeJSON('staff.json', $staff);
    // Return safe data without password
    unset($newStaff['password']);
    sendResponse(['message' => 'Staff member added successfully', 'staff' => $newStaff], 201);
}

function handlePutStaff() {
    $staffId = $_GET['id'] ?? null;
    if (!$staffId) {
        sendError('Staff ID is required', 400);
    }

    $data = getRequestBody();
    $staff = readJSON('staff.json');
    $updatedStaff = null;

    foreach ($staff as &$member) {
        if ($member['id'] === $staffId) {
            $member['name'] = $data['name'] ?? $member['name'];
            $member['email'] = $data['email'] ?? $member['email'];
            $member['role'] = $data['role'] ?? $member['role'];
            // Password can be updated separately if needed, not directly via PUT for other fields
            
            $updatedStaff = $member;
            break;
        }
    }

    if ($updatedStaff) {
        writeJSON('staff.json', $staff);
        unset($updatedStaff['password']); // Do not send password back
        sendResponse($updatedStaff);
    } else {
        sendError('Staff member not found', 404);
    }
}

function handleDeleteStaff() {
    $staffId = $_GET['id'] ?? null;
    if (!$staffId) {
        sendError('Staff ID is required', 400);
    }

    $staff = readJSON('staff.json');
    $initialCount = count($staff);
    $staff = array_filter($staff, fn($member) => $member['id'] !== $staffId);

    if (count($staff) < $initialCount) {
        writeJSON('staff.json', array_values($staff));
        sendResponse(['message' => 'Staff member deleted successfully']);
    } else {
        sendError('Staff member not found', 404);
    }
}

?>
