<?php

require_once __DIR__ . '/helpers.php';

function handleDealRequest($method) {
    switch ($method) {
        case 'GET':
            handleGetDeals();
            break;
        case 'POST': // Used for setting/updating the entire deal config
            handlePostDeal();
            break;
        default:
            sendError('Method not allowed', 405);
            break;
    }
}

function handleGetDeals() {
    $deals = readJSON('deals.json');
    // Assume only one deal configuration at a time for simplicity
    sendResponse(empty($deals) ? null : $deals[0]);
}

function handlePostDeal() {
    $data = getRequestBody();

    if (empty($data['dealPercentage']) || empty($data['dealProducts']) || empty($data['dealEndDate'])) {
        sendError('Missing required deal configuration fields', 400);
    }

    $dealConfig = [
        'id' => generateUniqueId('deal_'),
        'dealPercentage' => (float)$data['dealPercentage'],
        'dealProducts' => $data['dealProducts'], // Array of product IDs
        'dealEndDate' => $data['dealEndDate'], // ISO 8601 string
        'heroImage' => $data['heroImage'] ?? null,
        'lastUpdated' => date('Y-m-d H:i:s'),
    ];

    // Overwrite existing deal or save new one
    writeJSON('deals.json', [$dealConfig]); // Always store as an array with one element
    sendResponse($dealConfig, 201);
}

?>
