<?php

require_once __DIR__ . '/helpers.php';

function handleOrderRequest($method) {
    switch ($method) {
        case 'GET':
            handleGetOrders();
            break;
        case 'POST':
            handlePostOrder();
            break;
        case 'PUT':
            handlePutOrder();
            break;
        default:
            sendError('Method not allowed', 405);
            break;
    }
}

function handleGetOrders() {
    $orders = readJSON('orders.json');
    sendResponse($orders);
}

function handlePostOrder() {
    $data = getRequestBody();

    // Basic validation
    if (empty($data['customer']) || empty($data['items']) || empty($data['totalAmount']) || empty($data['paymentMethod'])) {
        sendError('Missing required order fields', 400);
    }

    $orders = readJSON('orders.json');

    $newOrder = [
        'id' => generateUniqueId('order_'),
        'customer' => $data['customer'],
        'items' => $data['items'],
        'totalAmount' => (float)$data['totalAmount'],
        'paymentMethod' => $data['paymentMethod'],
        'transactionId' => $data['transactionId'] ?? null, // For Chapa/PayPal
        'screenshot' => $data['screenshot'] ?? null, // For bank transfer
        'status' => 'pending', // Default status
        'orderDate' => date('Y-m-d H:i:s'),
        'isHidden' => false,
    ];

    $orders[] = $newOrder;
    writeJSON('orders.json', $orders);
    sendResponse(['message' => 'Order placed successfully', 'orderId' => $newOrder['id']], 201);
}

function handlePutOrder() {
    $orderId = $_GET['id'] ?? null;
    if (!$orderId) {
        sendError('Order ID is required', 400);
    }

    $data = getRequestBody();
    $orders = readJSON('orders.json');
    $updatedOrder = null;

    foreach ($orders as &$order) {
        if ($order['id'] === $orderId) {
            // Update allowed fields (e.g., status, isHidden)
            $order['status'] = $data['status'] ?? $order['status'];
            $order['isHidden'] = isset($data['isHidden']) ? filter_var($data['isHidden'], FILTER_VALIDATE_BOOLEAN) : $order['isHidden'];
            // Add other fields that might be updated by admin
            $updatedOrder = $order;
            break;
        }
    }

    if ($updatedOrder) {
        writeJSON('orders.json', $orders);
        sendResponse($updatedOrder);
    } else {
        sendError('Order not found', 404);
    }
}

?>
