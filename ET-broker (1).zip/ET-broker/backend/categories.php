<?php

require_once __DIR__ . '/../db_connect.php';
require_once __DIR__ . '/helpers.php';

function handleCategoryRequest($method) {
    switch ($method) {
        case 'GET':
            handleGetCategories();
            break;
        case 'POST':
            handleCreateCategory();
            break;
        case 'PUT':
            handleUpdateCategory();
            break;
        case 'DELETE':
            handleDeleteCategory();
            break;
        default:
            sendError('Method not allowed', 405);
            break;
    }
}

function handleGetCategories() {
    try {
        $categories = getMultipleRows(
            "SELECT id, name, slug, parent_id, description, image, icon, sort_order 
             FROM categories 
             WHERE is_active = 1 
             ORDER BY sort_order ASC, name ASC"
        );
        
        // Organize categories with subcategories
        $organized_categories = [];
        $subcategories = [];
        
        foreach ($categories as $category) {
            if ($category['parent_id'] === null) {
                $category['subcategories'] = [];
                $organized_categories[] = $category;
            } else {
                $subcategories[] = $category;
            }
        }
        
        // Add subcategories to their parents
        foreach ($subcategories as $subcategory) {
            foreach ($organized_categories as &$parent) {
                if ($parent['id'] == $subcategory['parent_id']) {
                    $parent['subcategories'][] = $subcategory;
                    break;
                }
            }
        }
        
        sendResponse([
            'success' => true,
            'categories' => $organized_categories
        ]);
        
    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleCreateCategory() {
    try {
        $data = getRequestBody();
        
        if (empty($data['name'])) {
            sendError('Category name is required', 400);
        }
        
        $slug = strtolower(str_replace(' ', '-', $data['name']));
        
        executeQuery(
            "INSERT INTO categories (name, slug, parent_id, description, image, icon, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)",
            [
                sanitizeInput($data['name']),
                $slug,
                $data['parent_id'] ?? null,
                sanitizeInput($data['description'] ?? ''),
                $data['image'] ?? null,
                $data['icon'] ?? null,
                intval($data['sort_order'] ?? 0)
            ]
        );
        
        sendResponse([
            'success' => true,
            'message' => 'Category created successfully'
        ], 201);
        
    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleUpdateCategory() {
    try {
        $categoryId = $_GET['id'] ?? null;
        if (!$categoryId) {
            sendError('Category ID is required', 400);
        }
        
        $data = getRequestBody();
        $update_fields = [];
        $params = [];
        
        if (isset($data['name'])) {
            $update_fields[] = "name = ?";
            $params[] = sanitizeInput($data['name']);
        }
        
        if (isset($data['description'])) {
            $update_fields[] = "description = ?";
            $params[] = sanitizeInput($data['description']);
        }
        
        if (isset($data['image'])) {
            $update_fields[] = "image = ?";
            $params[] = $data['image'];
        }
        
        if (isset($data['icon'])) {
            $update_fields[] = "icon = ?";
            $params[] = $data['icon'];
        }
        
        if (empty($update_fields)) {
            sendError('No fields to update', 400);
        }
        
        $params[] = $categoryId;
        
        executeQuery(
            "UPDATE categories SET " . implode(', ', $update_fields) . " WHERE id = ?",
            $params
        );
        
        sendResponse([
            'success' => true,
            'message' => 'Category updated successfully'
        ]);
        
    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

function handleDeleteCategory() {
    try {
        $categoryId = $_GET['id'] ?? null;
        if (!$categoryId) {
            sendError('Category ID is required', 400);
        }
        
        // Check if category has products
        $product_count = getSingleRow(
            "SELECT COUNT(*) as count FROM products WHERE category_id = ?",
            [$categoryId]
        );
        
        if ($product_count['count'] > 0) {
            sendError('Cannot delete category with existing products', 400);
        }
        
        // Soft delete - set is_active to false
        executeQuery(
            "UPDATE categories SET is_active = 0 WHERE id = ?",
            [$categoryId]
        );
        
        sendResponse([
            'success' => true,
            'message' => 'Category deleted successfully'
        ]);
        
    } catch (Exception $e) {
        sendError($e->getMessage(), 500);
    }
}

?>
