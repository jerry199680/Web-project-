// Jobs Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const jobSearch = document.getElementById('jobSearch');
    const locationFilter = document.getElementById('locationFilter');
    const categoryFilter = document.getElementById('categoryFilter');
    const experienceFilter = document.getElementById('experienceFilter');
    const featuredJobs = document.getElementById('featuredJobs');
    const jobsList = document.getElementById('jobsList');
    const jobsPagination = document.getElementById('jobsPagination');
    const viewBtns = document.querySelectorAll('.view-btn');
    const applicationModal = document.getElementById('applicationModal');
    const applicationForm = document.getElementById('applicationForm');
    const salaryRange = document.getElementById('salaryRange');
    const salaryValue = document.getElementById('salaryValue');
    
    // State
    let currentPage = 1;
    let currentView = 'grid';
    let currentFilters = {};
    let allJobs = [];
    let filteredJobs = [];
    let currentJobId = null;
    
    // Initialize
    loadFeaturedJobs();
    loadAllJobs();
    setupEventListeners();
    
    function setupEventListeners() {
        // Search and filters
        jobSearch.addEventListener('input', debounce(() => searchJobs(), 500));
        locationFilter.addEventListener('change', () => searchJobs());
        categoryFilter.addEventListener('change', () => searchJobs());
        experienceFilter.addEventListener('change', () => searchJobs());
        
        // View options
        viewBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                viewBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                currentView = btn.dataset.view;
                updateJobsView();
            });
        });
        
        // Salary range
        salaryRange.addEventListener('input', (e) => {
            salaryValue.textContent = `ETB ${parseInt(e.target.value).toLocaleString()}`;
        });
        
        // Application form
        applicationForm.addEventListener('submit', handleApplicationSubmit);
        
        // Close modal on outside click
        applicationModal.addEventListener('click', (e) => {
            if (e.target === applicationModal) {
                closeApplicationModal();
            }
        });
    }
    
    async function loadFeaturedJobs() {
        try {
            const response = await fetch('backend/api.php/jobs?featured=true&limit=6');
            const data = await response.json();
            
            if (data.success) {
                renderFeaturedJobs(data.jobs);
            }
        } catch (error) {
            console.error('Error loading featured jobs:', error);
        }
    }
    
    function renderFeaturedJobs(jobs) {
        featuredJobs.innerHTML = jobs.map(job => `
            <div class="job-card" onclick="viewJobDetails(${job.id})">
                <div class="job-header">
                    <div>
                        <h3 class="job-title">${job.title}</h3>
                        <p class="job-company">${job.company_name}</p>
                    </div>
                    <span class="job-type">${job.job_type}</span>
                </div>
                <div class="job-details">
                    <div class="job-location">
                        <i class="fas fa-map-marker-alt"></i>
                        ${job.location}
                    </div>
                    <div class="job-salary">${formatSalary(job.salary_min, job.salary_max)}</div>
                </div>
                <p class="job-description">${job.description}</p>
                <div class="job-tags">
                    ${job.tags.map(tag => `<span class="job-tag">${tag}</span>`).join('')}
                </div>
                <div class="job-footer">
                    <span class="job-posted">Posted ${timeAgo(job.created_at)}</span>
                    <button class="job-apply" onclick="event.stopPropagation(); applyForJob(${job.id})">
                        Apply Now
                    </button>
                </div>
            </div>
        `).join('');
    }
    
    async function loadAllJobs() {
        try {
            const response = await fetch('backend/api.php/jobs');
            const data = await response.json();
            
            if (data.success) {
                allJobs = data.jobs;
                filteredJobs = [...allJobs];
                renderJobsList();
                updateResultsInfo();
            }
        } catch (error) {
            console.error('Error loading jobs:', error);
        }
    }
    
    function searchJobs() {
        const searchTerm = jobSearch.value.toLowerCase();
        const location = locationFilter.value;
        const category = categoryFilter.value;
        const experience = experienceFilter.value;
        
        filteredJobs = allJobs.filter(job => {
            const matchesSearch = !searchTerm || 
                job.title.toLowerCase().includes(searchTerm) ||
                job.company_name.toLowerCase().includes(searchTerm) ||
                job.description.toLowerCase().includes(searchTerm);
            
            const matchesLocation = !location || job.location.toLowerCase().includes(location);
            const matchesCategory = !category || job.category === category;
            const matchesExperience = !experience || job.experience_level === experience;
            
            return matchesSearch && matchesLocation && matchesCategory && matchesExperience;
        });
        
        currentPage = 1;
        renderJobsList();
        updateResultsInfo();
    }
    
    function applyFilters() {
        const jobTypeFilters = Array.from(document.querySelectorAll('input[name="jobType"]:checked'))
            .map(checkbox => checkbox.value);
        const companySizeFilters = Array.from(document.querySelectorAll('input[name="companySize"]:checked'))
            .map(checkbox => checkbox.value);
        const salaryMin = parseInt(salaryRange.value);
        
        filteredJobs = allJobs.filter(job => {
            const matchesJobType = jobTypeFilters.length === 0 || jobTypeFilters.includes(job.job_type);
            const matchesCompanySize = companySizeFilters.length === 0 || 
                (job.company_size && companySizeFilters.includes(job.company_size));
            const matchesSalary = !salaryMin || (job.salary_min && job.salary_min >= salaryMin);
            
            return matchesJobType && matchesCompanySize && matchesSalary;
        });
        
        currentPage = 1;
        renderJobsList();
        updateResultsInfo();
    }
    
    function clearFilters() {
        // Reset all filter inputs
        document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
            checkbox.checked = false;
        });
        salaryRange.value = 50000;
        salaryValue.textContent = 'ETB 50,000';
        jobSearch.value = '';
        locationFilter.value = '';
        categoryFilter.value = '';
        experienceFilter.value = '';
        
        // Reset filtered jobs
        filteredJobs = [...allJobs];
        currentPage = 1;
        renderJobsList();
        updateResultsInfo();
    }
    
    function renderJobsList() {
        const jobsPerPage = 12;
        const startIndex = (currentPage - 1) * jobsPerPage;
        const endIndex = startIndex + jobsPerPage;
        const jobsToShow = filteredJobs.slice(startIndex, endIndex);
        
        jobsList.innerHTML = jobsToShow.map(job => `
            <div class="job-card" onclick="viewJobDetails(${job.id})">
                <div class="job-header">
                    <div>
                        <h3 class="job-title">${job.title}</h3>
                        <p class="job-company">${job.company_name}</p>
                    </div>
                    <span class="job-type">${job.job_type}</span>
                </div>
                <div class="job-details">
                    <div class="job-location">
                        <i class="fas fa-map-marker-alt"></i>
                        ${job.location}
                    </div>
                    <div class="job-salary">${formatSalary(job.salary_min, job.salary_max)}</div>
                </div>
                <p class="job-description">${job.description}</p>
                <div class="job-tags">
                    ${job.tags.map(tag => `<span class="job-tag">${tag}</span>`).join('')}
                </div>
                <div class="job-footer">
                    <span class="job-posted">Posted ${timeAgo(job.created_at)}</span>
                    <button class="job-apply" onclick="event.stopPropagation(); applyForJob(${job.id})">
                        Apply Now
                    </button>
                </div>
            </div>
        `).join('');
        
        updateJobsView();
        updatePagination();
    }
    
    function updateJobsView() {
        jobsList.className = `jobs-list ${currentView}`;
    }
    
    function updatePagination() {
        const jobsPerPage = 12;
        const totalPages = Math.ceil(filteredJobs.length / jobsPerPage);
        
        if (totalPages <= 1) {
            jobsPagination.innerHTML = '';
            return;
        }
        
        let paginationHTML = '';
        
        // Previous button
        paginationHTML += `
            <button ${currentPage === 1 ? 'disabled' : ''} onclick="changePage(${currentPage - 1})">
                <i class="fas fa-chevron-left"></i>
            </button>
        `;
        
        // Page numbers
        for (let i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= currentPage - 2 && i <= currentPage + 2)) {
                paginationHTML += `
                    <span class="page-number ${i === currentPage ? 'active' : ''}" 
                          onclick="changePage(${i})">${i}</span>
                `;
            } else if (i === currentPage - 3 || i === currentPage + 3) {
                paginationHTML += '<span class="page-number">...</span>';
            }
        }
        
        // Next button
        paginationHTML += `
            <button ${currentPage === totalPages ? 'disabled' : ''} onclick="changePage(${currentPage + 1})">
                <i class="fas fa-chevron-right"></i>
            </button>
        `;
        
        jobsPagination.innerHTML = paginationHTML;
    }
    
    function changePage(page) {
        if (page < 1 || page > Math.ceil(filteredJobs.length / 12)) return;
        
        currentPage = page;
        renderJobsList();
        
        // Scroll to top of jobs list
        jobsList.scrollIntoView({ behavior: 'smooth' });
    }
    
    function updateResultsInfo() {
        const resultsCount = document.getElementById('resultsCount');
        const resultsLocation = document.getElementById('resultsLocation');
        
        resultsCount.textContent = `${filteredJobs.length} job${filteredJobs.length !== 1 ? 's' : ''} found`;
        
        const location = locationFilter.value;
        if (location) {
            resultsLocation.textContent = `in ${location.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase())}`;
        } else {
            resultsLocation.textContent = '';
        }
    }
    
    function formatSalary(min, max) {
        if (!min && !max) return 'Salary not specified';
        if (!max) return `ETB ${min.toLocaleString()}+`;
        if (!min) return `Up to ETB ${max.toLocaleString()}`;
        return `ETB ${min.toLocaleString()} - ${max.toLocaleString()}`;
    }
    
    function timeAgo(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const diffInSeconds = Math.floor((now - date) / 1000);
        
        if (diffInSeconds < 60) return 'just now';
        if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
        if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
        if (diffInSeconds < 2592000) return `${Math.floor(diffInSeconds / 86400)}d ago`;
        return date.toLocaleDateString();
    }
    
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    // Job actions
    function viewJobDetails(jobId) {
        // In a real application, this would navigate to a job details page
        console.log('View job details:', jobId);
    }
    
    function applyForJob(jobId) {
        currentJobId = jobId;
        applicationModal.classList.add('show');
    }
    
    function closeApplicationModal() {
        applicationModal.classList.remove('show');
        applicationForm.reset();
        currentJobId = null;
    }
    
    function submitApplication() {
        if (!applicationForm.checkValidity()) {
            applicationForm.reportValidity();
            return;
        }
        
        const formData = new FormData(applicationForm);
        formData.append('job_id', currentJobId);
        
        // In a real application, this would submit to the backend
        console.log('Submitting application for job:', currentJobId);
        console.log('Form data:', Object.fromEntries(formData));
        
        // Show success message
        alert('Application submitted successfully!');
        closeApplicationModal();
    }
    
    function filterByCategory(category) {
        categoryFilter.value = category;
        searchJobs();
    }
    
    // Make functions globally available
    window.searchJobs = searchJobs;
    window.applyFilters = applyFilters;
    window.clearFilters = clearFilters;
    window.changePage = changePage;
    window.viewJobDetails = viewJobDetails;
    window.applyForJob = applyForJob;
    window.closeApplicationModal = closeApplicationModal;
    window.submitApplication = submitApplication;
    window.filterByCategory = filterByCategory;
});
