document.addEventListener('DOMContentLoaded', () => {
    const categoriesGrid = document.getElementById('categories-grid');
    const productGrid = document.getElementById('product-grid');
    const loader = document.getElementById('loader');

    // --- MOCK DATA ---
    const categories = [
        { name: 'Clothes', icon: 'fas fa-tshirt' },
        { name: 'Shoes', icon: 'fas fa-shoe-prints' },
        { name: 'Accessories', icon: 'fas fa-glasses' },
        { name: 'Machines', icon: 'fas fa-cogs' },
        { name: 'Home', icon: 'fas fa-home' },
        { name: 'Furniture', icon: 'fas fa-couch' },
        { name: 'Cars', icon: 'fas fa-car' },
        { name: 'Motor', icon: 'fas fa-motorcycle' },
        { name: 'Jobs', icon: 'fas fa-briefcase' },
        { name: 'Employees', icon: 'fas fa-users' },
    ];

    const allProducts = [
        { id: 1, name: "Classic Men's Shirt", price: 45, location: "Addis Ababa", category: "Clothes", image: "images/360f33bf797ff282ff4e7e23e018f5f3.jpg", seller: "Fashion Hub", badge: "New" },
        { id: 2, name: "Leather Ankle Boots", price: 80, location: "Adama", category: "Shoes", image: "images/ab1c006057d0416df26de61f08fc6daa.jpg", seller: "Shoe World", badge: "Sale" },
        { id: 3, name: "Designer Sunglasses", price: 120, location: "Addis Ababa", category: "Accessories", image: "images/45e48e5ba4dc5cb53d96b8a9fe747403.jpg", seller: "Sunnies Co.", badge: "Top" },
        { id: 4, name: "Heavy Duty Generator", price: 500, location: "Mekelle", category: "Machines", image: "images/69103cae4067d04ab6115d22b2a96891.jpg", seller: "Power Tools", badge: "" },
        { id: 5, name: "Modern Sofa Set", price: 750, location: "Addis Ababa", category: "Furniture", image: "images/fernature.jpeg", seller: "Home Decor", badge: "New" },
        { id: 6, name: "Toyota Vitz 2010", price: 8000, location: "Bahir Dar", category: "Cars", image: "images/car-1.jpg", seller: "Car Deals", badge: "" },
        { id: 7, name: "Sports Motorcycle", price: 4500, location: "Addis Ababa", category: "Motor", image: "images/bike-1.jpg", seller: "Speed Motors", badge: "Sale" },
        { id: 8, name: "Elegant Summer Dress", price: 65, location: "Hawassa", category: "Clothes", image: "images/77df67d6e7321e75104c6d43bbe2bd94.jpg", seller: "Chic Boutique", badge: "" },
        // Add more products for infinite scroll
        { id: 9, name: "Formal Men's Shoes", price: 95, location: "Addis Ababa", category: "Shoes", image: "images/a9c882ca498ea687eaff8c3f97959964.jpg", seller: "Gentlemen's Choice", badge: "" },
        { id: 10, name: "Luxury Wrist Watch", price: 300, location: "Addis Ababa", category: "Accessories", image: "images/95cd02a1a2255fdf385b012f390a5131.jpg", seller: "Timepiece Emporium", badge: "Top" },
        { id: 11, name: "Comfy Office Chair", price: 150, location: "Adama", category: "Furniture", image: "images/frenature.js", seller: "WorkSpace Pro", badge: "" },
        { id: 12, name: "Women's Running Sneakers", price: 70, location: "Addis Ababa", category: "Shoes", image: "images/ab9721a6ac114a5e6e37660d7ba90f5b.jpg", seller: "FitFeet", badge: "New" },
    ];

    // --- RENDER FUNCTIONS ---
    function renderCategories() {
        categoriesGrid.innerHTML = categories.map(cat => `
            <div class="category-card" data-category="${cat.name}">
                <i class="${cat.icon} fa-3x"></i>
                <h3>${cat.name}</h3>
            </div>
        `).join('');
    }
    
    function renderProducts(productsToRender) {
        const productHTML = productsToRender.map(prod => `
            <div class="product-card" data-id="${prod.id}">
                <div class="product-image-container">
                    <img src="${prod.image}" alt="${prod.name}" loading="lazy">
                    ${prod.badge ? `<div class="product-badge">${prod.badge}</div>` : ''}
                    <button class="quick-view-btn" aria-label="Quick View"><i class="fas fa-eye"></i></button>
                </div>
                <div class="product-info">
                    <h3>${prod.name}</h3>
                    <div class="price">$${prod.price.toFixed(2)}</div>
                    <div class="product-meta">
                        <span><i class="fas fa-map-marker-alt"></i> ${prod.location}</span> | 
                        <span>by <strong>${prod.seller}</strong></span>
                    </div>
                    <div class="product-actions">
                        <button class="add-to-cart-btn">Add to Cart</button>
                        <button class="wishlist-btn" aria-label="Add to Wishlist"><i class="far fa-heart"></i></button>
                    </div>
                </div>
            </div>
        `).join('');
        productGrid.innerHTML = productHTML;
    }

    // --- FILTERING & SORTING LOGIC ---
    const searchInput = document.getElementById('search-input');
    const sortButtons = document.querySelectorAll('.dropdown-menu li');
    const sortDisplay = document.querySelector('.filter-btn strong');

    let currentProducts = [...allProducts];
    let currentSort = 'relevance';

    function applyFilters() {
        let filtered = [...allProducts];
        const searchTerm = searchInput.value.toLowerCase();

        // Search filter
                if (searchTerm) {
            filtered = filtered.filter(p =>
                p.name.toLowerCase().includes(searchTerm) ||
                p.location.toLowerCase().includes(searchTerm) ||
                p.seller.toLowerCase().includes(searchTerm)
            );
        }

        // Sort
        switch (currentSort) {
            case 'latest':
                filtered.reverse();
                break;
            case 'price-asc':
                filtered.sort((a, b) => a.price - b.price);
                break;
            case 'price-desc':
                filtered.sort((a, b) => b.price - a.price);
                break;
        }
        
        // Animate grid update
        productGrid.style.opacity = '0';
        setTimeout(() => {
            currentProducts = filtered;
            renderProducts(currentProducts.slice(0, 8)); // Initial load
            productGrid.style.opacity = '1';
        }, 300);
        }
        
    searchInput.addEventListener('input', applyFilters);

    sortButtons.forEach(button => {
        button.addEventListener('click', () => {
            currentSort = button.dataset.sort;
            sortDisplay.textContent = button.textContent;
            applyFilters();
                });
            });

    // --- INFINITE SCROLL ---
    let isLoading = false;
    let productsToShow = 8;

    function loadMoreProducts() {
        if (isLoading) return;
        isLoading = true;
        loader.style.display = 'block';

        setTimeout(() => {
            const nextProducts = currentProducts.slice(productsToShow, productsToShow + 4);
            if (nextProducts.length > 0) {
                const nextHTML = nextProducts.map(prod => `
                    <div class="product-card" data-id="${prod.id}" style="animation-delay: ${Math.random() * 0.3}s">
                        <!-- ... same as renderProducts ... -->
                        <div class="product-image-container">
                            <img src="${prod.image}" alt="${prod.name}" loading="lazy">
                            ${prod.badge ? `<div class="product-badge">${prod.badge}</div>` : ''}
                        </div>
                        <div class="product-info">
                            <h3>${prod.name}</h3>
                            <div class="price">$${prod.price.toFixed(2)}</div>
                            <div class="product-meta">
                                <span><i class="fas fa-map-marker-alt"></i> ${prod.location}</span> | 
                                <span>by <strong>${prod.seller}</strong></span>
                                </div>
                                <button class="add-to-cart-btn">Add to Cart</button>
                                <button class="view-details-btn">View Full Details</button>
                            </div>
                        </div>
                    </div>
                `).join('');
                productGrid.insertAdjacentHTML('beforeend', nextHTML);
                productsToShow += nextProducts.length;
            } else {
                // No more products to load
                window.removeEventListener('scroll', onScroll);
            }
            loader.style.display = 'none';
            isLoading = false;
        }, 1000); // Simulate network delay
    }

    function onScroll() {
        if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 300) {
            loadMoreProducts();
            }
    }

    window.addEventListener('scroll', onScroll);

    // --- INITIAL RENDER ---
    renderCategories();
    renderProducts(currentProducts.slice(0, productsToShow));
});
