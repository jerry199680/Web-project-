<?php
session_start();
header('Content-Type: application/json');

require_once '../db_connect.php';

// --- Helper Functions ---
function send_response($status, $message, $data = []) {
    echo json_encode(['status' => $status, 'message' => $message, 'data' => $data]);
    exit();
}

function require_login() {
    if (!isset($_SESSION['user_id'])) {
        send_response('error', 'Authentication required. Please log in.');
    }
}

require_login(); // All cart operations require a logged-in user

$method = $_SERVER['REQUEST_METHOD'];
$user_id = $_SESSION['user_id'];

switch ($method) {
    case 'GET':
        // Fetch the user's cart
        $stmt = $conn->prepare(
            "SELECT c.product_id, c.quantity, p.name, p.price, p.image, u.fullname as seller_name
             FROM cart c
             JOIN products p ON c.product_id = p.id
             JOIN users u ON p.seller_id = u.id
             WHERE c.user_id = ?"
        );
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $cart_items = $result->fetch_all(MYSQLI_ASSOC);
        send_response('success', 'Cart items retrieved.', $cart_items);
        $stmt->close();
        break;

    case 'POST':
        // Add a product to the cart
        $product_id = $_POST['product_id'] ?? 0;
        $quantity = $_POST['quantity'] ?? 1;

        if ($product_id <= 0 || $quantity <= 0) {
            send_response('error', 'Invalid product ID or quantity.');
        }

        // Check if the item is already in the cart
        $stmt = $conn->prepare("SELECT quantity FROM cart WHERE user_id = ? AND product_id = ?");
        $stmt->bind_param("ii", $user_id, $product_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Update quantity if item exists
            $new_quantity = $result->fetch_assoc()['quantity'] + $quantity;
            $update_stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?");
            $update_stmt->bind_param("iii", $new_quantity, $user_id, $product_id);
            if ($update_stmt->execute()) {
                send_response('success', 'Product quantity updated in cart.');
            } else {
                send_response('error', 'Failed to update cart.');
            }
            $update_stmt->close();
        } else {
            // Insert new item if it doesn't exist
            $insert_stmt = $conn->prepare("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)");
            $insert_stmt->bind_param("iii", $user_id, $product_id, $quantity);
            if ($insert_stmt->execute()) {
                send_response('success', 'Product added to cart.');
            } else {
                send_response('error', 'Failed to add product to cart.');
            }
            $insert_stmt->close();
        }
        $stmt->close();
        break;

    case 'DELETE':
        // Remove an item from the cart
        // Note: Real DELETE requests are tricky from HTML forms. We'll use a POST request with a special parameter.
        // This is a common practice. For a true REST API, you'd configure the server to handle DELETE.
        send_response('error', 'Direct DELETE not supported. Use POST with _method=DELETE.');
        break;
        
    default:
        send_response('error', 'Invalid request method.');
        break;
}

// This part handles cart updates (quantity) and removals, using POST to simplify frontend forms.
if ($method === 'POST' && isset($_POST['_method'])) {
    $product_id = $_POST['product_id'] ?? 0;
    if ($product_id <= 0) {
        send_response('error', 'Invalid product ID.');
    }

    if ($_POST['_method'] === 'DELETE') {
        $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ? AND product_id = ?");
        $stmt->bind_param("ii", $user_id, $product_id);
        if ($stmt->execute()) {
            send_response('success', 'Product removed from cart.');
        } else {
            send_response('error', 'Failed to remove product from cart.');
        }
        $stmt->close();
    }

    if ($_POST['_method'] === 'PUT') {
        $quantity = $_POST['quantity'] ?? 0;
        if ($quantity <= 0) {
            // If quantity is zero or less, remove the item
            $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ? AND product_id = ?");
            $stmt->bind_param("ii", $user_id, $product_id);
        } else {
            // Otherwise, update the quantity
            $stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?");
            $stmt->bind_param("iii", $quantity, $user_id, $product_id);
        }
        
        if ($stmt->execute()) {
            send_response('success', 'Cart updated successfully.');
        } else {
            send_response('error', 'Failed to update cart.');
        }
        $stmt->close();
    }
}


$conn->close();
?>
