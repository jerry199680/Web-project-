// Checkout Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const checkoutForm = document.getElementById('checkoutForm');
    const orderItems = document.getElementById('orderItems');
    const deliverySummary = document.getElementById('deliverySummary');
    const paymentSummary = document.getElementById('paymentSummary');
    const summaryDetails = document.getElementById('summaryDetails');
    const orderNumber = document.getElementById('orderNumber');
    const orderTotal = document.getElementById('orderTotal');
    const estimatedDelivery = document.getElementById('estimatedDelivery');
    
    // State
    let currentStep = 1;
    let cart = [];
    let appliedCoupon = null;
    let orderData = {};
    
    // Initialize
    loadCartData();
    setupEventListeners();
    updateSummary();
    
    function setupEventListeners() {
        // Payment method change
        document.querySelectorAll('input[name="paymentMethod"]').forEach(radio => {
            radio.addEventListener('change', handlePaymentMethodChange);
        });
        
        // Form validation
        checkoutForm.addEventListener('submit', handleFormSubmit);
        
        // Real-time validation
        const requiredFields = ['firstName', 'lastName', 'email', 'phone', 'address', 'city', 'state'];
        requiredFields.forEach(fieldId => {
            const field = document.getElementById(fieldId);
            if (field) {
                field.addEventListener('blur', () => validateField(fieldId));
            }
        });
    }
    
    function loadCartData() {
        // Load cart from localStorage
        const savedCart = localStorage.getItem('checkoutCart');
        const savedCoupon = localStorage.getItem('appliedCoupon');
        
        if (savedCart) {
            cart = JSON.parse(savedCart);
        }
        
        if (savedCoupon) {
            appliedCoupon = JSON.parse(savedCoupon);
        }
        
        renderOrderItems();
    }
    
    function renderOrderItems() {
        if (cart.length === 0) {
            orderItems.innerHTML = '<p>No items in cart</p>';
            return;
        }
        
        orderItems.innerHTML = cart.map(item => `
            <div class="order-item">
                <div class="order-item-image">
                    <img src="${item.image}" alt="${item.title}">
                </div>
                <div class="order-item-details">
                    <div class="order-item-title">${item.title}</div>
                    <div class="order-item-seller">Sold by ${item.seller}</div>
                    <div class="order-item-price">ETB ${(item.price * item.quantity).toFixed(2)}</div>
                </div>
            </div>
        `).join('');
    }
    
    function updateSummary() {
        const subtotal = cart.reduce((total, item) => total + (item.price * item.quantity), 0);
        const shipping = calculateShipping(subtotal);
        const tax = (subtotal + shipping) * 0.15; // 15% tax
        let total = subtotal + shipping + tax;
        
        // Apply coupon discount if any
        let discountAmount = 0;
        if (appliedCoupon) {
            discountAmount = appliedCoupon.type === 'percentage' 
                ? (subtotal * appliedCoupon.value) / 100
                : appliedCoupon.value;
            total -= discountAmount;
        }
        
        summaryDetails.innerHTML = `
            <div class="summary-item">
                <span>Subtotal:</span>
                <span>ETB ${subtotal.toFixed(2)}</span>
            </div>
            <div class="summary-item">
                <span>Shipping:</span>
                <span>ETB ${shipping.toFixed(2)}</span>
            </div>
            <div class="summary-item">
                <span>Tax:</span>
                <span>ETB ${tax.toFixed(2)}</span>
            </div>
            ${discountAmount > 0 ? `
                <div class="summary-item">
                    <span>Discount:</span>
                    <span>-ETB ${discountAmount.toFixed(2)}</span>
                </div>
            ` : ''}
            <div class="summary-item total">
                <span>Total:</span>
                <span>ETB ${Math.max(0, total).toFixed(2)}</span>
            </div>
        `;
    }
    
    function calculateShipping(subtotal) {
        // Free shipping over ETB 1000
        if (subtotal >= 1000) return 0;
        
        // Calculate shipping based on number of unique sellers
        const uniqueSellers = new Set(cart.map(item => item.sellerId));
        return uniqueSellers.size * 50; // ETB 50 per seller
    }
    
    function nextStep(step) {
        if (validateCurrentStep()) {
            currentStep = step;
            updateStepDisplay();
            updateProgressSteps();
            
            if (step === 3) {
                updateReviewStep();
            }
        }
    }
    
    function prevStep(step) {
        currentStep = step;
        updateStepDisplay();
        updateProgressSteps();
    }
    
    function updateStepDisplay() {
        // Hide all steps
        document.querySelectorAll('.checkout-step').forEach(step => {
            step.classList.remove('active');
        });
        
        // Show current step
        document.getElementById(`step${currentStep}`).classList.add('active');
    }
    
    function updateProgressSteps() {
        document.querySelectorAll('.progress-step').forEach((step, index) => {
            const stepNumber = index + 1;
            step.classList.remove('active', 'completed');
            
            if (stepNumber < currentStep) {
                step.classList.add('completed');
            } else if (stepNumber === currentStep) {
                step.classList.add('active');
            }
        });
    }
    
    function validateCurrentStep() {
        switch (currentStep) {
            case 1:
                return validateShippingStep();
            case 2:
                return validatePaymentStep();
            case 3:
                return validateReviewStep();
            default:
                return true;
        }
    }
    
    function validateShippingStep() {
        const requiredFields = ['firstName', 'lastName', 'email', 'phone', 'address', 'city', 'state'];
        let isValid = true;
        
        requiredFields.forEach(fieldId => {
            const field = document.getElementById(fieldId);
            if (!field.value.trim()) {
                showFieldError(fieldId, 'This field is required');
                isValid = false;
            } else {
                clearFieldError(fieldId);
            }
        });
        
        // Validate email format
        const email = document.getElementById('email').value;
        if (email && !isValidEmail(email)) {
            showFieldError('email', 'Please enter a valid email address');
            isValid = false;
        }
        
        // Validate phone format
        const phone = document.getElementById('phone').value;
        if (phone && !isValidPhone(phone)) {
            showFieldError('phone', 'Please enter a valid phone number');
            isValid = false;
        }
        
        return isValid;
    }
    
    function validatePaymentStep() {
        const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked').value;
        let isValid = true;
        
        if (paymentMethod === 'stripe') {
            const cardFields = ['cardNumber', 'expiryDate', 'cvv', 'cardName'];
            cardFields.forEach(fieldId => {
                const field = document.getElementById(fieldId);
                if (!field.value.trim()) {
                    showFieldError(fieldId, 'This field is required');
                    isValid = false;
                } else {
                    clearFieldError(fieldId);
                }
            });
        } else if (paymentMethod === 'mobile') {
            const mobileFields = ['mobileProvider', 'mobileNumber'];
            mobileFields.forEach(fieldId => {
                const field = document.getElementById(fieldId);
                if (!field.value.trim()) {
                    showFieldError(fieldId, 'This field is required');
                    isValid = false;
                } else {
                    clearFieldError(fieldId);
                }
            });
        }
        
        return isValid;
    }
    
    function validateReviewStep() {
        const termsAgreement = document.getElementById('termsAgreement');
        if (!termsAgreement.checked) {
            alert('Please agree to the Terms of Service and Privacy Policy');
            return false;
        }
        return true;
    }
    
    function validateField(fieldId) {
        const field = document.getElementById(fieldId);
        if (!field.value.trim()) {
            showFieldError(fieldId, 'This field is required');
            return false;
        }
        
        // Specific validations
        if (fieldId === 'email' && !isValidEmail(field.value)) {
            showFieldError(fieldId, 'Please enter a valid email address');
            return false;
        }
        
        if (fieldId === 'phone' && !isValidPhone(field.value)) {
            showFieldError(fieldId, 'Please enter a valid phone number');
            return false;
        }
        
        clearFieldError(fieldId);
        return true;
    }
    
    function showFieldError(fieldId, message) {
        clearFieldError(fieldId);
        
        const field = document.getElementById(fieldId);
        const errorElement = document.createElement('div');
        errorElement.className = 'field-error';
        errorElement.textContent = message;
        errorElement.style.color = 'var(--error-color)';
        errorElement.style.fontSize = '0.8rem';
        errorElement.style.marginTop = '5px';
        
        field.parentNode.appendChild(errorElement);
        field.style.borderColor = 'var(--error-color)';
    }
    
    function clearFieldError(fieldId) {
        const field = document.getElementById(fieldId);
        const errorElement = field.parentNode.querySelector('.field-error');
        if (errorElement) {
            errorElement.remove();
        }
        field.style.borderColor = 'var(--border-color)';
    }
    
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
    
    function isValidPhone(phone) {
        const phoneRegex = /^\+?[1-9]\d{1,14}$/;
        return phoneRegex.test(phone.replace(/\s/g, ''));
    }
    
    function handlePaymentMethodChange() {
        const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked').value;
        
        // Hide all payment detail sections
        document.getElementById('cardDetails').style.display = 'none';
        document.getElementById('mobileDetails').style.display = 'none';
        
        // Show relevant section
        if (paymentMethod === 'stripe') {
            document.getElementById('cardDetails').style.display = 'block';
        } else if (paymentMethod === 'mobile') {
            document.getElementById('mobileDetails').style.display = 'block';
        }
    }
    
    function updateReviewStep() {
        // Update delivery summary
        const formData = new FormData(checkoutForm);
        const deliveryMethod = document.querySelector('input[name="deliveryMethod"]:checked').value;
        
        deliverySummary.innerHTML = `
            <p><strong>Name:</strong> ${formData.get('firstName')} ${formData.get('lastName')}</p>
            <p><strong>Email:</strong> ${formData.get('email')}</p>
            <p><strong>Phone:</strong> ${formData.get('phone')}</p>
            <p><strong>Address:</strong> ${formData.get('address')}, ${formData.get('city')}, ${formData.get('state')}</p>
            <p><strong>Delivery Method:</strong> ${deliveryMethod === 'standard' ? 'Standard (5-7 days)' : 'Express (2-3 days)'}</p>
        `;
        
        // Update payment summary
        const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked').value;
        let paymentText = '';
        
        if (paymentMethod === 'stripe') {
            const cardNumber = formData.get('cardNumber');
            paymentText = `Card ending in ${cardNumber.slice(-4)}`;
        } else if (paymentMethod === 'mobile') {
            paymentText = `${formData.get('mobileProvider')} - ${formData.get('mobileNumber')}`;
        } else {
            paymentText = 'Bank Transfer';
        }
        
        paymentSummary.innerHTML = `
            <p><strong>Payment Method:</strong> ${paymentText}</p>
        `;
    }
    
    function placeOrder() {
        if (!validateCurrentStep()) {
            return;
        }
        
        // Collect order data
        const formData = new FormData(checkoutForm);
        orderData = {
            shipping: {
                firstName: formData.get('firstName'),
                lastName: formData.get('lastName'),
                email: formData.get('email'),
                phone: formData.get('phone'),
                address: formData.get('address'),
                city: formData.get('city'),
                state: formData.get('state'),
                postalCode: formData.get('postalCode'),
                country: formData.get('country')
            },
            delivery: {
                method: formData.get('deliveryMethod')
            },
            payment: {
                method: formData.get('paymentMethod'),
                cardNumber: formData.get('cardNumber'),
                expiryDate: formData.get('expiryDate'),
                cvv: formData.get('cvv'),
                cardName: formData.get('cardName'),
                mobileProvider: formData.get('mobileProvider'),
                mobileNumber: formData.get('mobileNumber')
            },
            items: cart,
            appliedCoupon: appliedCoupon
        };
        
        // Process order
        processOrder();
    }
    
    async function processOrder() {
        try {
            // Show loading state
            const placeOrderBtn = document.querySelector('button[onclick="placeOrder()"]');
            const originalText = placeOrderBtn.innerHTML;
            placeOrderBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
            placeOrderBtn.disabled = true;
            
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            // Generate order number
            const orderNum = 'ETB-' + Date.now().toString().slice(-8);
            
            // Calculate estimated delivery
            const deliveryMethod = orderData.delivery.method;
            const deliveryDays = deliveryMethod === 'express' ? 3 : 7;
            const deliveryDate = new Date();
            deliveryDate.setDate(deliveryDate.getDate() + deliveryDays);
            
            // Update order complete step
            orderNumber.textContent = orderNum;
            orderTotal.textContent = summaryDetails.querySelector('.summary-item.total span:last-child').textContent;
            estimatedDelivery.textContent = deliveryDate.toLocaleDateString();
            
            // Move to complete step
            currentStep = 4;
            updateStepDisplay();
            updateProgressSteps();
            
            // Clear cart
            localStorage.removeItem('cart');
            localStorage.removeItem('checkoutCart');
            localStorage.removeItem('appliedCoupon');
            
        } catch (error) {
            console.error('Error processing order:', error);
            alert('An error occurred while processing your order. Please try again.');
            
            // Reset button
            const placeOrderBtn = document.querySelector('button[onclick="placeOrder()"]');
            placeOrderBtn.innerHTML = originalText;
            placeOrderBtn.disabled = false;
        }
    }
    
    function handleFormSubmit(e) {
        e.preventDefault();
        placeOrder();
    }
    
    // Make functions globally available
    window.nextStep = nextStep;
    window.prevStep = prevStep;
    window.placeOrder = placeOrder;
});
