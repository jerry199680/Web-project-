<?php
session_start();
include_once '../../db_connect.php';

header('Content-Type: application/json');

// Check if seller is logged in
if (!isset($_SESSION['seller_id'])) {
    echo json_encode(['error' => 'Seller not authenticated']);
    exit;
}

$seller_id = $_SESSION['seller_id'];

// Fetch seller profile from the database
$query = "SELECT name, email, avatar_url, unread_notifications, unread_messages FROM sellers WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $seller_profile = $result->fetch_assoc();
    echo json_encode($seller_profile);
} else {
    echo json_encode(['error' => 'Seller profile not found']);
}

$stmt->close();
$conn->close();
?>
