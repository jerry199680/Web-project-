<?php
header('Content-Type: application/json');

// Include database connection
require_once 'db_connect.php';

/**
 * Send a formatted JSON response
 * @param string $status Success or error status
 * @param string $message Response message
 * @param array $data Optional data to include in response
 * @param int $http_code HTTP status code
 */
function send_response($status, $message, $data = [], $http_code = 200) {
    http_response_code($http_code);
    echo json_encode([
        'status' => $status, 
        'message' => $message, 
        'data' => $data
    ]);
    exit();
}

// Check database connection
if ($conn->connect_error) {
    send_response('error', 'Database connection failed: ' . $conn->connect_error, [], 500);
}

// Set default values for pagination
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 12;
$offset = ($page - 1) * $limit;

// Validate pagination parameters
if ($page < 1) $page = 1;
if ($limit < 1 || $limit > 50) $limit = 12; // Limit between 1 and 50

// Initialize response data
$response_data = [
    'categories' => [],
    'products' => [],
    'pagination' => [
        'current_page' => $page,
        'per_page' => $limit,
        'total_items' => 0,
        'total_pages' => 0
    ],
    'filters' => []
];

// Get all categories
try {
    $categories_query = "SELECT * FROM categories ORDER BY name ASC";
    $categories_result = $conn->query($categories_query);
    
    if (!$categories_result) {
        throw new Exception("Error fetching categories: " . $conn->error);
    }
    
    $response_data['categories'] = $categories_result->fetch_all(MYSQLI_ASSOC);
} catch (Exception $e) {
    send_response('error', $e->getMessage(), [], 500);
}

// Build products query with filters
$products_query = "SELECT p.*, c.name as category_name, u.fullname as seller_name, u.avatar as seller_avatar 
                  FROM products p 
                  JOIN categories c ON p.category_id = c.id 
                  JOIN users u ON p.seller_id = u.id 
                  WHERE 1=1";

$count_query = "SELECT COUNT(*) as total FROM products p WHERE 1=1";
$query_params = [];

// Apply filters
$applied_filters = [];

// Category filter
if (isset($_GET['category_id']) && !empty($_GET['category_id'])) {
    $category_id = (int)$_GET['category_id'];
    $products_query .= " AND p.category_id = ?";
    $count_query .= " AND p.category_id = ?";
    $query_params[] = $category_id;
    $applied_filters['category_id'] = $category_id;
}

// Price range filter
if (isset($_GET['min_price']) && is_numeric($_GET['min_price'])) {
    $min_price = (float)$_GET['min_price'];
    $products_query .= " AND p.price >= ?";
    $count_query .= " AND p.price >= ?";
    $query_params[] = $min_price;
    $applied_filters['min_price'] = $min_price;
}

if (isset($_GET['max_price']) && is_numeric($_GET['max_price'])) {
    $max_price = (float)$_GET['max_price'];
    $products_query .= " AND p.price <= ?";
    $count_query .= " AND p.price <= ?";
    $query_params[] = $max_price;
    $applied_filters['max_price'] = $max_price;
}

// Location filter
if (isset($_GET['location']) && !empty($_GET['location'])) {
    $location = '%' . $conn->real_escape_string($_GET['location']) . '%';
    $products_query .= " AND p.address LIKE ?";
    $count_query .= " AND p.address LIKE ?";
    $query_params[] = $location;
    $applied_filters['location'] = $_GET['location'];
}

// Search term
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = '%' . $conn->real_escape_string($_GET['search']) . '%';
    $products_query .= " AND (p.name LIKE ? OR p.description LIKE ?)";
    $count_query .= " AND (p.name LIKE ? OR p.description LIKE ?)";
    $query_params[] = $search;
    $query_params[] = $search;
    $applied_filters['search'] = $_GET['search'];
}

// Apply sorting
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'relevance';
$applied_filters['sort'] = $sort;

switch ($sort) {
    case 'price_asc':
        $products_query .= " ORDER BY p.price ASC";
        break;
    case 'price_desc':
        $products_query .= " ORDER BY p.price DESC";
        break;
    case 'newest':
        $products_query .= " ORDER BY p.created_at DESC";
        break;
    case 'relevance':
    default:
        // For relevance, we could implement a more complex scoring system
        // For now, we'll use a combination of newest and potentially featured items
        $products_query .= " ORDER BY p.created_at DESC";
        break;
}

// Add pagination
$products_query .= " LIMIT ?, ?";
$query_params[] = $offset;
$query_params[] = $limit;

// Store applied filters in response
$response_data['filters'] = $applied_filters;

// Get total count for pagination
try {
    $stmt = $conn->prepare($count_query);
    
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    if (!empty($query_params)) {
        // Create parameter types string (s for string, i for integer, d for double)
        $types = '';
        foreach ($query_params as $param) {
            if (is_int($param)) {
                $types .= 'i';
            } elseif (is_float($param)) {
                $types .= 'd';
            } else {
                $types .= 's';
            }
        }
        
        // Remove pagination parameters as they're not needed for count query
        $count_params = array_slice($query_params, 0, -2);
        
        if (!empty($count_params)) {
            $count_types = substr($types, 0, -2);
            $stmt->bind_param($count_types, ...$count_params);
        }
    }
    
    $stmt->execute();
    $count_result = $stmt->get_result();
    $total_row = $count_result->fetch_assoc();
    $total_items = $total_row['total'];
    
    // Update pagination info
    $response_data['pagination']['total_items'] = $total_items;
    $response_data['pagination']['total_pages'] = ceil($total_items / $limit);
    
    $stmt->close();
} catch (Exception $e) {
    send_response('error', 'Error counting products: ' . $e->getMessage(), [], 500);
}

// Get products with pagination and filters
try {
    $stmt = $conn->prepare($products_query);
    
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    if (!empty($query_params)) {
        // Create parameter types string
        $types = '';
        foreach ($query_params as $param) {
            if (is_int($param)) {
                $types .= 'i';
            } elseif (is_float($param)) {
                $types .= 'd';
            } else {
                $types .= 's';
            }
        }
        
        $stmt->bind_param($types, ...$query_params);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    $products = $result->fetch_all(MYSQLI_ASSOC);
    
    // Format product data
    foreach ($products as &$product) {
        // Add any additional formatting here if needed
        $product['price'] = (float)$product['price']; // Convert price to float
    }
    
    $response_data['products'] = $products;
    $stmt->close();
} catch (Exception $e) {
    send_response('error', 'Error fetching products: ' . $e->getMessage(), [], 500);
}

// Send successful response
send_response('success', 'Categories and products retrieved successfully.', $response_data);

$conn->close();
?>
