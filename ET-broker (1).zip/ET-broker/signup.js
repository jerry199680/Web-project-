// Signup Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const signupForm = document.getElementById('signupForm');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirmPassword');
    const passwordToggle = document.getElementById('passwordToggle');
    const confirmPasswordToggle = document.getElementById('confirmPasswordToggle');
    const strengthFill = document.getElementById('strengthFill');
    const strengthText = document.getElementById('strengthText');
    const avatarPreview = document.getElementById('avatarPreview');
    const avatarUploadBtn = document.getElementById('avatarUploadBtn');
    const avatarInput = document.getElementById('avatar');
    const roleInputs = document.querySelectorAll('input[name="role"]');
    const adminPasscodeGroup = document.getElementById('adminPasscodeGroup');
    const submitBtn = document.getElementById('submitBtn');
    const successModal = document.getElementById('successModal');

    // Password strength checker
    function checkPasswordStrength(password) {
        let strength = 0;
        let feedback = [];

        if (password.length >= 8) strength++;
        else feedback.push('At least 8 characters');

        if (/[a-z]/.test(password)) strength++;
        else feedback.push('Lowercase letter');

        if (/[A-Z]/.test(password)) strength++;
        else feedback.push('Uppercase letter');

        if (/[0-9]/.test(password)) strength++;
        else feedback.push('Number');

        if (/[^A-Za-z0-9]/.test(password)) strength++;
        else feedback.push('Special character');

        return { strength, feedback };
    }

    // Update password strength indicator
    function updatePasswordStrength() {
        const password = passwordInput.value;
        const { strength, feedback } = checkPasswordStrength(password);

        strengthFill.className = 'strength-fill';
        
        if (password.length === 0) {
            strengthText.textContent = 'Password strength';
            return;
        }

        if (strength <= 2) {
            strengthFill.classList.add('weak');
            strengthText.textContent = 'Weak password';
        } else if (strength === 3) {
            strengthFill.classList.add('fair');
            strengthText.textContent = 'Fair password';
        } else if (strength === 4) {
            strengthFill.classList.add('good');
            strengthText.textContent = 'Good password';
        } else {
            strengthFill.classList.add('strong');
            strengthText.textContent = 'Strong password';
        }
    }

    // Password toggle functionality
    function togglePasswordVisibility(input, toggle) {
        const isPassword = input.type === 'password';
        input.type = isPassword ? 'text' : 'password';
        toggle.querySelector('i').className = isPassword ? 'fas fa-eye-slash' : 'fas fa-eye';
    }

    // Avatar upload functionality
    function handleAvatarUpload() {
        const file = avatarInput.files[0];
        if (file) {
            // Validate file type
            if (!file.type.startsWith('image/')) {
                showError('avatar-error', 'Please select a valid image file');
                return;
            }
            
            // Validate file size (5MB max)
            if (file.size > 5 * 1024 * 1024) {
                showError('avatar-error', 'File size must be less than 5MB');
                return;
            }
            
            const reader = new FileReader();
            reader.onload = function(e) {
                avatarPreview.innerHTML = `<img src="${e.target.result}" alt="Profile Picture">`;
                hideError('avatar-error');
            };
            reader.readAsDataURL(file);
        }
    }

    // Form validation
    function validateForm() {
        let isValid = true;
        const formData = new FormData(signupForm);

        // Clear previous errors
        clearAllErrors();

        // Validate full name
        const fullname = formData.get('fullname');
        if (!fullname || fullname.length < 2) {
            showError('fullname-error', 'Full name must be at least 2 characters');
            isValid = false;
        }
        
        // Validate email
        const email = formData.get('email');
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!email || !emailRegex.test(email)) {
            showError('email-error', 'Please enter a valid email address');
            isValid = false;
        }
        
        // Validate phone
        const phone = formData.get('phone');
        const phoneRegex = /^\+251[0-9]{9}$/;
        if (!phone || !phoneRegex.test(phone.replace(/\s/g, ''))) {
            showError('phone-error', 'Please enter a valid Ethiopian phone number (+251XXXXXXXXX)');
            isValid = false;
        }
        
        // Validate password
        const password = formData.get('password');
        const { strength } = checkPasswordStrength(password);
        if (!password || password.length < 8) {
            showError('password-error', 'Password must be at least 8 characters');
            isValid = false;
        } else if (strength < 3) {
            showError('password-error', 'Password is too weak. Please use a stronger password');
            isValid = false;
        }
        
        // Validate confirm password
        const confirmPassword = formData.get('confirmPassword');
        if (password !== confirmPassword) {
            showError('confirmPassword-error', 'Passwords do not match');
            isValid = false;
        }
        
        // Validate admin passcode if admin role is selected
        const role = formData.get('role');
        if (role === 'admin') {
            const adminPasscode = formData.get('adminPasscode');
            if (!adminPasscode) {
                showError('adminPasscode-error', 'Admin passcode is required');
                isValid = false;
            }
        }

        // Validate terms
        const terms = formData.get('terms');
        if (!terms) {
            showError('terms-error', 'You must agree to the terms and conditions');
            isValid = false;
        }
        
        return isValid;
    }
    
    // Show error message
    function showError(errorId, message) {
        const errorElement = document.getElementById(errorId);
        if (errorElement) {
            errorElement.textContent = message;
            errorElement.classList.add('show');
        }
        
        // Add error class to parent form group
        const formGroup = errorElement?.closest('.form-group');
        if (formGroup) {
            formGroup.classList.add('error');
        }
    }

    // Hide error message
    function hideError(errorId) {
        const errorElement = document.getElementById(errorId);
        if (errorElement) {
            errorElement.classList.remove('show');
        }
        
        // Remove error class from parent form group
        const formGroup = errorElement?.closest('.form-group');
        if (formGroup) {
            formGroup.classList.remove('error');
        }
    }

    // Clear all errors
    function clearAllErrors() {
        const errorElements = document.querySelectorAll('.error-message');
        errorElements.forEach(error => {
            error.classList.remove('show');
        });
        
        const formGroups = document.querySelectorAll('.form-group');
        formGroups.forEach(group => {
            group.classList.remove('error');
        });
    }

    // Real-time email validation
    async function validateEmailUniqueness(email) {
        try {
            const response = await fetch('backend/api.php/users/check-email', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email })
            });
            
            const result = await response.json();
            return result.available;
        } catch (error) {
            console.error('Email validation error:', error);
            return true; // Assume available if check fails
        }
    }

    // Real-time phone validation
    async function validatePhoneUniqueness(phone) {
        try {
            const response = await fetch('backend/api.php/users/check-phone', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ phone })
            });
            
            const result = await response.json();
            return result.available;
        } catch (error) {
            console.error('Phone validation error:', error);
            return true; // Assume available if check fails
        }
    }

    // Submit form
    async function submitForm() {
        if (!validateForm()) {
            return;
        }

        const formData = new FormData(signupForm);
        
        // Show loading state
        submitBtn.disabled = true;
        submitBtn.querySelector('.btn-text').style.display = 'none';
        submitBtn.querySelector('.btn-loading').style.display = 'flex';

        try {
            const response = await fetch('backend/api.php/users/signup', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                // Show success modal
                successModal.classList.add('show');
                
                // Store user data in localStorage
                localStorage.setItem('user', JSON.stringify(result.user));
                localStorage.setItem('token', result.token);
            } else {
                // Show error messages
                if (result.errors) {
                    Object.keys(result.errors).forEach(field => {
                        showError(`${field}-error`, result.errors[field]);
                    });
                } else {
                    alert(result.message || 'An error occurred. Please try again.');
                }
            }
        } catch (error) {
            console.error('Signup error:', error);
            alert('An error occurred. Please try again.');
        } finally {
            // Hide loading state
            submitBtn.disabled = false;
            submitBtn.querySelector('.btn-text').style.display = 'block';
            submitBtn.querySelector('.btn-loading').style.display = 'none';
        }
    }

    // Event Listeners
    passwordInput.addEventListener('input', updatePasswordStrength);
    
    passwordToggle.addEventListener('click', () => {
        togglePasswordVisibility(passwordInput, passwordToggle);
    });
    
    confirmPasswordToggle.addEventListener('click', () => {
        togglePasswordVisibility(confirmPasswordInput, confirmPasswordToggle);
    });

    avatarUploadBtn.addEventListener('click', () => {
        avatarInput.click();
    });

    avatarInput.addEventListener('change', handleAvatarUpload);

    // Role selection
    roleInputs.forEach(input => {
        input.addEventListener('change', function() {
            if (this.value === 'admin') {
                adminPasscodeGroup.style.display = 'block';
            } else {
                adminPasscodeGroup.style.display = 'none';
            }
        });
    });

    // Real-time validation
    const emailInput = document.getElementById('email');
    const phoneInput = document.getElementById('phone');

    let emailTimeout, phoneTimeout;

    emailInput.addEventListener('input', function() {
        clearTimeout(emailTimeout);
        emailTimeout = setTimeout(async () => {
            const email = this.value;
            if (email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                const isAvailable = await validateEmailUniqueness(email);
                if (!isAvailable) {
                    showError('email-error', 'This email is already registered');
                } else {
                    hideError('email-error');
                }
            }
        }, 500);
    });

    phoneInput.addEventListener('input', function() {
        clearTimeout(phoneTimeout);
        phoneTimeout = setTimeout(async () => {
            const phone = this.value.replace(/\s/g, '');
            if (phone && /^\+251[0-9]{9}$/.test(phone)) {
                const isAvailable = await validatePhoneUniqueness(phone);
                if (!isAvailable) {
                    showError('phone-error', 'This phone number is already registered');
            } else {
                    hideError('phone-error');
                }
            }
        }, 500);
    });

    // Form submission
    signupForm.addEventListener('submit', function(e) {
        e.preventDefault();
        submitForm();
    });

    // Google sign up
    document.querySelector('.google-btn').addEventListener('click', function() {
        // Implement Google OAuth
        alert('Google sign up will be implemented soon');
    });

    // Close modal
    successModal.addEventListener('click', function(e) {
        if (e.target === successModal) {
            successModal.classList.remove('show');
        }
    });
});