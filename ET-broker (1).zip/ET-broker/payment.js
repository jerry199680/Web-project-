document.addEventListener('DOMContentLoaded', () => {
    const tabs = document.querySelectorAll('.tab-link');
    const contents = document.querySelectorAll('.tab-content');
    const payNowBtn = document.getElementById('pay-now-btn');
    const modal = document.getElementById('payment-modal');
    const modalCloseBtn = document.getElementById('modal-close-btn');
    const modalRetryBtn = document.getElementById('modal-retry-btn');
    const termsCheckbox = document.getElementById('terms-agree');

    // --- Tab Switching Logic ---
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(item => item.classList.remove('active'));
            contents.forEach(item => item.classList.remove('active'));

            tab.classList.add('active');
            document.getElementById(tab.dataset.tab).classList.add('active');
        });
    });

    // --- Form Validation & Pay Button State ---
    const checkFormValidity = () => {
        const activeForm = document.querySelector('.tab-content.active form');
        let isFormValid = true;
        if (activeForm) {
            isFormValid = activeForm.checkValidity();
        }
        payNowBtn.disabled = !(isFormValid && termsCheckbox.checked);
    };

    document.querySelectorAll('form input, form select').forEach(input => {
        input.addEventListener('input', checkFormValidity);
    });
    termsCheckbox.addEventListener('change', checkFormValidity);

    // --- Payment Simulation Logic ---
    payNowBtn.addEventListener('click', () => {
        // Simulate a network request
        showModal('processing');
        
        // Simulate different outcomes
        const paymentOutcome = Math.random(); // Random number between 0 and 1

        setTimeout(() => {
            if (paymentOutcome < 0.7) { // 70% chance of success
                showModal('success');
                // In a real app, you'd redirect or update the UI here
                // e.g., window.location.href = '/order-confirmation';
            } else if (paymentOutcome < 0.9) { // 20% chance of failure
                showModal('failure');
            } else { // 10% chance of network error
                showModal('network_error');
            }
        }, 2500); // Simulate 2.5 second delay
    });

    // --- Modal Handling ---
    const showModal = (status) => {
        const modalIcon = document.getElementById('modal-icon');
        const modalTitle = document.getElementById('modal-title');
        const modalMessage = document.getElementById('modal-message');

        modalRetryBtn.classList.add('hidden');
        modalIcon.innerHTML = '';

        switch (status) {
            case 'processing':
                modalIcon.innerHTML = '<div class="loader"></div>'; // Simple CSS loader
                modalTitle.textContent = 'Processing Payment...';
                modalMessage.textContent = 'Please wait while we securely process your transaction.';
                break;
            case 'success':
                modalIcon.innerHTML = '<i class="fas fa-check-circle" style="color: var(--success-color);"></i>';
                modalTitle.textContent = 'Payment Successful!';
                modalMessage.textContent = 'Your product is now active. A receipt has been sent to your email.';
                break;
            case 'failure':
                modalIcon.innerHTML = '<i class="fas fa-times-circle" style="color: var(--error-color);"></i>';
                modalTitle.textContent = 'Payment Failed';
                modalMessage.textContent = 'Your payment could not be processed. Please check your details and try again.';
                modalRetryBtn.classList.remove('hidden');
                break;
            case 'network_error':
                modalIcon.innerHTML = '<i class="fas fa-exclamation-triangle" style="color: #f39c12;"></i>';
                modalTitle.textContent = 'Network Issue';
                modalMessage.textContent = 'We had trouble connecting. Your payment will be retried automatically. Your product draft has been saved.';
                break;
        }
        
        modal.style.display = 'flex';
        addLoaderStyle(); // Inject loader CSS if needed
    };

    const closeModal = () => {
        modal.style.display = 'none';
    };

    modalCloseBtn.addEventListener('click', closeModal);
    modalRetryBtn.addEventListener('click', () => {
        closeModal();
        payNowBtn.click(); // Simulate clicking the pay button again
    });

    // Add CSS for the loader dynamically
    const addLoaderStyle = () => {
        if (!document.getElementById('loader-style')) {
            const style = document.createElement('style');
            style.id = 'loader-style';
            style.innerHTML = `
                .loader {
                    border: 4px solid #f3f3f3;
                    border-top: 4px solid var(--primary-color);
                    border-radius: 50%;
                    width: 40px;
                    height: 40px;
                    animation: spin 1s linear infinite;
                    margin: 0 auto 15px auto;
                }
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            `;
            document.head.appendChild(style);
        }
    };

    // Initial check
    checkFormValidity();
});
