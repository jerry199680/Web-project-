document.addEventListener('DOMContentLoaded', () => {
 
    let state = {
        admin: { name: 'Admin', profilePic: 'images/a9a28572d7d010e5403ceb9b76d575f5.jpg' },
        kpis: { totalUsers: 1250, totalSellers: 350, activeListings: 5600, transactionsToday: 89, platformRevenue: 15200, pendingApprovals: 12 },
        users: [
            { id: 'U001', name: 'John Doe', email: 'john.doe@example.com', date: '2023-10-01' },
            { id: 'U002', name: 'Jane Smith', email: 'jane.smith@example.com', date: '2023-09-15' },
        ],
        sellers: [
            { id: 'S001', name: 'Gadget World', email: 'contact@gadgetworld.com', date: '2023-08-20', status: 'Approved' },
            { id: 'S002', name: 'Fashion Hub', email: 'support@fashionhub.com', date: '2023-10-05', status: 'Pending' },
        ],
        products: [
            { id: 'P001', name: 'Modern Chair', seller: 'Gadget World', price: 150.00, stock: 50, status: 'InStock' },
            { id: 'P002', name: 'Vintage Lamp', seller: 'Fashion Hub', price: 75.50, stock: 8, status: 'LowStock' },
            { id: 'P003', name: 'Minimalist Desk', seller: 'Gadget World', price: 320.00, stock: 0, status: 'OutOfStock' },
        ],
        recentOrders: [
            { id: '#12345', product: 'Modern Chair', customer: 'John Doe', date: '2023-10-27', amount: 150.00, status: 'Paid', productImg: 'images/air1.jpg' },
            { id: '#12346', product: 'Vintage Lamp', customer: 'Jane Smith', date: '2023-10-27', amount: 75.50, status: 'Pending', productImg: 'images/air2.jpg' },
        ],
        transactions: [
            { transId: 'T001', orderId: '#12345', date: '2023-10-27', gross: 150.00, fee: 15.00, net: 135.00, status: 'Completed' },
            { transId: 'T002', orderId: '#12346', date: '2023-10-27', gross: 75.50, fee: 7.55, net: 67.95, status: 'Completed' },
            { transId: 'T003', orderId: '#12348', date: '2023-10-28', gross: 500.00, fee: 50.00, net: 450.00, status: 'Pending' },
        ],
        feeRules: [
            { id: 1, category: 'Electronics', type: 'percentage', value: 10 },
            { id: 2, category: 'Fashion', type: 'percentage', value: 12 },
            { id: 3, category: 'Home Goods', type: 'fixed', value: 5.00 },
            { id: 4, category: 'Default', type: 'percentage', value: 8 },
        ],
        salesData: {
            '7': { labels: ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6', 'Day 7'], data: [15, 25, 20, 30, 28, 35, 40] },
            '30': { labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'], data: [150, 180, 220, 250] },
            '180': { labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'], data: [50, 80, 120, 100, 150, 180] }
        }
    };

   
    const render = () => {
        loadAdminInfo();
        loadKpis();
        populateTable('recent-orders-table', state.recentOrders, orderRowDashboard);
        populateTable('users-table', state.users, userRow);
        populateTable('sellers-table', state.sellers, sellerRow);
        populateTable('products-table', state.products, productRow);
        populateTable('transactions-table', state.transactions, transactionRow);
        populateTable('fee-rules-table', state.feeRules, feeRuleRow);
    };

    const loadAdminInfo = () => {
        document.getElementById('admin-name').textContent = state.admin.name;
        document.getElementById('admin-profile-pic').src = state.admin.profilePic;
    };

    const loadKpis = () => {
        Object.keys(state.kpis).forEach(key => {
            const element = document.getElementById(key.replace(/([A-Z])/g, '-$1').toLowerCase());
            if (element) element.textContent = (key === 'platformRevenue' ? '$' : '') + state.kpis[key].toLocaleString();
        });
    };

    const populateTable = (tableId, data, rowGenerator) => {
        const tableBody = document.querySelector(`#${tableId} tbody`);
        if (tableBody) tableBody.innerHTML = data.map(rowGenerator).join('');
    };

    // --- TABLE ROW GENERATORS ---
    const createActionButtons = (id, type) => `<td class="action-buttons"><a href="#" title="Edit" class="edit-${type}" data-id="${id}"><i class="fas fa-edit"></i></a><a href="#" title="Delete" class="delete-${type}" data-id="${id}"><i class="fas fa-trash"></i></a></td>`;
    const userRow = user => `<tr><td>${user.id}</td><td>${user.name}</td><td>${user.email}</td><td>${user.date}</td>${createActionButtons(user.id, 'user')}</tr>`;
    const sellerRow = seller => `<tr><td>${seller.id}</td><td>${seller.name}</td><td>${seller.email}</td><td>${seller.date}</td><td><span class="status ${seller.status.toLowerCase()}">${seller.status}</span></td>${createActionButtons(seller.id, 'seller')}</tr>`;
    const productRow = p => `<tr><td>${p.id}</td><td>${p.name}</td><td>${p.seller}</td><td>$${p.price.toFixed(2)}</td><td>${p.stock}</td><td><span class="status ${p.status.toLowerCase().replace('outofstock', 'out-of-stock')}">${p.status.replace('OutOfStock', 'Out of Stock')}</span></td>${createActionButtons(p.id, 'product')}</tr>`;
    const orderRowDashboard = order => `<tr><td>${order.id}</td><td><div class="product-info"><img src="${order.productImg}" alt="Product"><span>${order.product}</span></div></td><td>${order.customer}</td><td>${order.date}</td><td>$${order.amount.toFixed(2)}</td><td><span class="status ${order.status.toLowerCase()}">${order.status}</span></td></tr>`;
    const transactionRow = t => `<tr><td>${t.transId}</td><td>${t.orderId}</td><td>${t.date}</td><td>$${t.gross.toFixed(2)}</td><td>$${t.fee.toFixed(2)}</td><td>$${t.net.toFixed(2)}</td><td><span class="status ${t.status.toLowerCase()}">${t.status}</span></td></tr>`;
    const feeRuleRow = rule => `<tr><td>${rule.category}</td><td>${rule.type === 'percentage' ? `${rule.value}%` : `$${rule.value.toFixed(2)}`}</td>${createActionButtons(rule.id, 'fee-rule')}</tr>`;

    // --- VIEW SWITCHING ---
    const switchView = viewId => {
        document.querySelectorAll('.view-container').forEach(c => c.classList.remove('active'));
        document.getElementById(`${viewId}-view`).classList.add('active');
        document.querySelectorAll('.sidebar-nav li').forEach(li => li.classList.remove('active'));
        document.querySelector(`.sidebar-nav a[data-view="${viewId}"]`).parentElement.classList.add('active');
    };

    // --- CHARTS ---
    let productSalesChart;
    const initCharts = () => {
        if (document.getElementById('productSalesChart')) {
            const salesCtx = document.getElementById('productSalesChart').getContext('2d');
            productSalesChart = new Chart(salesCtx, { type: 'line', data: { labels: state.salesData['180'].labels, datasets: [{ label: 'Sales', data: state.salesData['180'].data, borderColor: '#43a047', backgroundColor: 'rgba(67, 160, 71, 0.1)', fill: true, tension: 0.4 }] }, options: { responsive: true, maintainAspectRatio: false } });
        }
        if (document.getElementById('trafficSourcesChart')) new Chart(document.getElementById('trafficSourcesChart').getContext('2d'), { type: 'pie', data: { labels: ['Social Media', 'Search Engines', 'Direct'], datasets: [{ data: [45, 35, 20], backgroundColor: ['#1e88e5', '#fb8c00', '#43a047'] }] }, options: { responsive: true, maintainAspectRatio: false } });
        if (document.getElementById('topCategoriesChart')) new Chart(document.getElementById('topCategoriesChart').getContext('2d'), { type: 'bar', data: { labels: ['Electronics', 'Fashion', 'Home Goods'], datasets: [{ label: 'Sales', data: [250, 180, 150], backgroundColor: ['#00796b', '#d81b60', '#ff5722'] }] }, options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } } });
    };

    const updateSalesChart = timeRange => {
        if (productSalesChart) {
            productSalesChart.data.labels = state.salesData[timeRange].labels;
            productSalesChart.data.datasets[0].data = state.salesData[timeRange].data;
            productSalesChart.update();
        }
    };

    // --- FEE MANAGEMENT LOGIC ---
    const feeForm = document.getElementById('fee-form');
    const feeRuleIdInput = document.getElementById('fee-rule-id');
    const feeCategoryInput = document.getElementById('fee-category');
    const feeTypeInput = document.getElementById('fee-type');
    const feeValueInput = document.getElementById('fee-value');

    const clearFeeForm = () => {
        feeForm.reset();
        feeRuleIdInput.value = '';
    };

    feeForm.addEventListener('submit', e => {
        e.preventDefault();
        const id = feeRuleIdInput.value;
        const newRule = {
            id: id ? parseInt(id) : Date.now(),
            category: feeCategoryInput.value,
            type: feeTypeInput.value,
            value: parseFloat(feeValueInput.value)
        };

        if (id) {
            state.feeRules = state.feeRules.map(rule => rule.id === newRule.id ? newRule : rule);
        } else {
            state.feeRules.push(newRule);
        }
        render();
        clearFeeForm();
    });

    document.getElementById('clear-fee-form').addEventListener('click', clearFeeForm);

    document.getElementById('fees-view').addEventListener('click', e => {
        const editLink = e.target.closest('.edit-fee-rule');
        const deleteLink = e.target.closest('.delete-fee-rule');

        if (editLink) {
            e.preventDefault();
            const ruleId = parseInt(editLink.dataset.id);
            const ruleToEdit = state.feeRules.find(rule => rule.id === ruleId);
            if (ruleToEdit) {
                feeRuleIdInput.value = ruleToEdit.id;
                feeCategoryInput.value = ruleToEdit.category;
                feeTypeInput.value = ruleToEdit.type;
                feeValueInput.value = ruleToEdit.value;
                feeCategoryInput.focus();
            }
        }

        if (deleteLink) {
            e.preventDefault();
            if (confirm('Are you sure you want to delete this fee rule?')) {
                const ruleId = parseInt(deleteLink.dataset.id);
                state.feeRules = state.feeRules.filter(rule => rule.id !== ruleId);
                render();
            }
        }
    });

    // --- GLOBAL EVENT LISTENERS ---
    document.querySelector('.sidebar-nav').addEventListener('click', e => {
        const link = e.target.closest('a[data-view]');
        if (link) {
            e.preventDefault();
            switchView(link.dataset.view);
        }
    });

    if (document.getElementById('sales-time-range')) {
        document.getElementById('sales-time-range').addEventListener('change', e => updateSalesChart(e.target.value));
    }
    document.querySelector('.mobile-menu-toggle')?.addEventListener('click', () => document.querySelector('.sidebar')?.classList.toggle('open'));

    // --- INITIALIZATION ---
    const initializeDashboard = () => {
        render();
        initCharts();
        console.log('Admin dashboard initialized.');
    };

    initializeDashboard();
});
// ... existing code ...
document.addEventListener('DOMContentLoaded', () => {
    // ... existing chart code ...

    // --- Load All Transactions ---
    function loadAllTransactions() {
        const transactions = JSON.parse(localStorage.getItem('transactions')) || [];
        const recentOrdersTableBody = document.querySelector('.recent-orders-widget tbody');

        if (recentOrdersTableBody) {
            recentOrdersTableBody.innerHTML = '';
            if (transactions.length === 0) {
                recentOrdersTableBody.innerHTML = '<tr><td colspan="5">No transactions found.</td></tr>';
                return;
            }

            transactions.forEach(t => {
                const row = `
                    <tr>
                        <td>${t.orderId}</td>
                        <td>${t.productName}</td>
                        <td>${t.buyer}</td>
                        <td>${new Date(t.date).toLocaleDateString()}</td>
                        <td><span class="status ${t.status.toLowerCase()}">${t.status}</span></td>
                    </tr>
                `;
                recentOrdersTableBody.innerHTML += row;
            });
        }
    }

    loadAllTransactions();

    console.log('Admin dashboard initialized with dynamic data.');
});
