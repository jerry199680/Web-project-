<?php
session_start();
header('Content-Type: application/json');

require_once '../db_connect.php';

// --- Helper Functions ---
function send_response($status, $message, $data = []) {
    echo json_encode(['status' => $status, 'message' => $message, 'data' => $data]);
    exit();
}

function require_login() {
    if (!isset($_SESSION['user_id'])) {
        send_response('error', 'Authentication required. Please log in.');
    }
}

require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_response('error', 'Invalid request method. Only POST is accepted.');
}

$user_id = $_SESSION['user_id'];

// Start a database transaction
$conn->begin_transaction();

try {
    // 1. Get all items from the user's cart
    $cart_stmt = $conn->prepare(
        "SELECT c.product_id, c.quantity, p.price, p.seller_id
         FROM cart c
         JOIN products p ON c.product_id = p.id
         WHERE c.user_id = ?"
    );
    $cart_stmt->bind_param("i", $user_id);
    $cart_stmt->execute();
    $cart_items_result = $cart_stmt->get_result();
    
    if ($cart_items_result->num_rows === 0) {
        send_response('error', 'Your cart is empty.');
    }
    
    $cart_items = $cart_items_result->fetch_all(MYSQLI_ASSOC);
    $cart_stmt->close();

    // 2. Calculate total amount and create a transaction record
    $total_amount = 0;
    foreach ($cart_items as $item) {
        $total_amount += $item['price'] * $item['quantity'];
    }

    $transaction_id = 'txn_' . uniqid(); // Generate a unique transaction ID
    $trans_stmt = $conn->prepare("INSERT INTO transactions (id, user_id, total_amount) VALUES (?, ?, ?)");
    $trans_stmt->bind_param("sid", $transaction_id, $user_id, $total_amount);
    $trans_stmt->execute();
    $trans_stmt->close();

    // 3. Move items from cart to transaction_items
    $item_stmt = $conn->prepare("INSERT INTO transaction_items (transaction_id, product_id, seller_id, quantity, price) VALUES (?, ?, ?, ?, ?)");
    foreach ($cart_items as $item) {
        $item_stmt->bind_param("siiid", $transaction_id, $item['product_id'], $item['seller_id'], $item['quantity'], $item['price']);
        $item_stmt->execute();
    }
    $item_stmt->close();

    // 4. Clear the user's cart
    $clear_stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
    $clear_stmt->bind_param("i", $user_id);
    $clear_stmt->execute();
    $clear_stmt->close();

    // If all queries were successful, commit the transaction
    $conn->commit();
    send_response('success', 'Checkout successful! Your order has been placed.', ['transaction_id' => $transaction_id]);

} catch (Exception $e) {
    // If any query fails, roll back the entire transaction
    $conn->rollback();
    send_response('error', 'Checkout failed. Please try again.', ['error' => $e->getMessage()]);
}

$conn->close();
?>
