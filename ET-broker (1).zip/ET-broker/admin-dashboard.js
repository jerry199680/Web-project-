// Admin Dashboard JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const navLinks = document.querySelectorAll('.nav-link');
    const adminSections = document.querySelectorAll('.admin-section');
    
    // Charts
    let revenueChart = null;
    let categoriesChart = null;
    
    // State
    let currentSection = 'dashboard';
    let currentPage = 1;
    let currentFilters = {};
    
    // Initialize
    setupEventListeners();
    loadDashboardData();
    
    function setupEventListeners() {
        // Navigation
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.dataset.section;
                switchSection(section);
            });
        });
        
        // Filter changes
        setupFilterListeners();
    }
    
    function setupFilterListeners() {
        // User filters
        const userSearch = document.getElementById('userSearch');
        const userRoleFilter = document.getElementById('userRoleFilter');
        const userStatusFilter = document.getElementById('userStatusFilter');
        
        if (userSearch) userSearch.addEventListener('input', debounce(() => loadUsers(), 500));
        if (userRoleFilter) userRoleFilter.addEventListener('change', () => loadUsers());
        if (userStatusFilter) userStatusFilter.addEventListener('change', () => loadUsers());
        
        // Product filters
        const productSearch = document.getElementById('productSearch');
        const productCategoryFilter = document.getElementById('productCategoryFilter');
        const productStatusFilter = document.getElementById('productStatusFilter');
        
        if (productSearch) productSearch.addEventListener('input', debounce(() => loadProducts(), 500));
        if (productCategoryFilter) productCategoryFilter.addEventListener('change', () => loadProducts());
        if (productStatusFilter) productStatusFilter.addEventListener('change', () => loadProducts());
        
        // Order filters
        const orderSearch = document.getElementById('orderSearch');
        const orderStatusFilter = document.getElementById('orderStatusFilter');
        const orderDateFrom = document.getElementById('orderDateFrom');
        const orderDateTo = document.getElementById('orderDateTo');
        
        if (orderSearch) orderSearch.addEventListener('input', debounce(() => loadOrders(), 500));
        if (orderStatusFilter) orderStatusFilter.addEventListener('change', () => loadOrders());
        if (orderDateFrom) orderDateFrom.addEventListener('change', () => loadOrders());
        if (orderDateTo) orderDateTo.addEventListener('change', () => loadOrders());
        
        // Revenue period change
        const revenuePeriod = document.getElementById('revenuePeriod');
        if (revenuePeriod) {
            revenuePeriod.addEventListener('change', () => updateRevenueChart());
        }
    }
    
    function switchSection(section) {
        // Update navigation
        navLinks.forEach(link => {
            link.parentElement.classList.remove('active');
            if (link.dataset.section === section) {
                link.parentElement.classList.add('active');
            }
        });
        
        // Update sections
        adminSections.forEach(sec => {
            sec.classList.remove('active');
            if (sec.id === section) {
                sec.classList.add('active');
            }
        });
        
        currentSection = section;
        
        // Load section data
        switch (section) {
            case 'dashboard':
                loadDashboardData();
                break;
            case 'users':
                loadUsers();
                break;
            case 'products':
                loadProducts();
                break;
            case 'orders':
                loadOrders();
                break;
            case 'categories':
                loadCategories();
                break;
            case 'jobs':
                loadJobs();
                break;
            case 'reviews':
                loadReviews();
                break;
            case 'notifications':
                loadNotifications();
                break;
            case 'settings':
                loadSettings();
                break;
        }
    }
    
    async function loadDashboardData() {
        try {
            // Load stats
            const statsResponse = await fetch('backend/api.php/admin/stats');
            const stats = await statsResponse.json();
            
            if (stats.success) {
                updateStatsCards(stats.data);
            }
            
            // Load recent activity
            const activityResponse = await fetch('backend/api.php/admin/activity');
            const activity = await activityResponse.json();
            
            if (activity.success) {
                updateRecentActivity(activity.data);
            }
            
            // Initialize charts
            initializeCharts();
            
        } catch (error) {
            console.error('Error loading dashboard data:', error);
        }
    }
    
    function updateStatsCards(data) {
        document.getElementById('totalUsers').textContent = data.totalUsers || 0;
        document.getElementById('totalSellers').textContent = data.totalSellers || 0;
        document.getElementById('totalProducts').textContent = data.totalProducts || 0;
        document.getElementById('totalOrders').textContent = data.totalOrders || 0;
        document.getElementById('totalRevenue').textContent = `ETB ${(data.totalRevenue || 0).toFixed(2)}`;
        document.getElementById('avgRating').textContent = (data.avgRating || 0).toFixed(1);
    }
    
    function updateRecentActivity(activities) {
        const container = document.getElementById('recentActivity');
        if (!container) return;
        
        container.innerHTML = activities.map(activity => `
            <div class="activity-item">
                <div class="activity-icon">
                    <i class="fas ${getActivityIcon(activity.type)}"></i>
                </div>
                <div class="activity-content">
                    <div class="activity-title">${activity.title}</div>
                    <div class="activity-description">${activity.description}</div>
                </div>
                <div class="activity-time">${timeAgo(activity.created_at)}</div>
            </div>
        `).join('');
    }
    
    function getActivityIcon(type) {
        const icons = {
            'user_registered': 'fa-user-plus',
            'product_created': 'fa-box',
            'order_placed': 'fa-shopping-cart',
            'review_submitted': 'fa-star',
            'payment_received': 'fa-credit-card',
            'default': 'fa-circle'
        };
        return icons[type] || icons.default;
    }
    
    function timeAgo(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const diffInSeconds = Math.floor((now - date) / 1000);
        
        if (diffInSeconds < 60) return 'Just now';
        if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
        if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
        return `${Math.floor(diffInSeconds / 86400)}d ago`;
    }
    
    function initializeCharts() {
        // Revenue Chart
        const revenueCtx = document.getElementById('revenueChart');
        if (revenueCtx) {
            updateRevenueChart();
        }
        
        // Categories Chart
        const categoriesCtx = document.getElementById('categoriesChart');
        if (categoriesCtx) {
            updateCategoriesChart();
        }
    }
    
    async function updateRevenueChart() {
        const period = document.getElementById('revenuePeriod')?.value || 30;
        const ctx = document.getElementById('revenueChart');
        if (!ctx) return;
        
        try {
            const response = await fetch(`backend/api.php/admin/revenue?period=${period}`);
            const data = await response.json();
            
            if (revenueChart) {
                revenueChart.destroy();
            }
            
            revenueChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.labels || [],
                    datasets: [{
                        label: 'Revenue',
                        data: data.values || [],
                        borderColor: '#00796b',
                        backgroundColor: 'rgba(0, 121, 107, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return 'ETB ' + value.toLocaleString();
                                }
                            }
                        }
                    }
                }
            });
        } catch (error) {
            console.error('Error loading revenue chart:', error);
        }
    }
    
    async function updateCategoriesChart() {
        const ctx = document.getElementById('categoriesChart');
        if (!ctx) return;
        
        try {
            const response = await fetch('backend/api.php/admin/categories-stats');
            const data = await response.json();
            
            if (categoriesChart) {
                categoriesChart.destroy();
            }
            
            categoriesChart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: data.labels || [],
                    datasets: [{
                        data: data.values || [],
                        backgroundColor: [
                            '#00796b',
                            '#4db6ac',
                            '#80cbc4',
                            '#b2dfdb',
                            '#e0f2f1'
                        ]
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        } catch (error) {
            console.error('Error loading categories chart:', error);
        }
    }
    
    async function loadUsers() {
        const search = document.getElementById('userSearch')?.value || '';
        const role = document.getElementById('userRoleFilter')?.value || '';
        const status = document.getElementById('userStatusFilter')?.value || '';
        
        try {
            const params = new URLSearchParams({
                search,
                role,
                status,
                page: currentPage
            });
            
            const response = await fetch(`backend/api.php/admin/users?${params}`);
            const data = await response.json();
            
            if (data.success) {
                updateUsersTable(data.users);
                updatePagination('usersPagination', data.pagination);
            }
        } catch (error) {
            console.error('Error loading users:', error);
        }
    }
    
    function updateUsersTable(users) {
        const tbody = document.querySelector('#usersTable tbody');
        if (!tbody) return;
        
        tbody.innerHTML = users.map(user => `
            <tr>
                <td>${user.id}</td>
                <td>${user.fullname}</td>
                <td>${user.email}</td>
                <td>${user.phone || '-'}</td>
                <td><span class="status-badge ${user.role}">${user.role}</span></td>
                <td><span class="status-badge ${user.status || 'active'}">${user.status || 'active'}</span></td>
                <td>${formatDate(user.created_at)}</td>
                <td>
                    <div class="action-buttons">
                        <button class="action-btn view" onclick="viewUser(${user.id})">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="action-btn edit" onclick="editUser(${user.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="action-btn delete" onclick="deleteUser(${user.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }
    
    async function loadProducts() {
        const search = document.getElementById('productSearch')?.value || '';
        const category = document.getElementById('productCategoryFilter')?.value || '';
        const status = document.getElementById('productStatusFilter')?.value || '';
        
        try {
            const params = new URLSearchParams({
                search,
                category,
                status,
                page: currentPage
            });
            
            const response = await fetch(`backend/api.php/admin/products?${params}`);
            const data = await response.json();
            
            if (data.success) {
                updateProductsTable(data.products);
                updatePagination('productsPagination', data.pagination);
            }
        } catch (error) {
            console.error('Error loading products:', error);
        }
    }
    
    function updateProductsTable(products) {
        const tbody = document.querySelector('#productsTable tbody');
        if (!tbody) return;
        
        tbody.innerHTML = products.map(product => `
            <tr>
                <td>${product.id}</td>
                <td><img src="${product.main_image || 'images/default-product.png'}" alt="${product.title}"></td>
                <td>${product.title}</td>
                <td>${product.seller_name || '-'}</td>
                <td>${product.category_name || '-'}</td>
                <td>ETB ${product.price.toFixed(2)}</td>
                <td><span class="status-badge ${product.status}">${product.status}</span></td>
                <td>${formatDate(product.created_at)}</td>
                <td>
                    <div class="action-buttons">
                        <button class="action-btn view" onclick="viewProduct(${product.id})">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="action-btn edit" onclick="editProduct(${product.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="action-btn delete" onclick="deleteProduct(${product.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }
    
    async function loadOrders() {
        const search = document.getElementById('orderSearch')?.value || '';
        const status = document.getElementById('orderStatusFilter')?.value || '';
        const dateFrom = document.getElementById('orderDateFrom')?.value || '';
        const dateTo = document.getElementById('orderDateTo')?.value || '';
        
        try {
            const params = new URLSearchParams({
                search,
                status,
                date_from: dateFrom,
                date_to: dateTo,
                page: currentPage
            });
            
            const response = await fetch(`backend/api.php/admin/orders?${params}`);
            const data = await response.json();
            
            if (data.success) {
                updateOrdersTable(data.orders);
                updatePagination('ordersPagination', data.pagination);
            }
        } catch (error) {
            console.error('Error loading orders:', error);
        }
    }
    
    function updateOrdersTable(orders) {
        const tbody = document.querySelector('#ordersTable tbody');
        if (!tbody) return;
        
        tbody.innerHTML = orders.map(order => `
            <tr>
                <td>${order.order_number}</td>
                <td>${order.customer_name}</td>
                <td>${order.items_count} items</td>
                <td>ETB ${order.total_amount.toFixed(2)}</td>
                <td><span class="status-badge ${order.status}">${order.status}</span></td>
                <td>${formatDate(order.created_at)}</td>
                <td>
                    <div class="action-buttons">
                        <button class="action-btn view" onclick="viewOrder(${order.id})">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="action-btn edit" onclick="updateOrderStatus(${order.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }
    
    function updatePagination(containerId, pagination) {
        const container = document.getElementById(containerId);
        if (!container || !pagination) return;
        
        const { current_page, total_pages, has_prev, has_next } = pagination;
        
        container.innerHTML = `
            <button ${!has_prev ? 'disabled' : ''} onclick="changePage(${current_page - 1})">
                <i class="fas fa-chevron-left"></i>
            </button>
            ${Array.from({ length: total_pages }, (_, i) => i + 1).map(page => `
                <span class="page-number ${page === current_page ? 'active' : ''}" 
                      onclick="changePage(${page})">${page}</span>
            `).join('')}
            <button ${!has_next ? 'disabled' : ''} onclick="changePage(${current_page + 1})">
                <i class="fas fa-chevron-right"></i>
            </button>
        `;
    }
    
    function changePage(page) {
        currentPage = page;
        
        switch (currentSection) {
            case 'users':
                loadUsers();
                break;
            case 'products':
                loadProducts();
                break;
            case 'orders':
                loadOrders();
                break;
        }
    }
    
    function formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }
    
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    // Modal functions
    function showAddUserModal() {
        document.getElementById('addUserModal').classList.add('show');
    }
    
    function closeModal(modalId) {
        document.getElementById(modalId).classList.remove('show');
    }
    
    async function addUser() {
        const form = document.getElementById('addUserForm');
        const formData = new FormData(form);
        
        try {
            const response = await fetch('backend/api.php/admin/users', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                closeModal('addUserModal');
                loadUsers();
                alert('User added successfully');
            } else {
                alert('Error adding user: ' + result.message);
            }
        } catch (error) {
            console.error('Error adding user:', error);
            alert('Error adding user');
        }
    }
    
    // Action functions
    function viewUser(userId) {
        // Implement view user functionality
        console.log('View user:', userId);
    }
    
    function editUser(userId) {
        // Implement edit user functionality
        console.log('Edit user:', userId);
    }
    
    function deleteUser(userId) {
        if (confirm('Are you sure you want to delete this user?')) {
            // Implement delete user functionality
            console.log('Delete user:', userId);
        }
    }
    
    function viewProduct(productId) {
        // Implement view product functionality
        console.log('View product:', productId);
    }
    
    function editProduct(productId) {
        // Implement edit product functionality
        console.log('Edit product:', productId);
    }
    
    function deleteProduct(productId) {
        if (confirm('Are you sure you want to delete this product?')) {
            // Implement delete product functionality
            console.log('Delete product:', productId);
        }
    }
    
    function viewOrder(orderId) {
        // Implement view order functionality
        console.log('View order:', orderId);
    }
    
    function updateOrderStatus(orderId) {
        // Implement update order status functionality
        console.log('Update order status:', orderId);
    }
    
    function exportProducts() {
        // Implement export products functionality
        console.log('Export products');
    }
    
    // Make functions globally available
    window.showAddUserModal = showAddUserModal;
    window.closeModal = closeModal;
    window.addUser = addUser;
    window.changePage = changePage;
    window.viewUser = viewUser;
    window.editUser = editUser;
    window.deleteUser = deleteUser;
    window.viewProduct = viewProduct;
    window.editProduct = editProduct;
    window.deleteProduct = deleteProduct;
    window.viewOrder = viewOrder;
    window.updateOrderStatus = updateOrderStatus;
    window.exportProducts = exportProducts;
});
