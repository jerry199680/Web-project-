document.addEventListener('DOMContentLoaded', () => {
    // --- NEW HEADER LOGIC ---
    const mainHeader = document.getElementById('mainHeader');
    const userBtn = document.getElementById('userBtn');
    const userDropdown = document.getElementById('userDropdown');
    const hamburgerBtn = document.getElementById('hamburgerBtn');
    const sideMenu = document.querySelector('.side-menu-container');
    const overlay = document.querySelector('.overlay');

    // Sticky header
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            mainHeader.classList.add('compact');
        } else {
            mainHeader.classList.remove('compact');
        }
    });

    // Toggle user dropdown
    if (userBtn && userDropdown) {
        userBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            userDropdown.classList.toggle('active');
        });
    }

    // Toggle mobile side menu
    if (hamburgerBtn && sideMenu && overlay) {
        hamburgerBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            sideMenu.classList.add('open');
            overlay.classList.add('active');
        });

        overlay.addEventListener('click', () => {
            sideMenu.classList.remove('open');
            overlay.classList.remove('active');
        });
    }
    
    // Close dropdowns when clicking outside
    document.addEventListener('click', (e) => {
        if (userDropdown && !userDropdown.contains(e.target) && !userBtn.contains(e.target)) {
            userDropdown.classList.remove('active');
        }
    });


    // --- MOCK DATA ---
    const products = [
        { id: 1, title: "Premium Leather Laptop Bag, Fits 15-inch", price: 89.99, image: "images/86a73f6a024b9bd4ecd5b67615cc8ac7.jpg", seller: { name: "EthioLeather", avatar: "images/seller-1.png" }, rating: 4.5, reviews: 120 },
        { id: 2, title: "Modern Smartwatch with Health Tracking", price: 150.00, image: "images/95cd02a1a2255fdf385b012f390a5131.jpg", seller: { name: "GadgetZone", avatar: "images/seller-2.png" }, rating: 5, reviews: 350 },
        { id: 3, title: "Stylish Women's Handbag, Multiple Colors", price: 45.50, image: "images/a9a28572d7d010e5403ceb9b76d575f5.jpg", seller: { name: "ChicBags", avatar: "images/seller-3.png" }, rating: 4, reviews: 88 },
        { id: 4, title: "Men's Classic Cotton T-Shirt, Pack of 3", price: 29.99, image: "images/360f33bf797ff282ff4e7e23e018f5f3.jpg", seller: { name: "ComfortWear", avatar: "images/seller-4.png" }, rating: 4.5, reviews: 450 },
        { id: 5, title: "Comfortable Running Shoes for Men", price: 75.00, image: "images/ab1c006057d0416df26de61f08fc6daa.jpg", seller: { name: "FitFeet", avatar: "images/seller-1.png" }, rating: 5, reviews: 600 },
        { id: 6, title: "Elegant Wrist Watch for Women", price: 199.00, image: "images/a041fbee9535c48f6cb25d6cd7721583.jpg", seller: { name: "TimeKeepers", avatar: "images/seller-2.png" }, rating: 5, reviews: 150 },
        { id: 7, title: "Kids Educational Toy Blocks, 100 Pieces", price: 25.00, image: "images/89462972933b34b59bce2da5e67bb877.jpg", seller: { name: "PlayfulMinds", avatar: "images/seller-3.png" }, rating: 4, reviews: 95 },
        { id: 8, title: "Professional DSLR Camera with Kit Lens", price: 699.00, image: "images/69103cae4067d04ab6115d22b2a96891.jpg", seller: { name: "PhotoPro", avatar: "images/seller-4.png" }, rating: 5, reviews: 80 },
    ];

    const jobs = [
        { title: "Senior Frontend Developer", company: "Tech-Innovate Inc.", location: "Addis Ababa", salary: "Competitive", deadline: "2024-08-30" },
        { title: "Marketing Manager", company: "SellFast PLC", location: "Remote", salary: "ETB 40,000", deadline: "2024-09-10" },
        { title: "Logistics Coordinator", company: "EthioDeliver", location: "Adama", salary: "ETB 25,000", deadline: "2024-08-25" },
    ];

    // --- PRODUCT & JOB RENDERING (No changes here) ---
    function createProductCard(product) {
        return `
            <div class="product-card">
                <div class="product-card-image">
                    <img src="${product.image}" alt="${product.title}">
                    <div class="product-card-actions">
                        <button aria-label="Quick view"><i class="fas fa-eye"></i></button>
                        <button aria-label="Save to wishlist"><i class="far fa-heart"></i></button>
                        <button aria-label="Compare"><i class="fas fa-exchange-alt"></i></button>
                    </div>
                </div>
                <div class="product-card-info">
                    <h3 class="product-card-title">${product.title}</h3>
                    <div class="product-card-price">$${product.price.toFixed(2)}</div>
                    <div class="product-card-seller">
                        <img src="${product.seller.avatar}" alt="${product.seller.name}">
                        <span>${product.seller.name}</span>
                    </div>
                    <div class="product-card-rating">
                        <span class="stars">${'★'.repeat(Math.floor(product.rating))}${'☆'.repeat(5 - Math.floor(product.rating))}</span>
                        <span>(${product.reviews})</span>
                    </div>
                </div>
            </div>
        `;
    }

    function createJobCard(job) {
        return `
            <div class="job-card">
                <h3>${job.title}</h3>
                <p><strong>${job.company}</strong></p>
                <div class="job-meta">
                    <span><i class="fas fa-map-marker-alt"></i> ${job.location}</span>
                    <span><i class="fas fa-money-bill-wave"></i> ${job.salary}</span>
                </div>
                <p>Deadline: ${job.deadline}</p>
                <button class="btn btn-primary">Apply Now</button>
            </div>
        `;
    }

    function renderItems(containerId, items, createCardFn) {
        const container = document.getElementById(containerId);
        if (container) {
            container.innerHTML = items.map(createCardFn).join('');
        }
    }

    renderItems('top-selling-carousel', products, createProductCard);
    renderItems('recommended-grid', products.slice().reverse(), createProductCard);
    renderItems('latest-grid', products.slice(0, 4), createProductCard);
    renderItems('job-grid', jobs, createJobCard);

    // --- CAROUSEL LOGIC (No changes here) ---
    const carousels = document.querySelectorAll('.product-carousel-section');
    carousels.forEach(section => {
        const carousel = section.querySelector('.product-carousel');
        const prevBtn = section.querySelector('.carousel-nav.prev');
        const nextBtn = section.querySelector('.carousel-nav.next');
        if (!carousel || !prevBtn || !nextBtn) return;

        const cardWidth = carousel.querySelector('.product-card').offsetWidth + 20; // card width + gap

        prevBtn.addEventListener('click', () => {
            carousel.scrollLeft -= cardWidth * 2;
        });

        nextBtn.addEventListener('click', () => {
            carousel.scrollLeft += cardWidth * 2;
        });
    });

    // --- LOAD MORE LOGIC (No changes here) ---
    const loadMoreBtn = document.querySelector('.load-more-btn');
    const latestGrid = document.getElementById('latest-grid');
    let loadedCount = 4;

    if (loadMoreBtn && latestGrid) {
        loadMoreBtn.addEventListener('click', () => {
            // Simulate loading more products
            const newProducts = products.slice(0, 4).map(p => ({...p, id: p.id + Math.random() }));
            latestGrid.insertAdjacentHTML('beforeend', newProducts.map(createProductCard).join(''));
            loadedCount += 4;
            if (loadedCount >= 12) { // Simulate end of list
                loadMoreBtn.textContent = "No More Products";
                loadMoreBtn.disabled = true;
            }
        });
    }

    // --- HERO SLIDER (No changes here) ---
    function setupHeroSlider() {
        const slider = document.querySelector('.hero-slider');
        if (!slider) return;

        const slidesData = [
            { img: 'https://images.unsplash.com/photo-1555529771-835f59fc5efe?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D' },
            { img: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?q=80&w=2158&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D' },
            { img: 'https://images.unsplash.com/photo-1524758631624-e2822e304c36?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D' },
            { img: 'https://images.unsplash.com/photo-1487017159836-4e23ece2e4cf?q=80&w=2071&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D' }
        ];

        slidesData.forEach((slide, index) => {
            const slideEl = document.createElement('div');
            slideEl.className = 'hero-slide';
            if (index === 0) slideEl.classList.add('active');
            slideEl.style.backgroundImage = `url('${slide.img}')`;
            slider.appendChild(slideEl);
        });

        let currentSlide = 0;
        const slides = document.querySelectorAll('.hero-slide');
        const slideCount = slides.length;

        setInterval(() => {
            slides[currentSlide].classList.remove('active');
            currentSlide = (currentSlide + 1) % slideCount;
            slides[currentSlide].classList.add('active');
        }, 7000);
    }

    setupHeroSlider();
});
document.addEventListener('DOMContentLoaded', () => {
    // --- DOM ELEMENTS ---
    const mainHeader = document.getElementById('mainHeader');
    const userBtn = document.getElementById('userBtn');
    const userDropdown = document.getElementById('userDropdown');
    const hamburgerBtn = document.getElementById('hamburgerBtn');
    const sideMenu = document.getElementById('sideMenu');
    const overlay = document.getElementById('overlay');
    const searchInput = document.getElementById('searchInput');
    const searchCategory = document.getElementById('searchCategory');
    const searchSubmitBtn = document.getElementById('searchSubmitBtn');
    const cartCountEl = document.getElementById('cartCount');
    const cartIcon = document.querySelector('.cart-icon');
    const noResultsMessage = document.getElementById('no-results-message');

    // --- MOCK DATA ---
    const allProducts = [
        { id: 1, title: "Premium Leather Laptop Bag, Fits 15-inch", price: 89.99, image: "images/86a73f6a024b9bd4ecd5b67615cc8ac7.jpg", category: "fashion", seller: { name: "EthioLeather", avatar: "images/seller-1.png" }, rating: 4.5, reviews: 120 },
        { id: 2, title: "Modern Smartwatch with Health Tracking", price: 150.00, image: "images/95cd02a1a2255fdf385b012f390a5131.jpg", category: "electronics", seller: { name: "GadgetZone", avatar: "images/seller-2.png" }, rating: 5, reviews: 350 },
        { id: 3, title: "Stylish Women's Handbag, Multiple Colors", price: 45.50, image: "images/a9a28572d7d010e5403ceb9b76d575f5.jpg", category: "fashion", seller: { name: "ChicBags", avatar: "images/seller-3.png" }, rating: 4, reviews: 88 },
        { id: 4, title: "Men's Classic Cotton T-Shirt, Pack of 3", price: 29.99, image: "images/360f33bf797ff282ff4e7e23e018f5f3.jpg", category: "fashion", seller: { name: "ComfortWear", avatar: "images/seller-4.png" }, rating: 4.5, reviews: 450 },
        { id: 5, title: "Comfortable Running Shoes for Men", price: 75.00, image: "images/ab1c006057d0416df26de61f08fc6daa.jpg", category: "fashion", seller: { name: "FitFeet", avatar: "images/seller-1.png" }, rating: 5, reviews: 600 },
        { id: 6, title: "Elegant Wrist Watch for Women", price: 199.00, image: "images/a041fbee9535c48f6cb25d6cd7721583.jpg", category: "fashion", seller: { name: "TimeKeepers", avatar: "images/seller-2.png" }, rating: 5, reviews: 150 },
        { id: 7, title: "Kids Educational Toy Blocks, 100 Pieces", price: 25.00, image: "", category: "toys", seller: { name: "PlayfulMinds", avatar: "images/seller-3.png" }, rating: 4, reviews: 95 }, // Example with missing image
        { id: 8, title: "Professional DSLR Camera with Kit Lens", price: 699.00, image: "images/69103cae4067d04ab6115d22b2a96891.jpg", category: "electronics", seller: { name: "PhotoPro", avatar: "images/seller-4.png" }, rating: 5, reviews: 80 },
    ];

    const jobs = [
        { title: "Senior Frontend Developer", company: "Tech-Innovate Inc.", location: "Addis Ababa", salary: "Competitive", deadline: "2024-08-30" },
        { title: "Marketing Manager", company: "SellFast PLC", location: "Remote", salary: "ETB 40,000", deadline: "2024-09-10" },
        { title: "Logistics Coordinator", company: "EthioDeliver", location: "Adama", salary: "ETB 25,000", deadline: "2024-08-25" },
    ];
    
    let cart = [];

    // --- HEADER INTERACTIVITY ---
    window.addEventListener('scroll', () => {
        mainHeader.classList.toggle('compact', window.scrollY > 50);
    });

    if (userBtn) {
        userBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            userDropdown.classList.toggle('active');
        });
    }

    if (hamburgerBtn) {
        hamburgerBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            sideMenu.classList.add('open');
            overlay.classList.add('active');
        });
    }
    
    if(overlay) {
        overlay.addEventListener('click', () => {
            sideMenu.classList.remove('open');
            overlay.classList.remove('active');
        });
    }

    document.addEventListener('click', (e) => {
        if (userDropdown && !userDropdown.contains(e.target) && !userBtn.contains(e.target)) {
            userDropdown.classList.remove('active');
        }
    });

    // --- RENDERING FUNCTIONS ---
    function createProductCard(product) {
        const imageSrc = product.image || 'images/default-product.png'; // Default image
        return `
            <div class="product-card" data-id="${product.id}">
                <div class="product-card-image">
                    <img src="${imageSrc}" alt="${product.title}" onerror="this.onerror=null;this.src='images/default-product.png';">
                    <div class="product-card-actions">
                        <button aria-label="Quick view"><i class="fas fa-eye"></i></button>
                        <button aria-label="Save to wishlist"><i class="far fa-heart"></i></button>
                    </div>
                </div>
                <div class="product-card-info">
                    <h3 class="product-card-title">${product.title}</h3>
                    <div class="product-card-price">$${product.price.toFixed(2)}</div>
                    <div class="product-card-rating">
                        <span class="stars">${'★'.repeat(Math.floor(product.rating))}${'☆'.repeat(5 - Math.floor(product.rating))}</span>
                        <span>(${product.reviews})</span>
                    </div>
                </div>
                <button class="add-to-cart-btn" data-id="${product.id}">Add to Cart</button>
            </div>
        `;
    }

    function createJobCard(job) {
        return `
            <div class="job-card">
                <h3>${job.title}</h3>
                <p><strong>${job.company}</strong></p>
                <div class="job-meta">
                    <span><i class="fas fa-map-marker-alt"></i> ${job.location}</span>
                    <span><i class="fas fa-money-bill-wave"></i> ${job.salary}</span>
                </div>
                <p>Deadline: ${job.deadline}</p>
                <button class="btn btn-primary">Apply Now</button>
            </div>
        `;
    }

    function renderItems(containerId, items, createCardFn) {
        const container = document.getElementById(containerId);
        if (container) {
            container.innerHTML = items.map(createCardFn).join('');
        }
    }

    // --- SEARCH FUNCTIONALITY ---
    function handleSearch() {
        const query = searchInput.value.toLowerCase();
        const category = searchCategory.value;

        const filteredProducts = allProducts.filter(product => {
            const matchesQuery = product.title.toLowerCase().includes(query);
            const matchesCategory = category === 'all' || product.category === category;
            return matchesQuery && matchesCategory;
        });

        renderItems('recommended-grid', filteredProducts, createProductCard);
        
        if (filteredProducts.length === 0) {
            noResultsMessage.style.display = 'block';
        } else {
            noResultsMessage.style.display = 'none';
        }
    }

    if (searchSubmitBtn) {
        searchSubmitBtn.addEventListener('click', handleSearch);
    }
    if(searchInput) {
        searchInput.addEventListener('keyup', (e) => {
            if (e.key === 'Enter') {
                handleSearch();
            }
        });
    }

    // --- ADD TO CART FUNCTIONALITY ---
    function addToCart(productId) {
        const product = allProducts.find(p => p.id === parseInt(productId));
        if (product) {
            cart.push(product);
            updateCartCount();
        }
    }

    function updateCartCount() {
        cartCountEl.textContent = cart.length;
        // Animate cart icon
        cartIcon.classList.add('updated');
        setTimeout(() => {
            cartIcon.classList.remove('updated');
            cartIcon.querySelector('.badge').style.transform = 'scale(1)';
        }, 300);
        setTimeout(() => {
            cartIcon.querySelector('.badge').style.transform = '';
        }, 600);
    }

    document.addEventListener('click', (e) => {
        if (e.target && e.target.matches('.add-to-cart-btn')) {
            addToCart(e.target.dataset.id);
        }
    });

    // --- INITIAL PAGE LOAD ---
    function initializePage() {
        renderItems('top-selling-carousel', allProducts.slice(0, 8), createProductCard);
        renderItems('recommended-grid', allProducts.slice().reverse(), createProductCard);
        renderItems('latest-grid', allProducts.slice(0, 4), createProductCard);
        renderItems('job-grid', jobs, createJobCard);
        setupHeroSlider();
    }

    // --- HERO SLIDER (No changes here) ---
    function setupHeroSlider() {
        const slider = document.querySelector('.hero-slider');
        if (!slider) return;

        const slidesData = [
            { img: 'https://images.unsplash.com/photo-1555529771-835f59fc5efe?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D' },
            { img: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?q=80&w=2158&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D' },
            { img: 'https://images.unsplash.com/photo-1524758631624-e2822e304c36?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D' },
            { img: 'https://images.unsplash.com/photo-1487017159836-4e23ece2e4cf?q=80&w=2071&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D' }
        ];

        slidesData.forEach((slide, index) => {
            const slideEl = document.createElement('div');
            slideEl.className = 'hero-slide';
            if (index === 0) slideEl.classList.add('active');
            slideEl.style.backgroundImage = `url('${slide.img}')`;
            slider.appendChild(slideEl);
        });

        let currentSlide = 0;
        const slides = document.querySelectorAll('.hero-slide');
        const slideCount = slides.length;

        setInterval(() => {
            slides[currentSlide].classList.remove('active');
            currentSlide = (currentSlide + 1) % slideCount;
            slides[currentSlide].classList.add('active');
        }, 7000);
    }

    initializePage();
});
document.addEventListener('DOMContentLoaded', async () => {
    // ... existing code ...

    // --- Load Latest Products from Local Storage ---
    function loadLatestProducts() {
        const latestGrid = document.getElementById('latest-grid');
        if (!latestGrid) return;

        const products = JSON.parse(localStorage.getItem('allProducts')) || [];
        
        // Get the most recent products
        const latestProducts = products.slice(-8).reverse(); 

        if (latestProducts.length > 0) {
            latestGrid.innerHTML = latestProducts.map(product => `
                <div class="product-card">
                    <div class="product-image-container">
                        <img src="${product.image}" alt="${product.name}">
                        <div class="seller-info-overlay">
                            <img src="${product.sellerImage}" alt="${product.seller}">
                            <span>${product.seller}</span>
                        </div>
                    </div>
                    <div class="product-info">
                        <h3>${product.name}</h3>
                        <div class="price">$${product.price.toFixed(2)}</div>
                        <div class="product-meta">
                            <span><i class="fas fa-map-marker-alt"></i> ${product.sellerLocation}</span>
                        </div>
                        <button class="add-to-cart-btn" data-product-id="${product.id}">Add to Cart</button>
                    </div>
                </div>
            `).join('');
        } else {
            latestGrid.innerHTML = '<p>No products available yet. Check back soon!</p>';
        }
    }

    loadLatestProducts();

    // --- Add to Cart Logic ---
    document.body.addEventListener('click', (e) => {
        if (e.target.classList.contains('add-to-cart-btn')) {
            const productId = e.target.dataset.productId;
            let cart = JSON.parse(localStorage.getItem('cart')) || [];

            if (!cart.includes(productId)) {
                cart.push(productId);
                localStorage.setItem('cart', JSON.stringify(cart));
                updateCartCount();
                alert('Product added to cart!');
            } else {
                alert('Product is already in your cart.');
            }
            }
        });

    function updateCartCount() {
        const cart = JSON.parse(localStorage.getItem('cart')) || [];
        const cartCount = document.getElementById('cartCount');
        if (cartCount) {
            cartCount.textContent = cart.length;
        }
    }

    updateCartCount();
});
