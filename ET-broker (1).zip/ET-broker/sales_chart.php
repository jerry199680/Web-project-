<?php
session_start();
include_once '../../db_connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['seller_id'])) {
    echo json_encode(['error' => 'Seller not authenticated']);
    exit;
}

$seller_id = $_SESSION['seller_id'];

// Fetch sales data for the last 7 days
$sales_query = "SELECT DATE(o.created_at) as sale_date, SUM(oi.quantity * oi.price) as daily_sales
                FROM orders o
                JOIN order_items oi ON o.id = oi.order_id
                JOIN products p ON oi.product_id = p.id
                WHERE p.seller_id = ? AND o.created_at >= CURDATE() - INTERVAL 7 DAY
                GROUP BY sale_date
                ORDER BY sale_date ASC";

$stmt = $conn->prepare($sales_query);
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$result = $stmt->get_result();

$sales_data = [];
while ($row = $result->fetch_assoc()) {
    $sales_data[] = $row;
}

// Prepare data for the chart
$labels = [];
$data = [];
$period = new DatePeriod(
    new DateTime('-6 days'),
    new DateInterval('P1D'),
    new DateTime('+1 day')
);

foreach ($period as $date) {
    $day = $date->format('Y-m-d');
    $labels[] = $date->format('M d');
    $daily_total = 0;
    foreach ($sales_data as $sale) {
        if ($sale['sale_date'] == $day) {
            $daily_total = (float)$sale['daily_sales'];
            break;
        }
    }
    $data[] = $daily_total;
}

$chart_data = [
    'labels' => $labels,
    'data' => $data,
];

echo json_encode($chart_data);

$stmt->close();
$conn->close();
?>
