<?php
session_start();
header('Content-Type: application/json');

require_once '../db_connect.php';

// --- Helper Functions ---
function send_response($status, $message, $data = []) {
    echo json_encode(['status' => $status, 'message' => $message, 'data' => $data]);
    exit();
}

function is_seller() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'user' && $_SESSION['is_seller'];
}

$method = $_SERVER['REQUEST_METHOD'];

// --- API Logic ---
switch ($method) {
    case 'GET':
        // Fetching products
        if (isset($_GET['id'])) {
            // Get a single product by ID
            $stmt = $conn->prepare("SELECT p.*, u.fullname as seller_name, u.avatar as seller_avatar FROM products p JOIN users u ON p.seller_id = u.id WHERE p.id = ?");
            $stmt->bind_param("i", $_GET['id']);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($product = $result->fetch_assoc()) {
                send_response('success', 'Product found.', $product);
            } else {
                send_response('error', 'Product not found.');
            }
        } else {
            // Get all products, with optional category filter
            $sql = "SELECT p.*, u.fullname as seller_name FROM products p JOIN users u ON p.seller_id = u.id";
            if (isset($_GET['category_id'])) {
                $sql .= " WHERE p.category_id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $_GET['category_id']);
            } else {
                $stmt = $conn->prepare($sql);
            }
            $stmt->execute();
            $result = $stmt->get_result();
            $products = $result->fetch_all(MYSQLI_ASSOC);
            send_response('success', 'Products retrieved.', $products);
        }
        $stmt->close();
        break;

    case 'POST':
        // Creating a new product
        if (!is_seller()) {
            send_response('error', 'Unauthorized: Only sellers can create products.');
        }

        $name = $_POST['name'] ?? '';
        $description = $_POST['description'] ?? '';
        $price = $_POST['price'] ?? 0;
        $category_id = $_POST['category_id'] ?? 0;
        $address = $_POST['address'] ?? '';
        $seller_id = $_SESSION['user_id'];

        if (empty($name) || empty($description) || $price <= 0 || $category_id <= 0) {
            send_response('error', 'All fields are required and must be valid.');
        }

        // Image upload handling
        $image_path = '';
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = '../images/products/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
            $image_name = uniqid('product_', true) . '.' . pathinfo(basename($_FILES['image']['name']), PATHINFO_EXTENSION);
            $target_file = $upload_dir . $image_name;
            if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
                $image_path = 'images/products/' . $image_name;
            } else {
                send_response('error', 'Failed to upload product image.');
            }
        } else {
            send_response('error', 'Product image is required.');
        }

        $stmt = $conn->prepare("INSERT INTO products (seller_id, category_id, name, description, price, image, address) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iisdsss", $seller_id, $category_id, $name, $description, $price, $image_path, $address);

        if ($stmt->execute()) {
            send_response('success', 'Product created successfully.');
        } else {
            send_response('error', 'Failed to create product.');
        }
        $stmt->close();
        break;

    // NOTE: PUT and DELETE cases would be here for a full REST API
    // They are omitted for brevity but would follow a similar pattern of
    // checking authorization and executing a prepared statement.

    default:
        send_response('error', 'Invalid request method.');
        break;
}

$conn->close();
?>
