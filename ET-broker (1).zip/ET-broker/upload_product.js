// Upload Product Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const uploadForm = document.getElementById('uploadForm');
    const imageUploadArea = document.getElementById('imageUploadArea');
    const productImagesInput = document.getElementById('productImages');
    const imagePreviewContainer = document.getElementById('imagePreviewContainer');
    const priceInput = document.getElementById('price');
    const featuredListingCheckbox = document.getElementById('featuredListing');
    
    // State
    let uploadedImages = [];
    let mainImageIndex = 0;
    
    // Initialize
    setupEventListeners();
    updateFeePreview();
    
    function setupEventListeners() {
        // Image upload
        imageUploadArea.addEventListener('click', () => productImagesInput.click());
        productImagesInput.addEventListener('change', handleImageUpload);
        
        // Price change for fee calculation
        priceInput.addEventListener('input', updateFeePreview);
        featuredListingCheckbox.addEventListener('change', updateFeePreview);
        
        // Form submission
        uploadForm.addEventListener('submit', handleFormSubmit);
    }
    
    function handleImageUpload(e) {
        const files = Array.from(e.target.files);
        files.forEach(file => {
            if (file.type.startsWith('image/') && file.size <= 5 * 1024 * 1024) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    uploadedImages.push({
                        file: file,
                        url: e.target.result,
                        id: Date.now() + Math.random()
                    });
                    renderImagePreview();
                };
                reader.readAsDataURL(file);
            }
        });
    }
    
    function renderImagePreview() {
        imagePreviewContainer.innerHTML = '';
        uploadedImages.forEach((image, index) => {
            const previewItem = document.createElement('div');
            previewItem.className = 'image-preview-item';
            previewItem.innerHTML = `
                <img src="${image.url}" alt="Product image">
                <button class="remove-btn" onclick="removeImage(${index})">×</button>
                ${index === mainImageIndex ? '<div class="main-image-badge">Main</div>' : ''}
            `;
            previewItem.addEventListener('click', () => setMainImage(index));
            imagePreviewContainer.appendChild(previewItem);
        });
    }
    
    function removeImage(index) {
        uploadedImages.splice(index, 1);
        if (mainImageIndex >= uploadedImages.length) {
            mainImageIndex = Math.max(0, uploadedImages.length - 1);
        }
        renderImagePreview();
    }
    
    function setMainImage(index) {
        mainImageIndex = index;
        renderImagePreview();
    }
    
    function updateFeePreview() {
        const price = parseFloat(priceInput.value) || 0;
        const listingFee = (price * 5) / 100;
        const tax = (listingFee * 15) / 100;
        const featuredPrice = featuredListingCheckbox.checked ? 50 : 0;
        const totalFee = listingFee + tax + featuredPrice;
        
        document.getElementById('previewPrice').textContent = `ETB ${price.toFixed(2)}`;
        document.getElementById('previewListingFee').textContent = `ETB ${listingFee.toFixed(2)}`;
        document.getElementById('previewTax').textContent = `ETB ${tax.toFixed(2)}`;
        document.getElementById('previewTotalFee').textContent = `ETB ${totalFee.toFixed(2)}`;
    }
    
    function handleFormSubmit(e) {
        e.preventDefault();
        alert('Product upload functionality will be implemented with backend integration');
    }
    
    // Make functions globally available
    window.removeImage = removeImage;
    window.setMainImage = setMainImage;
});